
import React from 'react';
import { motion } from "framer-motion";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { 
  CheckCircle2, 
  FileText, 
  Image as ImageIcon,
  Download,
  Link2 
} from "lucide-react";

export default function ChatMessage({ message, isCurrentUser }) {
  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const today = new Date();
    const isToday = date.toDateString() === today.toDateString();
    
    return isToday
      ? format(date, 'HH:mm')
      : format(date, 'MMM d, HH:mm');
  };

  // Render system messages (like campaign confirmations)
  if (message.type === 'system') {
    return (
      <div className="flex justify-center my-4">
        <div className="bg-gray-100 rounded-lg px-4 py-2 max-w-xs sm:max-w-md text-xs text-center text-gray-600">
          {message.text}
        </div>
      </div>
    );
  }

  // Render campaign summary card
  if (message.type === 'campaign_summary') {
    return (
      <div className="flex justify-center my-4">
        <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg p-3 max-w-xs sm:max-w-md">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle2 className="w-4 h-4" />
            <span className="font-medium">Campaign Confirmed</span>
          </div>
          <div className="text-sm opacity-90">
            ${message.campaign.budget} | {message.campaign.content_type} | 
            Due: {format(new Date(message.campaign.deadline), 'MMM d')}
          </div>
        </div>
      </div>
    );
  }

  // Render file attachments
  if (message.attachments?.length > 0) {
    return (
      <div className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'} my-2`}>
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`flex flex-col ${isCurrentUser ? 'items-end' : 'items-start'}`}
        >
          <div className="flex gap-2 mb-2">
            {message.attachments.map((file, index) => (
              <div
                key={index}
                className="bg-white rounded-lg border p-2 flex items-center gap-2"
              >
                {file.type.startsWith('image') ? (
                  <div className="relative w-12 h-12 rounded overflow-hidden">
                    <img 
                      src={file.url} 
                      alt="attachment" 
                      className="object-cover w-full h-full"
                    />
                  </div>
                ) : (
                  <FileText className="w-5 h-5 text-gray-500" />
                )}
                <div className="flex flex-col">
                  <span className="text-sm font-medium truncate max-w-[120px]">
                    {file.name}
                  </span>
                  <div className="flex gap-2">
                    <button className="text-xs text-blue-600 hover:underline">
                      <Download className="w-3 h-3 inline mr-1" />
                      Download
                    </button>
                    <button className="text-xs text-blue-600 hover:underline">
                      <Link2 className="w-3 h-3 inline mr-1" />
                      Preview
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <span className="text-xs text-gray-500 mx-2">
            {formatTimestamp(message.timestamp)}
          </span>
        </motion.div>
      </div>
    );
  }

  // Render regular message
  return (
    <div 
      className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'} my-2`}
    >
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className={`flex flex-col ${isCurrentUser ? 'items-end' : 'items-start'}`}
      >
        <div className={`px-4 py-2 rounded-2xl max-w-xs sm:max-w-md ${
          isCurrentUser
            ? 'bg-purple-600 text-white rounded-tr-none'
            : 'bg-white border rounded-tl-none'
        }`}>
          {message.text}
        </div>
        <span className="text-xs text-gray-500 mt-1 mx-2">
          {formatTimestamp(message.timestamp)}
        </span>
      </motion.div>
    </div>
  );
}
