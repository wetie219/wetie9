import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { motion } from 'framer-motion';

export default function PlatformConnector({
  type,
  icon: Icon,
  label,
  handle,
  connected,
  editMode,
  onConnect,
  onChange,
  iconColor,
  gradientFrom,
  gradientTo
}) {
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-0">
        <div className={`py-2 px-4 flex items-center justify-between bg-gradient-to-r ${gradientFrom} ${gradientTo}`}>
          <div className="flex items-center">
            <Icon className="w-5 h-5 text-white mr-2" />
            <span className="text-white font-medium">{label}</span>
          </div>
          
          {connected && (
            <Badge className="bg-white text-gray-900 border-none">
              Connected
            </Badge>
          )}
        </div>
        
        <div className="p-4 space-y-3">
          {editMode ? (
            <>
              <div className="flex gap-2">
                <div className="flex items-center justify-center w-8">
                  <span className="text-gray-600">@</span>
                </div>
                <Input
                  value={handle}
                  onChange={(e) => onChange(e.target.value)}
                  placeholder={`${label.toLowerCase()}handle`}
                  className="flex-1"
                />
              </div>
              
              {!connected && (
                <motion.div whileTap={{ scale: 0.97 }}>
                  <Button
                    onClick={onConnect}
                    size="sm"
                    className={`w-full bg-white border text-gray-800 hover:bg-gray-100`}
                  >
                    <Icon className={`w-4 h-4 mr-2 ${iconColor}`} />
                    Connect {label}
                  </Button>
                </motion.div>
              )}
            </>
          ) : (
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${iconColor}`}>
                <Icon className="w-4 h-4" />
              </div>
              <div>
                <div className={`text-sm font-medium ${connected ? '' : 'text-gray-400'}`}>
                  @{handle || `your${label.toLowerCase()}handle`}
                </div>
                {!connected && (
                  <div className="text-xs text-gray-400">
                    Not connected via API
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}