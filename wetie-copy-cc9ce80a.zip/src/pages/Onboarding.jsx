import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Business } from "@/api/entities";
import { Influencer } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";
import { 
  ArrowLeft,
  ArrowRight, 
  CheckCircle
} from "lucide-react";

// Step components
import UserTypeSelection from "../components/onboarding/UserTypeSelection";
import ProfileUpload from "../components/onboarding/ProfileUpload";
import InfluencerDetails from "../components/onboarding/InfluencerDetails";
import InfluencerSocial from "../components/onboarding/InfluencerSocial";
import InfluencerCategories from "../components/onboarding/InfluencerCategories";
import InfluencerLocation from "../components/onboarding/InfluencerLocation";
import BusinessDetails from "../components/onboarding/BusinessDetails";
import BusinessGoals from "../components/onboarding/BusinessGoals";
import BusinessLocation from "../components/onboarding/BusinessLocation";

export default function Onboarding() {
  const [currentStep, setCurrentStep] = useState(0);
  const [userData, setUserData] = useState(null);
  const [formData, setFormData] = useState({
    user_type: "",
    profile_photo: "",
    display_name: "",
    bio: "",
    niche: [],
    platforms: {
      instagram: { handle: "" }
    },
    location: "",
    languages: [],
    company_name: "",
    industry: "",
    campaign_goals: [],
    locations: [],
    budget_range: ""
  });
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const loadUserData = async () => {
      try {
        const user = await User.me();
        setUserData(user);
        
        // Set user type from RoleSelection page
        if (user.user_type) {
          setFormData(prev => ({
            ...prev,
            user_type: user.user_type
          }));
        }
        
        // If user has completed onboarding, redirect to dashboard
        if (user.onboarding_completed) {
          if (user.user_type === "influencer") {
            navigate(createPageUrl("InfluencerDashboard"));
          } else {
            navigate(createPageUrl("Dashboard"));
          }
          return;
        }
        
        // If user has started onboarding, restore progress
        if (user.onboarding_step > 0) {
          setCurrentStep(user.onboarding_step);
          
          // Restore form data if user is influencer or business
          if (user.user_type === "influencer") {
            const influencerData = await Influencer.filter({ user_id: user.id });
            if (influencerData.length > 0) {
              const data = influencerData[0];
              setFormData(prev => ({
                ...prev,
                user_type: "influencer",
                profile_photo: data.profile_picture || "",
                display_name: data.full_name || "",
                bio: data.bio || "",
                niche: data.niche || [],
                platforms: data.platforms || { instagram: { handle: "" } },
                location: data.location || "",
                languages: data.languages || []
              }));
            }
          } else if (user.user_type === "brand") {
            const businessData = await Business.filter({ user_id: user.id });
            if (businessData.length > 0) {
              const data = businessData[0];
              setFormData(prev => ({
                ...prev,
                user_type: "brand",
                profile_photo: data.logo_url || "",
                company_name: data.company_name || "",
                industry: data.industry || "",
                campaign_goals: data.campaign_goals || [],
                locations: data.locations || [],
                budget_range: data.budget_range || ""
              }));
            }
          }
        } else if (!user.user_type) {
          // If user doesn't have a type yet, redirect to role selection
          navigate(createPageUrl("RoleSelection"));
        }
      } catch (error) {
        console.error("Error loading user data:", error);
        // Redirect to login if not authenticated
        navigate(createPageUrl("Landing"));
      } finally {
        setLoading(false);
      }
    };
    
    loadUserData();
  }, [navigate]);

  const updateFormData = (data) => {
    setFormData(prev => ({ ...prev, ...data }));
  };

  const saveProgress = async () => {
    try {
      // Save user type and onboarding progress
      await User.updateMyUserData({
        user_type: formData.user_type,
        onboarding_step: currentStep
      });
      
      // Save entity-specific data
      if (formData.user_type === "influencer") {
        // Check if influencer profile exists
        const existingProfiles = await Influencer.filter({ user_id: userData.id });
        
        const influencerData = {
          user_id: userData.id,
          full_name: formData.display_name,
          bio: formData.bio,
          profile_picture: formData.profile_photo,
          niche: formData.niche,
          location: formData.location,
          languages: formData.languages,
          platforms: formData.platforms
        };
        
        if (existingProfiles.length > 0) {
          await Influencer.update(existingProfiles[0].id, influencerData);
        } else {
          await Influencer.create(influencerData);
        }
      } else if (formData.user_type === "brand") {
        // Check if business profile exists
        const existingBusinesses = await Business.filter({ user_id: userData.id });
        
        const businessData = {
          user_id: userData.id,
          company_name: formData.company_name,
          industry: formData.industry,
          description: formData.bio,
          logo_url: formData.profile_photo,
          campaign_goals: formData.campaign_goals,
          locations: formData.locations,
          budget_range: formData.budget_range
        };
        
        if (existingBusinesses.length > 0) {
          await Business.update(existingBusinesses[0].id, businessData);
        } else {
          await Business.create(businessData);
        }
      }
    } catch (error) {
      console.error("Error saving progress:", error);
    }
  };

  const handleNext = async () => {
    // Save progress on every next step
    await saveProgress();
    setCurrentStep(prev => prev + 1);
  };

  const handlePrevious = () => {
    setCurrentStep(prev => prev - 1);
  };

  const handleComplete = async () => {
    try {
      // Final save with onboarding completed flag
      await saveProgress();
      await User.updateMyUserData({
        onboarding_completed: true
      });
      
      // Redirect to appropriate dashboard
      if (formData.user_type === "influencer") {
        navigate(createPageUrl("InfluencerDashboard"));
      } else {
        navigate(createPageUrl("Dashboard"));
      }
    } catch (error) {
      console.error("Error completing onboarding:", error);
    }
  };

  const getStepComponent = () => {
    // Skip user type selection since it's now done on the RoleSelection page
    const stepMapping = {
      "influencer": [
        <ProfileUpload formData={formData} updateFormData={updateFormData} />,
        <InfluencerDetails formData={formData} updateFormData={updateFormData} />,
        <InfluencerCategories formData={formData} updateFormData={updateFormData} />,
        <InfluencerSocial formData={formData} updateFormData={updateFormData} />,
        <InfluencerLocation formData={formData} updateFormData={updateFormData} />
      ],
      "brand": [
        <ProfileUpload formData={formData} updateFormData={updateFormData} />,
        <BusinessDetails formData={formData} updateFormData={updateFormData} />,
        <BusinessGoals formData={formData} updateFormData={updateFormData} />,
        <BusinessLocation formData={formData} updateFormData={updateFormData} />
      ]
    };
    
    return stepMapping[formData.user_type]?.[currentStep] || null;
  };

  // Determine max steps based on user type
  const getMaxSteps = () => {
    if (formData.user_type === "influencer") return 5;
    if (formData.user_type === "brand") return 4;
    return 0;
  };

  // Validate current step
  const isStepValid = () => {
    if (formData.user_type === "influencer") {
      switch (currentStep) {
        case 0:
          return !!formData.profile_photo;
        case 1:
          return !!formData.display_name;
        case 2:
          return formData.niche && formData.niche.length > 0;
        case 3:
          return formData.platforms?.instagram?.handle;
        case 4:
          return !!formData.location;
        default:
          return true;
      }
    } else if (formData.user_type === "brand") {
      switch (currentStep) {
        case 0:
          return !!formData.profile_photo;
        case 1:
          return !!formData.company_name && !!formData.industry;
        case 2:
          return formData.campaign_goals && formData.campaign_goals.length > 0;
        case 3:
          return true; // Business locations are optional
        default:
          return true;
      }
    }
    return false;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  const maxSteps = getMaxSteps();
  const isLastStep = currentStep === maxSteps - 1;

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white py-8 px-4">
      <div className="max-w-lg mx-auto">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-600">Step {currentStep + 1} of {maxSteps}</span>
            <span className="text-sm font-medium text-gray-600">{Math.round(((currentStep + 1) / maxSteps) * 100)}% Complete</span>
          </div>
          <div className="h-2 bg-gray-200 rounded-full">
            <div 
              className="h-full bg-gradient-to-r from-[#2F2C7F] to-[#E010CD] rounded-full transition-all duration-300"
              style={{ width: `${((currentStep + 1) / maxSteps) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Content Card */}
        <Card className="bg-white shadow-md">
          <CardContent className="p-6 md:p-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
              >
                {getStepComponent()}
              </motion.div>
            </AnimatePresence>

            {/* Navigation Buttons */}
            <div className="mt-10 flex justify-between">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={currentStep === 0}
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              {isLastStep ? (
                <Button
                  onClick={handleComplete}
                  className="bg-gradient-to-r from-[#2F2C7F] to-[#E010CD] text-white"
                  disabled={!isStepValid()}
                >
                  Complete
                  <CheckCircle className="ml-2 h-4 w-4" />
                </Button>
              ) : (
                <Button
                  onClick={handleNext}
                  className="bg-gradient-to-r from-[#2F2C7F] to-[#E010CD] text-white"
                  disabled={!isStepValid()}
                >
                  Next
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}