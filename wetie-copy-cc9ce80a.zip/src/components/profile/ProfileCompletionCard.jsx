import React from 'react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle, ArrowRight } from "lucide-react";

export default function ProfileCompletionCard({ percentage }) {
  const getCompletionItems = () => {
    return [
      {
        label: "Upload company logo",
        status: percentage >= 20
      },
      {
        label: "Add company details",
        status: percentage >= 40
      },
      {
        label: "Set campaign goals",
        status: percentage >= 60
      },
      {
        label: "Define target audience",
        status: percentage >= 80
      },
      {
        label: "Complete your profile",
        status: percentage >= 100
      }
    ];
  };

  const items = getCompletionItems();
  const nextItem = items.find(item => !item.status);

  return (
    <Card className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 shadow-sm border-purple-100">
      <div className="flex items-start gap-4">
        <div className="flex-1">
          <h3 className="font-medium mb-1 text-purple-900">Complete your profile</h3>
          <p className="text-sm text-purple-700 mb-4">
            A complete profile helps you match with the perfect influencers
          </p>
          
          <ul className="space-y-2">
            {items.slice(0, 3).map((item, index) => (
              <li key={index} className="flex items-center gap-2 text-sm">
                {item.status ? (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                ) : (
                  <XCircle className="w-4 h-4 text-gray-300" />
                )}
                <span className={item.status ? "text-gray-700" : "text-gray-500"}>
                  {item.label}
                </span>
              </li>
            ))}
          </ul>
        </div>
        
        {nextItem && (
          <Button className="bg-purple-600 hover:bg-purple-700">
            {nextItem.label}
            <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        )}
      </div>
    </Card>
  );
}