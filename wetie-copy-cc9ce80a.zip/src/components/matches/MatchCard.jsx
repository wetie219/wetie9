import React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, X, Loader2 } from "lucide-react";
import MatchPercentageCircle from "../dashboard/MatchPercentageCircle";

export default function MatchCard({ match, onAccept, onDecline, processing }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      layout
    >
      <Card className="p-4 hover:shadow-md transition-shadow duration-300">
        <div className="flex items-start gap-4">
          {/* Brand Logo */}
          <div className="w-16 h-16 rounded-xl bg-gray-100 border flex items-center justify-center overflow-hidden">
            <img
              src={match.business?.logo_url || "https://via.placeholder.com/64"}
              alt={match.business?.company_name}
              className="w-12 h-12 object-contain"
            />
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold text-gray-900">
                  {match.business?.company_name}
                </h3>
                <p className="text-sm text-gray-600">
                  {match.business?.industry} · {match.business?.location}
                </p>
              </div>
              
              {/* Match Percentage */}
              <MatchPercentageCircle percentage={match.match_percentage || 75} />
            </div>

            {/* Campaign Info */}
            {match.campaign_details?.title && (
              <div className="mt-2">
                <Badge variant="secondary" className="bg-purple-50 text-purple-700">
                  {match.campaign_details.title}
                </Badge>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-2 mt-4">
              <Button
                className="flex-1 bg-green-500 hover:bg-green-600 text-white"
                onClick={onAccept}
                disabled={processing}
              >
                {processing ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <>
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Accept
                  </>
                )}
              </Button>
              <Button
                variant="outline"
                className="flex-1 border-red-200 text-red-600 hover:bg-red-50"
                onClick={onDecline}
                disabled={processing}
              >
                <X className="w-4 h-4 mr-2" />
                Decline
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}