
import React, { useState, useEffect, useRef } from "react";
import { User } from "@/api/entities";
import { Business } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Separator } from "@/components/ui/separator";
import {
  Upload,
  CheckCircle,
  Building2,
  LogOut,
  Edit,
  Tag,
  FileText,
  Globe,
  MapPin,
  DollarSign,
  Target,
  Megaphone,
  Rocket,
  ShoppingBag,
  Users,
  Zap,
  Instagram,
  Youtube,
  Music,
  Linkedin,
  Facebook,
  ArrowRight,
  PieChart,
  BellRing,
  Calendar,
  Info,
  Eye,
  CheckCircle2,
  HelpCircle,
  MessageSquare
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { UploadFile } from "@/api/integrations";
import ProfileCompletionCard from "../components/profile/ProfileCompletionCard";
import SocialMediaLinks from "../components/profile/SocialMediaLinks";
import MatchingPreview from "../components/profile/MatchingPreview";
import ProfileCompletionCircle from "../components/profile/ProfileCompletionCircle";
import { motion, AnimatePresence } from "framer-motion";

export default function Profile() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [business, setBusiness] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState("company_info");
  const [completionPercentage, setCompletionPercentage] = useState(0);
  const [confettiActive, setConfettiActive] = useState(false);
  const [viewAsInfluencer, setViewAsInfluencer] = useState(false);
  const formRef = useRef(null);
  const [formData, setFormData] = useState({
    company_name: "",
    username: "",
    industry: "",
    description: "",
    website: "",
    location: "",
    campaign_goals: [],
    budget_range: "",
    preferred_platforms: [],
    target_audience: {
      age_range: [],
      gender: [],
      interests: [],
      locations: []
    },
    social_media: {
      instagram: "",
      tiktok: "",
      linkedin: "",
      facebook: ""
    },
    logo_url: ""
  });
  const [logoFile, setLogoFile] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  
  useEffect(() => {
    loadData();
  }, []);
  
  useEffect(() => {
    // Calculate profile completion percentage
    const newPercentage = calculateProfileCompletion();
    
    // If completion percentage reaches 100%, trigger confetti
    if (newPercentage === 100 && completionPercentage < 100) {
      setConfettiActive(true);
      setTimeout(() => setConfettiActive(false), 3000);
    }
  }, [formData]);

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      const businessList = await Business.filter({ user_id: userData.id });
      if (businessList.length > 0) {
        const businessData = businessList[0];
        setBusiness(businessData);
        setFormData({
          company_name: businessData.company_name || "",
          username: businessData.username || `@${businessData.company_name?.toLowerCase().replace(/\s+/g, '')}` || "",
          industry: businessData.industry || "",
          description: businessData.description || "",
          website: businessData.website || "",
          location: businessData.locations?.[0] || "",
          campaign_goals: businessData.campaign_goals || [],
          budget_range: businessData.budget_range || "",
          preferred_platforms: businessData.preferred_platforms || [],
          target_audience: businessData.target_audience || {
            age_range: [],
            gender: [],
            interests: [],
            locations: []
          },
          social_media: businessData.social_media || {
            instagram: "",
            tiktok: "",
            linkedin: "",
            facebook: ""
          },
          logo_url: businessData.logo_url || ""
        });
      }
    } catch (error) {
      console.error("Error loading profile data:", error);
    } finally {
      setLoading(false);
    }
  };

  const calculateProfileCompletion = () => {
    let requiredFields = [
      'company_name', 
      'industry', 
      'description', 
      'logo_url',
      'budget_range'
    ];
    
    let bonusFields = [
      'website',
      'location',
      'social_media.instagram',
      'social_media.linkedin',
      'preferred_platforms',
      'campaign_goals',
      'target_audience.age_range',
      'target_audience.locations'
    ];
    
    // Calculate required fields completion (70% of total)
    let completedRequired = requiredFields.filter(field => {
      const value = field.includes('.') 
        ? formData[field.split('.')[0]][field.split('.')[1]]
        : formData[field];
      return value && (Array.isArray(value) ? value.length > 0 : true);
    }).length;
    
    let requiredPercentage = (completedRequired / requiredFields.length) * 70;
    
    // Calculate bonus fields completion (30% of total)
    let completedBonus = bonusFields.filter(field => {
      if (field.includes('.')) {
        const [parent, child] = field.split('.');
        const value = formData[parent][child];
        return value && (Array.isArray(value) ? value.length > 0 : true);
      } else {
        const value = formData[field];
        return value && (Array.isArray(value) ? value.length > 0 : true);
      }
    }).length;
    
    let bonusPercentage = (completedBonus / bonusFields.length) * 30;
    
    const newPercentage = Math.round(requiredPercentage + bonusPercentage);
    setCompletionPercentage(newPercentage);
    return newPercentage;
  };

  const getMissingField = () => {
    const fields = {
      'company_name': 'company name',
      'industry': 'industry',
      'description': 'description',
      'logo_url': 'logo',
      'budget_range': 'budget range',
      'campaign_goals': 'campaign goals',
      'preferred_platforms': 'preferred platforms',
      'target_audience.age_range': 'target age range'
    };
    
    for (const [field, label] of Object.entries(fields)) {
      const value = field.includes('.') 
        ? formData[field.split('.')[0]][field.split('.')[1]]
        : formData[field];
      
      if (!value || (Array.isArray(value) && value.length === 0)) {
        return label;
      }
    }
    
    return null;
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleNestedChange = (parent, field, value) => {
    setFormData(prev => ({
      ...prev,
      [parent]: {
        ...prev[parent],
        [field]: value
      }
    }));
  };

  // Safe array check helper
  const safeArray = (arr) => Array.isArray(arr) ? arr : [];

  // Safe object check helper
  const safeObject = (obj, defaultObj) => obj || defaultObj;

  const handleArrayToggle = (field, value) => {
    setFormData(prev => {
      const currentArray = safeArray(prev[field]);
      if (currentArray.includes(value)) {
        return {
          ...prev,
          [field]: currentArray.filter(item => item !== value)
        };
      } else {
        return {
          ...prev,
          [field]: [...currentArray, value]
        };
      }
    });
  };
  
  const handleNestedArrayToggle = (parent, field, value) => {
    setFormData(prev => {
      const parentObj = prev[parent] || {};
      const currentArray = safeArray(parentObj[field]);
      
      if (currentArray.includes(value)) {
        return {
          ...prev,
          [parent]: {
            ...parentObj,
            [field]: currentArray.filter(item => item !== value)
          }
        };
      } else {
        return {
          ...prev,
          [parent]: {
            ...parentObj,
            [field]: [...currentArray, value]
          }
        };
      }
    });
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setLogoFile(e.target.files[0]);
    }
  };

  const uploadLogo = async () => {
    if (!logoFile) return formData.logo_url;
    
    try {
      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => Math.min(prev + 10, 90));
      }, 200);

      const result = await UploadFile({ file: logoFile });
      clearInterval(progressInterval);
      setUploadProgress(100);
      
      return result.file_url;
    } catch (error) {
      console.error("Error uploading logo:", error);
      return formData.logo_url;
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    
    try {
      // Upload logo if new file selected
      const logo_url = await uploadLogo();
      
      const finalData = {
        ...formData,
        logo_url
      };
      
      if (business) {
        // Update existing business
        await Business.update(business.id, finalData);
      } else {
        // Create new business
        await Business.create(finalData);
      }
      
      // If profile is complete, show confetti
      if (completionPercentage === 100) {
        setConfettiActive(true);
        setTimeout(() => {
          setConfettiActive(false);
          navigate(createPageUrl("Dashboard"));
        }, 2000);
      } else {
        navigate(createPageUrl("Dashboard"));
      }
    } catch (error) {
      console.error("Error saving business profile:", error);
    } finally {
      setSaving(false);
    }
  };

  const handleLogout = async () => {
    try {
      await User.logout();
      // Redirect to Landing page which has sign in and sign up options
      navigate(createPageUrl("Landing"));
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };

  const scrollToMissingField = () => {
    if (formRef.current) {
      formRef.current.scrollIntoView({ behavior: 'smooth' });
    }
    
    const missingField = getMissingField();
    if (missingField === 'campaign goals' || missingField === 'budget range' || 
        missingField === 'preferred platforms' || missingField === 'target age range') {
      setActiveTab('campaign_prefs');
    } else {
      setActiveTab('company_info');
    }
  };

  // Simulated suggested influencers based on profile data
  const suggestedInfluencers = [
    {
      id: 'inf1',
      name: 'Sarah Watkins',
      handle: '@sarahcreates',
      image: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
      platforms: ['instagram', 'tiktok'],
      niche: ['fashion', 'lifestyle'],
      matchScore: 94
    },
    {
      id: 'inf2',
      name: 'Mike Chen',
      handle: '@mikestech',
      image: 'https://images.unsplash.com/photo-1552058544-f2b08422138a?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
      platforms: ['youtube', 'instagram'],
      niche: ['tech', 'gadgets'],
      matchScore: 87
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  // Early return for the "View as Influencer" mode
  if (viewAsInfluencer) {
    return (
      <div className="pb-32 bg-gray-50 min-h-screen">
        {/* Public View Header */}
        <div className="bg-gradient-to-r from-purple-100 to-pink-50 py-8 px-4 relative">
          <div className="max-w-2xl mx-auto">
            <div className="flex justify-end absolute top-4 right-4">
              <Button 
                variant="outline" 
                size="sm" 
                className="bg-white/80 backdrop-blur-sm text-purple-800 border-purple-200 hover:bg-white"
                onClick={() => setViewAsInfluencer(false)}
              >
                <Eye className="w-4 h-4 mr-2" />
                Exit Preview
              </Button>
            </div>
            
            <div className="flex items-start gap-4 mt-4">
              {/* Logo Circle */}
              <div className="relative">
                <div className="w-20 h-20 rounded-full bg-white flex items-center justify-center border-2 border-purple-100 overflow-hidden">
                  {formData.logo_url ? (
                    <img 
                      src={formData.logo_url} 
                      alt="Company Logo" 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Building2 className="w-8 h-8 text-gray-300" />
                  )}
                </div>
              </div>
              
              {/* Company Info */}
              <div className="flex-1">
                <div className="flex items-center">
                  <h1 className="text-2xl font-bold">
                    {formData.company_name || "Your Company"}
                  </h1>
                  {completionPercentage >= 90 && (
                    <Badge className="ml-2 bg-blue-100 text-blue-800">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Verified
                    </Badge>
                  )}
                </div>
                <p className="text-gray-500 mb-1">
                  {formData.username || "@yourcompany"}
                </p>
                <p className="text-sm text-gray-600 mb-3">
                  {formData.industry ? formData.industry.charAt(0).toUpperCase() + formData.industry.slice(1) : "Industry"} 
                  {formData.location && ` · ${formData.location}`}
                </p>
                <p className="text-sm text-gray-600 line-clamp-2">
                  {formData.description || "No company description provided."}
                </p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Public Profile Content */}
        <div className="max-w-2xl mx-auto mt-8 px-4">
          {/* Campaign Preferences Section */}
          <div className="space-y-6">
            <h2 className="text-lg font-semibold">Campaign Preferences</h2>
            
            <Card className="p-6">
              <div className="space-y-6">
                {/* Campaign Goals */}
                {formData.campaign_goals.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium flex items-center mb-3">
                      <Target className="w-4 h-4 text-purple-600 mr-2" />
                      Campaign Goals
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {formData.campaign_goals.map(goal => {
                        const label = goal.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
                        return (
                          <Badge key={goal} className="bg-purple-100 text-purple-800 px-3 py-1">
                            {label}
                          </Badge>
                        );
                      })}
                    </div>
                  </div>
                )}
                
                {/* Preferred Platforms */}
                {formData.preferred_platforms.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium flex items-center mb-3">
                      <Zap className="w-4 h-4 text-purple-600 mr-2" />
                      Preferred Platforms
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {formData.preferred_platforms.map(platform => (
                        <Badge key={platform} className="bg-blue-100 text-blue-800 px-3 py-1">
                          {platform.charAt(0).toUpperCase() + platform.slice(1)}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Budget Range */}
                {formData.budget_range && (
                  <div>
                    <h3 className="text-sm font-medium flex items-center mb-3">
                      <DollarSign className="w-4 h-4 text-purple-600 mr-2" />
                      Budget Range
                    </h3>
                    <Badge className="bg-green-100 text-green-800 px-3 py-1">
                      {formData.budget_range === "0-500" && "$0 - $500"}
                      {formData.budget_range === "501-2000" && "$501 - $2,000"}
                      {formData.budget_range === "2001-5000" && "$2,001 - $5,000"}
                      {formData.budget_range === "5000+" && "$5,000+"}
                    </Badge>
                  </div>
                )}
                
                {/* Target Audience */}
                {formData.target_audience.age_range.length > 0 && (
                  <div>
                    <h3 className="text-sm font-medium flex items-center mb-3">
                      <Users className="w-4 h-4 text-purple-600 mr-2" />
                      Target Audience
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {formData.target_audience.age_range.map(age => (
                        <Badge key={age} className="bg-amber-100 text-amber-800 px-3 py-1">
                          Age {age}
                        </Badge>
                      ))}
                      
                      {formData.target_audience.gender.map(gender => (
                        <Badge key={gender} className="bg-amber-100 text-amber-800 px-3 py-1">
                          {gender.charAt(0).toUpperCase() + gender.slice(1)}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </Card>
            
            {/* Contact Button */}
            <div className="flex justify-center mt-8">
              <Button 
                className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-6"
                size="lg"
              >
                <MessageSquare className="w-5 h-5 mr-2" />
                Connect with This Brand
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-32 bg-gray-50 min-h-screen">
      {/* Confetti Animation - Shown when profile hits 100% */}
      <AnimatePresence>
        {confettiActive && (
          <motion.div
            className="fixed inset-0 pointer-events-none z-50 overflow-hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="absolute inset-0 flex items-center justify-center">
              <img 
                src="https://cdn.pixabay.com/animation/2022/12/05/10/47/10-47-43-71_512.gif" 
                alt="Celebration" 
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Section */}
      <div className="bg-gradient-to-r from-purple-100 to-pink-50 py-8 px-4 sticky top-0 z-20 shadow-sm">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-start gap-4">
            {/* Logo Circle */}
            <div className="relative">
              <div 
                className="w-20 h-20 rounded-full bg-white flex items-center justify-center border-2 border-purple-100 overflow-hidden shadow-md group cursor-pointer transition-all duration-300 hover:shadow-lg"
                onClick={() => document.getElementById("logo").click()}
              >
                {formData.logo_url || logoFile ? (
                  <img 
                    src={logoFile ? URL.createObjectURL(logoFile) : formData.logo_url} 
                    alt="Company Logo" 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <Building2 className="w-8 h-8 text-gray-300" />
                )}
                
                <input
                  id="logo"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileChange}
                />
                
                <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white text-sm font-medium transition-opacity">
                  <Upload className="w-4 h-4 mr-1" />
                  Upload
                </div>
              </div>
            </div>
            
            {/* Company Info */}
            <div className="flex-1">
              <div className="flex items-center flex-wrap gap-2">
                <h1 className="text-2xl font-bold text-gray-900">
                  {formData.company_name || "Your Company"}
                </h1>
                {completionPercentage >= 90 && (
                  <Badge className="bg-blue-100 text-blue-800">
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    Verified
                  </Badge>
                )}
              </div>
              <p className="text-gray-500 mb-1">
                {formData.username || "@yourcompany"}
              </p>
              <p className="text-sm text-gray-600 mb-2">
                {formData.industry ? formData.industry.charAt(0).toUpperCase() + formData.industry.slice(1) : "Select your industry"}
                {formData.location && ` · ${formData.location}`}
              </p>
              <p className="text-sm text-gray-600 line-clamp-1 mb-3">
                {formData.description ? formData.description.substring(0, 80) + (formData.description.length > 80 ? '...' : '') : "Add your company description..."}
              </p>
            </div>
            
            {/* Action Buttons */}
            <div className="flex flex-col gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                className="flex items-center gap-1 bg-white/80 backdrop-blur-sm"
              >
                <Edit className="w-4 h-4" />
                Edit
              </Button>
              
              <Button 
                variant="outline" 
                size="sm" 
                className="flex items-center gap-1 bg-white/80 backdrop-blur-sm text-purple-800 border-purple-200 hover:bg-white"
                onClick={() => setViewAsInfluencer(true)}
              >
                <Eye className="w-4 h-4" />
                Preview
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Profile Completion Progress */}
      <div className="max-w-2xl mx-auto px-4 mt-4">
        <motion.div
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="p-4 bg-white shadow-sm border-purple-100 overflow-hidden">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <ProfileCompletionCircle percentage={completionPercentage} />
                
                <div>
                  <h3 className="font-medium text-gray-900">Profile completion</h3>
                  <p className="text-sm text-gray-600">
                    {completionPercentage < 100 
                      ? `${getMissingField() ? `Add ${getMissingField()} to improve` : "Keep adding details to improve"}` 
                      : "Your profile is complete! 🎉"}
                  </p>
                </div>
              </div>
              
              {completionPercentage < 100 && (
                <Button 
                  size="sm"
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                  onClick={scrollToMissingField}
                >
                  Complete Setup
                  <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
              )}
            </div>
          </Card>
        </motion.div>
      </div>
      
      {/* Tab Navigation */}
      <div className="max-w-2xl mx-auto mt-6 px-4" ref={formRef}>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-2 mb-8">
            <TabsTrigger value="company_info" className="flex items-center gap-2">
              <Building2 className="w-4 h-4" />
              Company Information
            </TabsTrigger>
            <TabsTrigger value="campaign_prefs" className="flex items-center gap-2">
              <Target className="w-4 h-4" />
              Campaign Preferences
            </TabsTrigger>
          </TabsList>
          
          <form onSubmit={handleSubmit}>
            <TabsContent value="company_info" className="space-y-6">
              {/* Company Information Card */}
              <Card className="p-6 shadow-sm bg-white">
                <h2 className="text-lg font-semibold flex items-center gap-2 mb-6">
                  <Building2 className="w-5 h-5 text-purple-600" />
                  Company Information
                </h2>
                
                <div className="space-y-5">
                  <div className="grid gap-6 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="company_name" className="flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-gray-500" />
                        Company Name
                      </Label>
                      <Input
                        id="company_name"
                        value={formData.company_name}
                        onChange={(e) => handleChange("company_name", e.target.value)}
                        placeholder="Your company name"
                        required
                        className="border-gray-200 focus:border-purple-400 transition-colors"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="username" className="flex items-center gap-2">
                        <span className="text-gray-500">@</span>
                        Username
                      </Label>
                      <Input
                        id="username"
                        value={formData.username}
                        onChange={(e) => handleChange("username", e.target.value)}
                        placeholder="@yourcompany"
                        className="border-gray-200 focus:border-purple-400 transition-colors"
                      />
                    </div>
                  </div>
                  
                  <div className="grid gap-6 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="industry" className="flex items-center gap-2">
                        <Tag className="w-4 h-4 text-gray-500" />
                        Industry
                      </Label>
                      <Select
                        value={formData.industry}
                        onValueChange={(value) => handleChange("industry", value)}
                        required
                      >
                        <SelectTrigger className="border-gray-200 focus:border-purple-400 transition-colors">
                          <SelectValue placeholder="Select industry" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="fashion">Fashion</SelectItem>
                          <SelectItem value="beauty">Beauty</SelectItem>
                          <SelectItem value="tech">Technology</SelectItem>
                          <SelectItem value="food">Food & Beverage</SelectItem>
                          <SelectItem value="fitness">Fitness</SelectItem>
                          <SelectItem value="lifestyle">Lifestyle</SelectItem>
                          <SelectItem value="gaming">Gaming</SelectItem>
                          <SelectItem value="education">Education</SelectItem>
                          <SelectItem value="travel">Travel</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="website" className="flex items-center gap-2">
                        <Globe className="w-4 h-4 text-gray-500" />
                        Website
                      </Label>
                      <Input
                        id="website"
                        value={formData.website}
                        onChange={(e) => handleChange("website", e.target.value)}
                        placeholder="https://yourcompany.com"
                        className="border-gray-200 focus:border-purple-400 transition-colors"
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="location" className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-gray-500" />
                      Location
                    </Label>
                    <Input
                      id="location"
                      value={formData.location}
                      onChange={(e) => handleChange("location", e.target.value)}
                      placeholder="City, Country"
                      className="border-gray-200 focus:border-purple-400 transition-colors"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="description" className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-gray-500" />
                      Description
                    </Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => handleChange("description", e.target.value)}
                      placeholder="Tell us about your company..."
                      className="min-h-[100px] border-gray-200 focus:border-purple-400 transition-colors"
                    />
                  </div>
                  
                  <Separator className="my-6" />
                  
                  {/* Social Media Links */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="flex items-center gap-2">
                        <Globe className="w-4 h-4 text-gray-500" />
                        Social Media Links
                      </Label>
                      
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <HelpCircle className="h-4 w-4 text-gray-400" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="w-80 text-sm">
                              Adding your social media profiles helps improve match relevance and builds trust with potential influencers.
                            </p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    
                    <p className="text-sm text-gray-500 mb-4">
                      Link your accounts to improve match accuracy and influencer interest.
                    </p>
                    
                    <SocialMediaLinks 
                      socialMedia={formData.social_media} 
                      onChange={(platform, value) => 
                        handleNestedChange("social_media", platform, value)
                      } 
                    />
                  </div>
                </div>
              </Card>
            </TabsContent>
            
            <TabsContent value="campaign_prefs" className="space-y-6">
              {/* Campaign Preferences Card */}
              <Card className="p-6 shadow-sm bg-white">
                <h2 className="text-lg font-semibold flex items-center gap-2 mb-6">
                  <Target className="w-5 h-5 text-purple-600" />
                  Campaign Preferences
                </h2>
                
                <div className="space-y-6">
                  <div className="space-y-3">
                    <Label className="flex items-center gap-2">
                      <Rocket className="w-4 h-4 text-gray-500" />
                      Campaign Goals
                    </Label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {[
                        { id: "brand_awareness", icon: Megaphone, label: "Brand Awareness" },
                        { id: "product_launch", icon: Rocket, label: "Product Launch" },
                        { id: "sales_boost", icon: ShoppingBag, label: "Sales Boost" },
                        { id: "community_engagement", icon: Users, label: "Community Engagement" },
                        { id: "content_creation", icon: FileText, label: "Content Creation" }
                      ].map((goal) => (
                        <motion.div
                          key={goal.id}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <Button
                            type="button"
                            variant={safeArray(formData.campaign_goals).includes(goal.id) ? "default" : "outline"}
                            className={`justify-start h-auto py-3 px-4 w-full ${
                              safeArray(formData.campaign_goals).includes(goal.id)
                                ? "bg-gradient-to-r from-purple-600 to-purple-700 text-white border-none shadow-md"
                                : "text-gray-700 hover:border-purple-300 hover:bg-purple-50"
                            }`}
                            onClick={() => handleArrayToggle("campaign_goals", goal.id)}
                          >
                            <div className="flex items-center">
                              <goal.icon className={`w-4 h-4 mr-2 ${safeArray(formData.campaign_goals).includes(goal.id) ? "text-white" : ""}`} />
                              <span>{goal.label}</span>
                            </div>
                          </Button>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-3">
                    <Label className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-gray-500" />
                      Budget Range
                    </Label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {[
                        { id: "0-500", label: "$0 - $500" },
                        { id: "501-2000", label: "$501 - $2,000" },
                        { id: "2001-5000", label: "$2,001 - $5,000" },
                        { id: "5000+", label: "$5,000+" }
                      ].map((budget) => (
                        <motion.div
                          key={budget.id}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <Button
                            type="button"
                            variant={formData.budget_range === budget.id ? "default" : "outline"}
                            className={`w-full ${
                              formData.budget_range === budget.id
                                ? "bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white border-none shadow-md"
                                : "text-gray-700 hover:border-green-300 hover:bg-green-50"
                            }`}
                            onClick={() => handleChange("budget_range", budget.id)}
                          >
                            {budget.label}
                          </Button>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-3">
                    <Label className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-gray-500" />
                      Preferred Platforms
                    </Label>
                    <div className="flex flex-wrap gap-3">
                      {[
                        { id: "instagram", icon: Instagram, label: "Instagram", gradient: "from-purple-600 to-pink-600" },
                        { id: "tiktok", icon: Music, label: "TikTok", gradient: "from-black to-gray-800" },
                        { id: "youtube", icon: Youtube, label: "YouTube", gradient: "from-red-600 to-red-700" }
                      ].map((platform) => (
                        <motion.div
                          key={platform.id}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <Button
                            type="button"
                            variant={safeArray(formData.preferred_platforms).includes(platform.id) ? "default" : "outline"}
                            className={`rounded-full ${
                              safeArray(formData.preferred_platforms).includes(platform.id)
                                ? `bg-gradient-to-r ${platform.gradient} text-white border-none shadow-md`
                                : "text-gray-700 hover:border-gray-300 hover:bg-gray-50"
                            }`}
                            onClick={() => handleArrayToggle("preferred_platforms", platform.id)}
                          >
                            <platform.icon className="w-4 h-4 mr-2" />
                            {platform.label}
                          </Button>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-3">
                    <Label className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-gray-500" />
                      Target Audience
                    </Label>
                    
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-sm font-medium mb-2">Age Range</h4>
                        <div className="flex flex-wrap gap-2">
                          {["13-17", "18-24", "25-34", "35-44", "45+"].map((age) => (
                            <Badge
                              key={age}
                              variant={safeArray(formData.target_audience?.age_range).includes(age) ? "default" : "outline"}
                              className={`cursor-pointer px-3 py-1.5 hover:bg-purple-50 transition-colors ${
                                safeArray(formData.target_audience?.age_range).includes(age) 
                                  ? "bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-700 hover:to-purple-600" 
                                  : ""
                              }`}
                              onClick={() => handleNestedArrayToggle("target_audience", "age_range", age)}
                            >
                              {age}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium mb-2">Gender</h4>
                        <div className="flex flex-wrap gap-2">
                          {[
                            {id: "male", label: "Male"},
                            {id: "female", label: "Female"},
                            {id: "all", label: "All Genders"}
                          ].map((gender) => (
                            <Badge
                              key={gender.id}
                              variant={safeArray(safeObject(formData.target_audience, {gender: []}).gender).includes(gender.id) ? "default" : "outline"}
                              className={`cursor-pointer px-3 py-1.5 hover:bg-purple-50 transition-colors ${
                                safeArray(safeObject(formData.target_audience, {gender: []}).gender).includes(gender.id)
                                  ? "bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-700 hover:to-purple-600" 
                                  : ""
                              }`}
                              onClick={() => handleNestedArrayToggle("target_audience", "gender", gender.id)}
                            >
                              {gender.label}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
              
              {/* Matching Preview Card */}
              <MatchingPreview formData={formData} suggestedInfluencers={suggestedInfluencers} />
            </TabsContent>
            
            {/* Sticky Submit Buttons */}
            <motion.div 
              className="fixed bottom-20 left-0 right-0 p-4 bg-white/95 backdrop-blur-sm border-t border-gray-100 shadow-lg z-30"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <div className="max-w-2xl mx-auto">
                <div className="flex gap-3">
                  <Button 
                    type="submit" 
                    className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white h-12"
                    disabled={saving}
                  >
                    {saving ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Saving...
                      </>
                    ) : (
                      <>
                        {business ? "Update Profile" : "Create Profile"}
                      </>
                    )}
                  </Button>

                  {/* Logout Button */}
                  <Button 
                    type="button" 
                    variant="outline"
                    className="border-red-200 text-red-600 hover:bg-red-50 h-12 w-12"
                    onClick={handleLogout}
                  >
                    <LogOut className="w-5 h-5" />
                  </Button>
                </div>
              </div>
            </motion.div>
          </form>
        </Tabs>
      </div>
    </div>
  );
}
