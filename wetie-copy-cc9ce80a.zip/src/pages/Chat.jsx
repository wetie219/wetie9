
import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Match } from "@/api/entities";
import { Influencer } from "@/api/entities";
import { Business } from "@/api/entities";
import { User } from "@/api/entities";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  ChevronLeft,
  Send,
  Paperclip,
  Rocket,
  Briefcase,
  Calendar,
  DollarSign,
  CheckCircle,
  X
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import CampaignForm from "../components/chat/CampaignForm";
import CampaignConfirmation from "../components/chat/CampaignConfirmation";
import CampaignCompletion from "../components/chat/CampaignCompletion";

/**
 * Chat Page Component
 * Handles messaging between matched businesses and influencers
 * Includes campaign proposal and escrow workflow
 */
export default function Chat() {
  const navigate = useNavigate();
  const [match, setMatch] = useState(null);
  const [partner, setPartner] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [showCampaignForm, setShowCampaignForm] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [showCompletion, setShowCompletion] = useState(false);
  const [campaignState, setCampaignState] = useState("not_started");
  const [campaignData, setCampaignData] = useState(null);
  
  const messagesEndRef = useRef(null);
  
  useEffect(() => {
    loadChatData();
  }, []);
  
  useEffect(() => {
    // Scroll to bottom of messages when they update
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  /**
   * Load chat and match data
   */
  const loadChatData = async () => {
    try {
      setLoading(true);
      
      // Get URL parameters
      const urlParams = new URLSearchParams(window.location.search);
      const matchId = urlParams.get('match_id');
      
      if (!matchId) {
        navigate(createPageUrl("Messages"));
        return;
      }
      
      // Get current user
      const user = await User.me();
      setCurrentUser(user);
      
      // Get match details
      const matchData = await Match.get(matchId);
      setMatch(matchData);
      
      // Determine partner based on user type
      if (user.user_type === "influencer") {
        const business = await Business.get(matchData.business_id);
        setPartner(business);
      } else {
        const influencer = await Influencer.get(matchData.influencer_id);
        setPartner(influencer);
      }
      
      // Load messages (in a real app, this would be from a Messages entity)
      // Here we're creating mock messages for demonstration
      const mockMessages = generateMockMessages(matchData, user);
      setMessages(mockMessages);
      
      // Set campaign state based on match status
      setCampaignState(getCampaignState(matchData));
      if (matchData.campaign_details) {
        setCampaignData(matchData.campaign_details);
      }
      
    } catch (error) {
      console.error("Error loading chat data:", error);
    } finally {
      setLoading(false);
    }
  };
  
  /**
   * Generate placeholder messages for demonstration
   */
  const generateMockMessages = (match, user) => {
    const timeOffset = 24 * 60 * 60 * 1000; // 1 day in milliseconds
    const now = new Date();
    
    return [
      {
        id: "msg1",
        sender_id: match.business_id,
        text: "Hey there! I'm interested in collaborating with you on our new product line.",
        timestamp: new Date(now.getTime() - timeOffset * 3)
      },
      {
        id: "msg2",
        sender_id: match.influencer_id,
        text: "Hi! I'd love to hear more about your brand and what you have in mind.",
        timestamp: new Date(now.getTime() - timeOffset * 2.9)
      },
      {
        id: "msg3",
        sender_id: match.business_id,
        text: "We're launching a new sustainable clothing collection next month and would love to have you showcase some pieces.",
        timestamp: new Date(now.getTime() - timeOffset * 2.5)
      },
      {
        id: "msg4",
        sender_id: match.influencer_id,
        text: "That sounds interesting! What kind of content are you looking for?",
        timestamp: new Date(now.getTime() - timeOffset)
      },
      {
        id: "msg5",
        sender_id: match.business_id,
        text: "We're thinking 2-3 Instagram posts and perhaps a Reel. We can provide all the products.",
        timestamp: new Date(now.getTime() - timeOffset * 0.5)
      },
      {
        id: "msg6",
        sender_id: match.influencer_id,
        text: "Perfect! Let's discuss the details of our collaboration. When would you need the content by? And do you have specific themes or color schemes in mind?",
        timestamp: new Date(now.getTime() - timeOffset * 0.2)
      },
      {
        id: "msg7",
        type: "campaign_summary",
        campaign: {
          budget: "1,500",
          content_type: "2 Posts + 1 Reel",
          deadline: new Date(now.getTime() + timeOffset * 14) // 2 weeks from now
        },
        timestamp: new Date()
      },
      {
        id: "msg8",
        type: "system",
        text: "🎯 Campaign confirmed! Payment secured in escrow.",
        timestamp: new Date()
      }
    ];
  };
  
  /**
   * Determine campaign state based on match data
   */
  const getCampaignState = (match) => {
    if (!match.campaign_details) return "not_started";
    
    switch(match.status) {
      case "campaign_negotiation":
        return match.campaign_details.brand_confirmed && match.campaign_details.influencer_confirmed 
          ? "pending_payment" 
          : "proposal";
      case "campaign_active":
        return "active";
      case "campaign_completed":
        return "completed";
      default:
        return "not_started";
    }
  };
  
  /**
   * Send a new message
   */
  const sendMessage = (e) => {
    e.preventDefault();
    if (!newMessage.trim()) return;
    
    const newMsg = {
      id: `msg${messages.length + 1}`,
      sender_id: currentUser.user_type === "influencer" ? match.influencer_id : match.business_id,
      text: newMessage,
      timestamp: new Date()
    };
    
    setMessages([...messages, newMsg]);
    setNewMessage("");
  };
  
  /**
   * Handle campaign form submission
   */
  const handleCampaignSubmit = async (data) => {
    try {
      // Create campaign proposal
      setCampaignData(data);
      
      // Update match status with campaign details
      const updatedMatch = {
        ...match,
        status: "campaign_negotiation",
        campaign_details: {
          ...data,
          [currentUser.user_type === "influencer" ? "influencer_confirmed" : "brand_confirmed"]: true,
          [currentUser.user_type === "influencer" ? "brand_confirmed" : "influencer_confirmed"]: false,
          proposal_date: new Date().toISOString()
        }
      };
      
      await Match.update(match.id, updatedMatch);
      setMatch(updatedMatch);
      setShowCampaignForm(false);
      setCampaignState("proposal");
      
      // Add automatic message about the proposal
      const systemMsg = {
        id: `msg${messages.length + 1}`,
        sender_id: "system",
        text: `${currentUser.full_name} proposed a campaign: "${data.title}" with a budget of $${data.budget}`,
        timestamp: new Date(),
        isSystem: true
      };
      
      setMessages([...messages, systemMsg]);
      
    } catch (error) {
      console.error("Error creating campaign proposal:", error);
    }
  };
  
  /**
   * Handle accepting a campaign proposal
   */
  const handleAcceptProposal = async () => {
    try {
      if (!match || !campaignData) return;
      
      // Update match with confirmation
      const updatedMatch = {
        ...match,
        campaign_details: {
          ...match.campaign_details,
          [currentUser.user_type === "influencer" ? "influencer_confirmed" : "brand_confirmed"]: true
        }
      };
      
      // Check if both sides have confirmed
      const bothConfirmed = 
        currentUser.user_type === "influencer" 
          ? updatedMatch.campaign_details.brand_confirmed && true
          : updatedMatch.campaign_details.influencer_confirmed && true;
      
      if (bothConfirmed) {
        updatedMatch.status = "campaign_negotiation";
        setCampaignState("pending_payment");
      }
      
      await Match.update(match.id, updatedMatch);
      setMatch(updatedMatch);
      
      // Add confirmation message
      const systemMsg = {
        id: `msg${messages.length + 1}`,
        sender_id: "system",
        text: `${currentUser.full_name} accepted the campaign proposal.${bothConfirmed ? " Both parties have accepted! You can now secure the campaign." : ""}`,
        timestamp: new Date(),
        isSystem: true
      };
      
      setMessages([...messages, systemMsg]);
      
      if (bothConfirmed) {
        setShowConfirmation(true);
      }
      
    } catch (error) {
      console.error("Error accepting proposal:", error);
    }
  };
  
  /**
   * Handle campaign payment & escrow
   */
  const handleCampaignPayment = async () => {
    try {
      // In a real app, this would create a Stripe payment session
      
      // Update match status
      const updatedMatch = {
        ...match,
        status: "campaign_active",
        campaign_details: {
          ...match.campaign_details,
          payment_status: "escrow",
          payment_date: new Date().toISOString()
        }
      };
      
      await Match.update(match.id, updatedMatch);
      setMatch(updatedMatch);
      setCampaignState("active");
      setShowConfirmation(false);
      
      // Add payment confirmation message
      const systemMsg = {
        id: `msg${messages.length + 1}`,
        sender_id: "system",
        text: "Campaign payment has been secured in escrow. The campaign is now active!",
        timestamp: new Date(),
        isSystem: true
      };
      
      setMessages([...messages, systemMsg]);
      
    } catch (error) {
      console.error("Error processing payment:", error);
    }
  };
  
  /**
   * Handle marking campaign as complete
   */
  const handleMarkComplete = async () => {
    try {
      // Update campaign with completion status
      const updatedMatch = {
        ...match,
        campaign_details: {
          ...match.campaign_details,
          [currentUser.user_type === "influencer" ? "influencer_completed" : "brand_completed"]: true
        }
      };
      
      // Check if both sides have confirmed completion
      const bothCompleted = 
        currentUser.user_type === "influencer" 
          ? updatedMatch.campaign_details.brand_completed && true
          : updatedMatch.campaign_details.influencer_completed && true;
      
      if (bothCompleted) {
        updatedMatch.status = "campaign_completed";
        setCampaignState("completed");
        
        // In a real app, this would trigger Stripe payout from escrow
      }
      
      await Match.update(match.id, updatedMatch);
      setMatch(updatedMatch);
      
      // Add completion message
      const systemMsg = {
        id: `msg${messages.length + 1}`,
        sender_id: "system",
        text: `${currentUser.full_name} marked the campaign as complete.${bothCompleted ? " Both parties have confirmed completion! Payment has been released." : ""}`,
        timestamp: new Date(),
        isSystem: true
      };
      
      setMessages([...messages, systemMsg]);
      
      if (bothCompleted) {
        setShowCompletion(true);
      }
      
    } catch (error) {
      console.error("Error marking campaign as complete:", error);
    }
  };
  
  /**
   * Format timestamp to readable format
   */
  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const today = new Date();
    const isToday = date.toDateString() === today.toDateString();
    
    if (isToday) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' }) + 
           ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }
  
  if (!match || !partner) {
    return (
      <div className="p-4 text-center">
        <p>Conversation not found</p>
        <Button className="mt-4" onClick={() => navigate(createPageUrl("Messages"))}>
          Back to Messages
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Chat Header */}
      <div className="flex items-center p-4 border-b bg-white sticky top-0 z-10">
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => navigate(createPageUrl("Messages"))}
          className="mr-2"
        >
          <ChevronLeft className="h-5 w-5 text-gray-600" />
        </Button>
        
        <Avatar className="h-10 w-10 mr-3">
          <AvatarImage 
            src={partner.profile_picture || partner.logo_url} 
            alt={partner.full_name || partner.company_name} 
          />
          <AvatarFallback>
            {(partner.full_name?.[0] || partner.company_name?.[0] || "?").toUpperCase()}
          </AvatarFallback>
        </Avatar>
        
        <div className="flex-1">
          <h3 className="font-semibold">
            {partner.full_name || partner.company_name}
          </h3>
          <p className="text-xs text-gray-500">
            {campaignState === "not_started" ? "New Match" : 
             campaignState === "proposal" ? "Campaign Proposed" :
             campaignState === "pending_payment" ? "Pending Payment" :
             campaignState === "active" ? "Active Campaign" : "Completed Campaign"}
          </p>
        </div>
        
        {/* Campaign Actions based on state */}
        {campaignState === "not_started" && (
          <Button
            variant="outline"
            className="flex items-center text-purple-600 border-purple-200 hover:bg-purple-50"
            onClick={() => setShowCampaignForm(true)}
          >
            <Rocket className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Launch Campaign</span>
            <span className="inline sm:hidden">Campaign</span>
          </Button>
        )}
        
        {campaignState === "proposal" && !match.campaign_details?.[currentUser.user_type === "influencer" ? "influencer_confirmed" : "brand_confirmed"] && (
          <Button
            variant="outline"
            className="flex items-center text-green-600 border-green-200 hover:bg-green-50"
            onClick={handleAcceptProposal}
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Accept Proposal</span>
            <span className="inline sm:hidden">Accept</span>
          </Button>
        )}
        
        {campaignState === "active" && !match.campaign_details?.[currentUser.user_type === "influencer" ? "influencer_completed" : "brand_completed"] && (
          <Button
            variant="outline"
            className="flex items-center text-green-600 border-green-200 hover:bg-green-50"
            onClick={handleMarkComplete}
          >
            <CheckCircle className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Mark Complete</span>
            <span className="inline sm:hidden">Complete</span>
          </Button>
        )}
      </div>
      
      {/* Campaign Info Banner */}
      {campaignState !== "not_started" && (
        <div className="bg-indigo-50 border-b border-indigo-100 p-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Briefcase className="text-indigo-600 w-4 h-4 mr-2" />
              <span className="font-medium text-indigo-800">
                {campaignData?.title || "Campaign"}
              </span>
            </div>
            <div className="flex items-center space-x-4 text-xs text-indigo-700">
              <span className="flex items-center">
                <DollarSign className="w-3 h-3 mr-1" />
                ${campaignData?.budget || "0"}
              </span>
              <span className="flex items-center">
                <Calendar className="w-3 h-3 mr-1" />
                Due: {campaignData?.deadline || "TBD"}
              </span>
            </div>
          </div>
        </div>
      )}
      
      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div 
            key={msg.id}
            className={`flex ${msg.sender_id === (currentUser.user_type === "influencer" ? match.influencer_id : match.business_id) ? "justify-end" : "justify-start"} ${msg.isSystem ? "justify-center" : ""}`}
          >
            {msg.isSystem ? (
              <div className="bg-gray-100 rounded-lg px-4 py-2 max-w-xs sm:max-w-md text-xs text-center text-gray-600">
                {msg.text}
              </div>
            ) : (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex flex-col ${msg.sender_id === (currentUser.user_type === "influencer" ? match.influencer_id : match.business_id) ? "items-end" : "items-start"}`}
              >
                <div className={`px-4 py-2 rounded-2xl max-w-xs sm:max-w-md ${
                  msg.sender_id === (currentUser.user_type === "influencer" ? match.influencer_id : match.business_id)
                    ? "bg-purple-600 text-white rounded-tr-none"
                    : "bg-white border rounded-tl-none"
                }`}>
                  {msg.text}
                </div>
                <span className="text-xs text-gray-500 mt-1 mx-2">
                  {formatTimestamp(msg.timestamp)}
                </span>
              </motion.div>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      
      {/* Message Input */}
      <div className="p-4 border-t bg-white">
        <form onSubmit={sendMessage} className="flex items-center gap-2">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="text-gray-500"
          >
            <Paperclip className="h-5 w-5" />
          </Button>
          
          <Input
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            className="flex-1 bg-gray-100 border-0"
          />
          
          <Button type="submit" size="icon" variant="ghost" className="text-purple-600">
            <Send className="h-5 w-5" />
          </Button>
        </form>
      </div>
      
      {/* Campaign Form Modal */}
      <AnimatePresence>
        {showCampaignForm && (
          <CampaignForm
            onClose={() => setShowCampaignForm(false)}
            onSubmit={handleCampaignSubmit}
            userType={currentUser.user_type}
          />
        )}
      </AnimatePresence>
      
      {/* Campaign Confirmation Modal */}
      <AnimatePresence>
        {showConfirmation && (
          <CampaignConfirmation
            onClose={() => setShowConfirmation(false)}
            onConfirm={handleCampaignPayment}
            campaignData={campaignData}
            partnerName={partner.full_name || partner.company_name}
          />
        )}
      </AnimatePresence>
      
      {/* Campaign Completion Modal */}
      <AnimatePresence>
        {showCompletion && (
          <CampaignCompletion
            onClose={() => setShowCompletion(false)}
            campaignData={campaignData}
            partnerName={partner.full_name || partner.company_name}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
