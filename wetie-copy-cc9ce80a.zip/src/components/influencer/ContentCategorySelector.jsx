import React from 'react';
import { motion } from 'framer-motion';
import { Badge } from "@/components/ui/badge";

export default function ContentCategorySelector({ selectedCategories, onToggleCategory, editMode }) {
  const categories = [
    { id: 'fashion', icon: '👗', label: 'Fashion' },
    { id: 'beauty', icon: '💄', label: 'Beauty' },
    { id: 'lifestyle', icon: '🌿', label: 'Lifestyle' },
    { id: 'travel', icon: '✈️', label: 'Travel' },
    { id: 'fitness', icon: '💪', label: 'Fitness' },
    { id: 'food', icon: '🍲', label: 'Food' },
    { id: 'tech', icon: '📱', label: 'Tech' },
    { id: 'gaming', icon: '🎮', label: 'Gaming' },
    { id: 'education', icon: '📚', label: 'Education' },
    { id: 'business', icon: '💼', label: 'Business' },
    { id: 'comedy', icon: '😂', label: 'Comedy' },
    { id: 'art', icon: '🎨', label: 'Art' },
    { id: 'music', icon: '🎵', label: 'Music' },
    { id: 'family', icon: '👨‍👩‍👧', label: 'Family' },
    { id: 'sports', icon: '⚽', label: 'Sports' }
  ];

  return (
    <div className="space-y-4">
      {/* Selected categories display */}
      <div className="flex flex-wrap gap-2">
        {selectedCategories?.length > 0 ? (
          selectedCategories.map(categoryId => {
            const category = categories.find(c => c.id === categoryId) || 
                             { id: categoryId, icon: '✨', label: categoryId };
            return (
              <motion.div
                key={category.id}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                layout
              >
                <Badge 
                  className="px-3 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white border-none"
                  variant="default"
                >
                  {category.icon} {category.label}
                  {editMode && (
                    <button 
                      className="ml-2 text-white/80 hover:text-white"
                      onClick={() => onToggleCategory(category.id)}
                    >
                      ×
                    </button>
                  )}
                </Badge>
              </motion.div>
            );
          })
        ) : (
          <div className="text-gray-500 text-sm">
            {editMode ? 'Select categories below' : 'No categories selected'}
          </div>
        )}
      </div>
      
      {/* Category selection grid */}
      {editMode && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
          {categories.map(category => (
            <motion.div
              key={category.id}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Badge
                variant={selectedCategories?.includes(category.id) ? "default" : "outline"}
                className={`w-full justify-center py-2 px-3 cursor-pointer ${
                  selectedCategories?.includes(category.id)
                    ? "bg-purple-100 text-purple-800 hover:bg-purple-200 border-purple-200"
                    : "hover:border-purple-200 hover:bg-purple-50"
                }`}
                onClick={() => onToggleCategory(category.id)}
              >
                <span className="mr-1">{category.icon}</span>
                {category.label}
              </Badge>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}