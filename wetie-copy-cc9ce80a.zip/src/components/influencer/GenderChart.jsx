import React from 'react';
import { Pie, Cell } from 'recharts';

export default function GenderChart({ data }) {
  const chartData = [
    { name: 'Female', value: data.female, color: '#9F7AEA' },
    { name: 'Male', value: data.male, color: '#FEB2B2' }
  ];

  return (
    <div className="flex items-center justify-center gap-8">
      <div className="w-32 h-32">
        <Pie
          data={chartData}
          dataKey="value"
          nameKey="name"
          cx="50%"
          cy="50%"
          outerRadius={60}
          fill="#8884d8"
        >
          {chartData.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={entry.color} />
          ))}
        </Pie>
      </div>
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-[#9F7AEA]" />
          <span>Female {data.female}%</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-[#FEB2B2]" />
          <span>Male {data.male}%</span>
        </div>
      </div>
    </div>
  );
}