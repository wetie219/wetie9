import React from 'react';
import { motion } from 'framer-motion';

export default function ProfileCompletionCircle({ percentage }) {
  // Calculate the circle's circumference
  const radius = 20;
  const circumference = 2 * Math.PI * radius;
  
  // Calculate the dash offset based on percentage
  const dashOffset = circumference - (percentage / 100) * circumference;
  
  // Determine color based on percentage
  const getColor = () => {
    if (percentage < 30) return '#ef4444'; // red
    if (percentage < 70) return '#f59e0b'; // amber
    if (percentage < 100) return '#8b5cf6'; // purple
    return '#10b981'; // green for 100%
  };
  
  return (
    <div className="relative w-14 h-14 flex items-center justify-center">
      {/* Background Circle */}
      <svg width="46" height="46" viewBox="0 0 46 46" className="absolute">
        <circle
          cx="23"
          cy="23"
          r={radius}
          fill="none"
          stroke="#e5e7eb"
          strokeWidth="4"
        />
      </svg>
      
      {/* Progress Circle */}
      <motion.svg 
        width="46" 
        height="46" 
        viewBox="0 0 46 46" 
        className="absolute"
        initial={{ rotate: -90 }}
        animate={{ 
          rotate: -90,
        }}
      >
        <motion.circle
          cx="23"
          cy="23"
          r={radius}
          fill="none"
          stroke={getColor()}
          strokeWidth="4"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: dashOffset }}
          transition={{ duration: 1, ease: "easeOut" }}
          strokeLinecap="round"
        />
      </motion.svg>
      
      {/* Percentage Text */}
      <motion.div 
        className="text-sm font-semibold z-10"
        initial={{ scale: 0.8 }}
        animate={{ scale: 1 }}
        transition={{ delay: 0.5 }}
      >
        {percentage}%
      </motion.div>
    </div>
  );
}