import React from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Users, MapPin } from "lucide-react";

export default function AudienceInsights({ stats }) {
  const genderData = [
    { label: 'Female', value: stats?.instagram?.gender_split?.female || 0 },
    { label: 'Male', value: stats?.instagram?.gender_split?.male || 0 }
  ];

  const ageGroups = [
    { label: '13-17', value: stats?.instagram?.age_distribution?.['13-17'] || 0 },
    { label: '18-24', value: stats?.instagram?.age_distribution?.['18-24'] || 0 },
    { label: '25-34', value: stats?.instagram?.age_distribution?.['25-34'] || 0 },
    { label: '35-44', value: stats?.instagram?.age_distribution?.['35-44'] || 0 },
    { label: '45+', value: stats?.instagram?.age_distribution?.['45-plus'] || 0 }
  ];

  return (
    <Card className="p-6">
      <h2 className="text-lg font-semibold mb-6">Audience Insights</h2>
      
      <div className="grid md:grid-cols-2 gap-8">
        {/* Gender Distribution */}
        <div>
          <h3 className="text-sm font-medium mb-4 flex items-center gap-2">
            <Users className="w-4 h-4" />
            Gender Split
          </h3>
          <div className="space-y-4">
            {genderData.map(item => (
              <div key={item.label}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm text-gray-600">{item.label}</span>
                  <span className="text-sm font-medium">{item.value}%</span>
                </div>
                <Progress value={item.value} />
              </div>
            ))}
          </div>
        </div>

        {/* Age Distribution */}
        <div>
          <h3 className="text-sm font-medium mb-4">Age Groups</h3>
          <div className="space-y-4">
            {ageGroups.map(item => (
              <div key={item.label}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm text-gray-600">{item.label}</span>
                  <span className="text-sm font-medium">{item.value}%</span>
                </div>
                <Progress value={item.value} />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top Locations */}
      <div className="mt-8">
        <h3 className="text-sm font-medium mb-4 flex items-center gap-2">
          <MapPin className="w-4 h-4" />
          Top Locations
        </h3>
        <div className="flex flex-wrap gap-2">
          {stats?.instagram?.top_locations?.map((location, index) => (
            <Badge key={index} variant="secondary" className="px-3 py-1">
              {location.city || location.country} ({location.percentage}%)
            </Badge>
          ))}
        </div>
      </div>

      <div className="mt-6 text-xs text-gray-500 flex items-center gap-2">
        <span>Last updated via Instagram API</span>
        <span>•</span>
        <span>{new Date(stats?.last_updated).toLocaleDateString()}</span>
      </div>
    </Card>
  );
}