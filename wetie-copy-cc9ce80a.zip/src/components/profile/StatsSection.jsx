import React from 'react';
import { Card } from "@/components/ui/card";
import { 
  Users, 
  TrendingUp, 
  Eye, 
  Activity,
  RefreshCcw
} from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export default function StatsSection({ stats }) {
  const statItems = [
    {
      icon: Users,
      label: "Followers",
      value: stats?.instagram?.followers || 0,
      format: (val) => (val / 1000).toFixed(1) + "K"
    },
    {
      icon: Activity,
      label: "Engagement",
      value: stats?.instagram?.engagement_rate || 0,
      format: (val) => val.toFixed(1) + "%"
    },
    {
      icon: Eye,
      label: "Avg. Story Views",
      value: stats?.instagram?.reach || 0,
      format: (val) => (val / 1000).toFixed(1) + "K"
    },
    {
      icon: TrendingUp,
      label: "30-Day Reach",
      value: stats?.instagram?.reach || 0,
      format: (val) => (val / 1000).toFixed(1) + "K"
    }
  ];

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold">Performance Stats</h2>
        <Button variant="outline" size="sm" className="gap-2">
          <RefreshCcw className="w-4 h-4" />
          Refresh Stats
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {statItems.map((item, index) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-gray-50 rounded-xl p-4"
          >
            <div className="flex items-center gap-2 mb-2 text-gray-600">
              <item.icon className="w-4 h-4" />
              <span className="text-sm">{item.label}</span>
            </div>
            <div className="text-2xl font-bold">
              {item.format(item.value)}
            </div>
          </motion.div>
        ))}
      </div>
    </Card>
  );
}