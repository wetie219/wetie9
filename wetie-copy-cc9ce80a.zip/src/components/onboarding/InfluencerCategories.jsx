import React from "react";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { X } from "lucide-react";

export default function InfluencerCategories({ formData, updateFormData }) {
  const categories = [
    "Fashion", "Beauty", "Lifestyle", "Travel", "Fitness", 
    "Food", "Technology", "Gaming", "Business", "Art", 
    "Education", "Parenting", "Health", "DIY", "Music"
  ];
  
  const handleToggleCategory = (category) => {
    const currentNiche = formData.niche || [];
    
    if (currentNiche.includes(category)) {
      updateFormData({ 
        niche: currentNiche.filter(item => item !== category) 
      });
    } else {
      // Limit to 5 categories
      if (currentNiche.length < 5) {
        updateFormData({ 
          niche: [...currentNiche, category] 
        });
      }
    }
  };
  
  const removeCategory = (category) => {
    const currentNiche = formData.niche || [];
    updateFormData({ 
      niche: currentNiche.filter(item => item !== category) 
    });
  };
  
  return (
    <div>
      <h2 className="text-2xl font-bold text-center mb-2">Your Content Categories</h2>
      <p className="text-gray-600 text-center mb-8">
        Select up to 5 categories that best describe your content
      </p>
      
      {/* Selected categories */}
      <div className="mb-6">
        <Label>Selected Categories</Label>
        <div className="flex flex-wrap gap-2 mt-2 min-h-12 p-2 bg-gray-50 rounded-md">
          {(formData.niche || []).length === 0 ? (
            <p className="text-gray-400 text-sm">No categories selected</p>
          ) : (
            (formData.niche || []).map(category => (
              <Badge 
                key={category}
                className="bg-[#2F2C7F] hover:bg-[#23216d] flex items-center gap-1"
              >
                {category}
                <button 
                  onClick={() => removeCategory(category)}
                  className="ml-1 rounded-full hover:bg-white/20 p-0.5"
                >
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))
          )}
        </div>
        <p className="text-xs text-gray-500 mt-1">
          {(formData.niche || []).length}/5 categories selected
        </p>
      </div>
      
      {/* Category selection */}
      <div>
        <Label>Available Categories</Label>
        <div className="grid grid-cols-2 gap-2 mt-2">
          {categories.map(category => (
            <div 
              key={category} 
              className="flex items-center space-x-2"
            >
              <Checkbox 
                id={`category-${category}`}
                checked={(formData.niche || []).includes(category)}
                onCheckedChange={() => handleToggleCategory(category)}
                disabled={(formData.niche || []).length >= 5 && !(formData.niche || []).includes(category)}
              />
              <Label 
                htmlFor={`category-${category}`}
                className="text-sm font-normal cursor-pointer"
              >
                {category}
              </Label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}