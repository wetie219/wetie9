
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Match } from "@/api/entities";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Heart,
  Package,
  TrendingUp,
  DollarSign,
  ChevronRight,
  Star,
  Bell,
  Rocket,
  Sparkles
} from "lucide-react";
import QuickStatsCard from "../components/dashboard/QuickStatsCard";
import CampaignRequest from "../components/dashboard/CampaignRequest";
import MatchRequestPreview from "../components/dashboard/MatchRequestPreview";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function InfluencerDashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [stats, setStats] = useState({
    pendingRequests: 0,
    activeCampaigns: 0,
    completedCampaigns: 0,
    totalEarnings: 0
  });
  const [loading, setLoading] = useState(true);
  const [campaignRequests, setCampaignRequests] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      // Load matches/campaign data with updated status filtering
      const matches = await Match.list();
      
      // Calculate stats with new status logic
      const pendingRequests = matches.filter(m => 
        m.status === "campaign_negotiation" || m.status === "campaign_pending"
      ).length;
      
      const activeCampaigns = matches.filter(m => 
        m.status === "campaign_active"
      ).length;
      
      const completedCampaigns = matches.filter(m => 
        m.status === "campaign_completed"
      ).length;
      
      const totalEarnings = matches
        .filter(m => m.status === "campaign_completed")
        .reduce((sum, m) => sum + (m.campaign_details?.total_amount || 0), 0);

      setStats({
        pendingRequests,
        activeCampaigns,
        completedCampaigns,
        totalEarnings
      });

      // Get recent campaign requests
      const recentRequests = matches
        .filter(m => m.status === "campaign_negotiation" || m.status === "campaign_pending")
        .slice(0, 3);
      setCampaignRequests(recentRequests);

    } catch (error) {
      console.error("Error loading dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAFA]">
      {/* Top Welcome Section */}
      <div className="bg-white border-b">
        <div className="px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <motion.div 
                className="relative"
                whileHover={{ scale: 1.05 }}
              >
                <div className="w-14 h-14 rounded-full overflow-hidden ring-2 ring-purple-100">
                  <img 
                    src={user.profile_picture || "https://images.unsplash.com/photo-1494790108377-be9c29b29330"} 
                    alt={user.full_name}
                    className="w-full h-full object-cover"
                  />
                </div>
                {user.status === "verified" && (
                  <Badge 
                    className="absolute -bottom-1 -right-1 bg-gradient-to-r from-[#2A0845] to-[#C625FF] text-white"
                  >
                    <Star className="w-3 h-3" />
                  </Badge>
                )}
              </motion.div>
              
              <div>
                <motion.h1 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-2xl font-bold text-gray-900"
                >
                  👋 Welcome back, {user.full_name?.split(' ')[0]}
                </motion.h1>
                <p className="text-gray-500">@{user.username || user.full_name?.toLowerCase().replace(' ', '')}</p>
              </div>
            </div>

            <Button 
              variant="ghost" 
              size="icon" 
              className="rounded-full hover:bg-purple-50"
            >
              <Bell className="w-5 h-5 text-gray-600" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-4 py-6 space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          <QuickStatsCard
            title="Pending Requests"
            value={stats.pendingRequests}
            icon={Heart}
            trend="+12%"
            trendDir="up"
            color="rose"
            type="pending"
          />
          <QuickStatsCard
            title="Active Campaigns"
            value={stats.activeCampaigns}
            icon={Package}
            trend="+5%"
            trendDir="up"
            color="blue"
            type="active"
          />
          <QuickStatsCard
            title="Completed"
            value={stats.completedCampaigns}
            icon={TrendingUp}
            trendDir="up"
            trend="+18%"
            color="emerald"
            type="completed"
          />
          <QuickStatsCard
            title="Total Earnings"
            value={`$${stats.totalEarnings.toLocaleString()}`}
            icon={DollarSign}
            trend="+25%"
            trendDir="up"
            color="violet"
          />
        </div>

        {/* Match Requests Preview Card */}
        <MatchRequestPreview />

        {/* CTA Card */}
        <motion.div
          whileHover={{ scale: 1.01 }}
          className="bg-gradient-to-r from-[#2A0845] to-[#C625FF] rounded-2xl p-6 text-white"
        >
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-xl font-semibold mb-2">Want to get more collaborations?</h2>
              <p className="text-white/80 mb-4">Discover brands looking for creators like you</p>
              <Button 
                className="bg-white text-[#2A0845] hover:bg-white/90"
                onClick={() => navigate(createPageUrl("Discover"))}
              >
                <Rocket className="w-4 h-4 mr-2" />
                Apply to Campaigns
              </Button>
            </div>
            <Sparkles className="w-12 h-12 text-white/20" />
          </div>
        </motion.div>

        {/* Recent Campaign Requests */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Recent Requests</h2>
            <Button 
              variant="ghost" 
              className="text-sm text-purple-600 hover:text-purple-700"
              onClick={() => navigate(createPageUrl("Campaigns"))}
            >
              View All
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>

          <AnimatePresence>
            <div className="space-y-3">
              {campaignRequests.length > 0 ? (
                campaignRequests.map((request) => (
                  <CampaignRequest key={request.id} request={request} />
                ))
              ) : (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center py-8 bg-white rounded-xl border border-dashed border-gray-200"
                >
                  <div className="w-12 h-12 mx-auto mb-3 bg-purple-100 rounded-full flex items-center justify-center">
                    <Bell className="w-6 h-6 text-purple-600" />
                  </div>
                  <h3 className="text-gray-900 font-medium mb-1">No Requests Yet</h3>
                  <p className="text-gray-500 text-sm">
                    New campaign requests will appear here
                  </p>
                </motion.div>
              )}
            </div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
