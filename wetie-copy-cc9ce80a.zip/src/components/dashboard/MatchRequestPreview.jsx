import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Match } from "@/api/entities";
import { Business } from "@/api/entities";
import { User } from "@/api/entities";

export default function MatchRequestPreview() {
  const navigate = useNavigate();
  const [matchRequests, setMatchRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newMatchCount, setNewMatchCount] = useState(0);

  useEffect(() => {
    loadMatchRequests();
  }, []);

  const loadMatchRequests = async () => {
    try {
      const user = await User.me();
      
      // Get match requests with pending status
      const matchData = await Match.filter({
        influencer_id: user.id,
        status: "pending_match"
      });

      // Load business details for the first 3 matches
      const matchesWithBusinesses = await Promise.all(
        matchData.slice(0, 3).map(async (match) => {
          try {
            const business = await Business.get(match.business_id);
            return {
              ...match,
              business
            };
          } catch (error) {
            console.error(`Error loading business for match ${match.id}:`, error);
            return {
              ...match,
              business: { company_name: "Unknown Brand" }
            };
          }
        })
      );

      setMatchRequests(matchesWithBusinesses);
      setNewMatchCount(matchData.length);
    } catch (error) {
      console.error("Error loading match requests:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="p-4 border-dashed border-purple-200">
        <div className="flex items-center justify-center h-20">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-purple-600"></div>
        </div>
      </Card>
    );
  }

  if (newMatchCount === 0) {
    return null; // Don't show the card if there are no match requests
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="relative overflow-hidden"
    >
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-100 hover:border-purple-200 transition-all duration-300">
        <div className="p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <motion.div
                animate={{ 
                  scale: [1, 1.2, 1],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  repeatType: "reverse"
                }}
              >
                <Sparkles className="w-5 h-5 text-purple-600" />
              </motion.div>
              <h3 className="font-semibold text-lg text-gray-900">Match Requests</h3>
              <Badge className="bg-purple-600 text-white ml-1">
                {newMatchCount} New
              </Badge>
            </div>
            
            <Button
              variant="ghost"
              size="sm"
              className="text-purple-700 hover:text-purple-800 -mr-2"
              onClick={() => navigate(createPageUrl("MatchRequests"))}
            >
              View All
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
          
          <div className="space-y-3">
            <AnimatePresence>
              {matchRequests.map((match, index) => (
                <motion.div 
                  key={match.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                  className="flex items-center gap-3 bg-white p-3 rounded-lg hover:shadow-sm cursor-pointer"
                  onClick={() => navigate(createPageUrl("MatchRequests"))}
                >
                  <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center overflow-hidden border border-purple-200">
                    {match.business?.logo_url ? (
                      <img 
                        src={match.business.logo_url} 
                        alt={match.business.company_name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="font-medium text-purple-700">
                        {match.business?.company_name?.charAt(0) || "B"}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-gray-900 truncate">
                      {match.business?.company_name}
                    </div>
                    <div className="text-xs text-gray-500 truncate">
                      {match.business?.industry ? (
                        match.business.industry.charAt(0).toUpperCase() + match.business.industry.slice(1)
                      ) : (
                        "Brand Match"
                      )}
                    </div>
                  </div>
                  
                  {match.match_percentage && (
                    <Badge variant="outline" className="bg-purple-50 border-purple-200 text-purple-800">
                      {match.match_percentage}% Match
                    </Badge>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </Card>
      
      {/* Animated glow effect */}
      <motion.div 
        className="absolute -inset-1 bg-gradient-to-r from-purple-400 to-pink-400 rounded-xl blur opacity-20 -z-10"
        animate={{ 
          opacity: [0.15, 0.3, 0.15],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          repeatType: "reverse"
        }}
      />
    </motion.div>
  );
}