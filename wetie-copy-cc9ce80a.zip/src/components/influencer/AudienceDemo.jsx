import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Lock } from "lucide-react";

export default function AudienceDemo({ audienceData, isPrivate }) {
  const formatPercentage = (value) => {
    return `${Math.round(value)}%`;
  };

  if (isPrivate) {
    return (
      <Card className="relative overflow-hidden">
        <CardContent className="p-6 flex items-center justify-center min-h-[200px] text-center">
          <div className="space-y-2">
            <Lock className="w-12 h-12 text-gray-300 mx-auto" />
            <h3 className="text-xl font-medium text-gray-500">Audience Data Private</h3>
            <p className="text-gray-400 text-sm">
              The creator has set their audience demographics to private
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2">
      {/* Gender Split */}
      <Card>
        <CardContent className="p-6">
          <h3 className="text-lg font-medium mb-4">Gender Split</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-pink-500"></div>
                <span>Female</span>
              </div>
              <span className="font-medium">{formatPercentage(audienceData.gender_split?.female || 0)}</span>
            </div>
            
            <Progress value={audienceData.gender_split?.female || 0} className="h-2 bg-gray-100" indicatorClassName="bg-pink-500" />
            
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                <span>Male</span>
              </div>
              <span className="font-medium">{formatPercentage(audienceData.gender_split?.male || 0)}</span>
            </div>
            
            <Progress value={audienceData.gender_split?.male || 0} className="h-2 bg-gray-100" indicatorClassName="bg-blue-500" />
          </div>
        </CardContent>
      </Card>
      
      {/* Age Distribution */}
      <Card>
        <CardContent className="p-6">
          <h3 className="text-lg font-medium mb-4">Age Groups</h3>
          
          <div className="space-y-3">
            {Object.entries(audienceData.age_distribution || {}).map(([ageGroup, percentage]) => (
              <div key={ageGroup} className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span>{ageGroup.replace('_', '-')}</span>
                  <span className="font-medium">{formatPercentage(percentage)}</span>
                </div>
                <Progress 
                  value={percentage} 
                  className="h-2 bg-gray-100" 
                  indicatorClassName="bg-gradient-to-r from-purple-600 to-pink-600" 
                />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      {/* Top Locations */}
      <Card className="md:col-span-2">
        <CardContent className="p-6">
          <h3 className="text-lg font-medium mb-4">Top Locations</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {(audienceData.top_locations || []).slice(0, 3).map((location, index) => (
              <div key={index} className="flex flex-col items-center p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl mb-1">
                  {getCountryFlag(location.country)}
                </div>
                <div className="font-medium">{location.country}</div>
                <div className="text-sm text-gray-500">{formatPercentage(location.percentage)}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Helper function to get country emoji flags
function getCountryFlag(countryName) {
  const countryFlags = {
    'Qatar': '🇶🇦',
    'UAE': '🇦🇪',
    'United States': '🇺🇸',
    'United Kingdom': '🇬🇧',
    'Saudi Arabia': '🇸🇦',
    'India': '🇮🇳',
    'Canada': '🇨🇦',
    'Australia': '🇦🇺',
    'France': '🇫🇷',
    'Germany': '🇩🇪',
    'Japan': '🇯🇵',
    // Default flag if country not found
    'default': '🌎'
  };
  
  return countryFlags[countryName] || countryFlags['default'];
}