// ... keep existing code
import { Save, XCircle, CheckCircle } from "lucide-react";

// ... keep existing code (but change Save icon to CheckCircle in the button)
        <Button
          onClick={() => onSave({ ...editedData, total_amount: calculateTotal() })}
          disabled={isProcessing}
          className="bg-green-600 hover:bg-green-700 flex items-center gap-2"
        >
          <CheckCircle className="w-4 h-4" /> Save Invoice
        </Button>
// ... keep existing code