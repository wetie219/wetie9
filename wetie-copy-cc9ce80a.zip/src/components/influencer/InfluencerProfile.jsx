import React, { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Cake, Instagram, Users, Globe, Building2 } from "lucide-react";
import { motion } from "framer-motion";
import StatsCard from './StatsCard';
import GenderChart from './GenderChart';
import AudienceStats from './AudienceStats';
import MatchScore from './MatchScore';

export default function InfluencerProfile({ influencer }) {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="min-h-screen bg-[#F8F8FF] pb-24">
      {/* Header Section */}
      <div className="relative h-[300px]">
        <div className="absolute inset-0 grid grid-cols-2 gap-2 p-4">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="h-full rounded-2xl overflow-hidden shadow-lg"
          >
            <img 
              src={influencer.profile_picture} 
              alt={influencer.full_name}
              className="w-full h-full object-cover"
            />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="h-full rounded-2xl overflow-hidden shadow-lg"
          >
            <img 
              src={influencer.profile_picture_secondary || influencer.profile_picture} 
              alt={influencer.full_name}
              className="w-full h-full object-cover"
            />
          </motion.div>
        </div>
        
        {/* Match Score Overlay */}
        <div className="absolute top-4 right-4">
          <MatchScore percentage={influencer.matchPercentage} />
        </div>
      </div>

      {/* Profile Info Section */}
      <div className="px-4 -mt-6 relative z-10">
        <Card className="rounded-3xl shadow-lg">
          <CardContent className="p-6 space-y-6">
            {/* Basic Info */}
            <div>
              <h1 className="text-2xl font-bold mb-2">{influencer.full_name}</h1>
              <div className="flex items-center gap-4 text-gray-600">
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  <span>{influencer.location || "Doha"}</span>
                </div>
                {influencer.age && (
                  <div className="flex items-center gap-1">
                    <Cake className="w-4 h-4" />
                    <span>{influencer.age} years</span>
                  </div>
                )}
              </div>
            </div>

            {/* Bio */}
            <p className="text-gray-700 font-[Inter] leading-relaxed">
              {influencer.bio}
            </p>

            {/* Instagram Stats */}
            <div className="pt-4">
              <h3 className="text-center text-lg font-semibold mb-4">Account Reach</h3>
              <div className="flex items-center justify-between bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-xl">
                <div className="flex items-center gap-2">
                  <Instagram className="w-5 h-5 text-pink-600" />
                  <span className="font-medium">{influencer.platforms?.instagram?.handle}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Users className="w-4 h-4 text-gray-600" />
                  <span className="font-bold">
                    {(influencer.platforms?.instagram?.followers / 1000).toFixed(1)}K
                  </span>
                </div>
              </div>
            </div>

            {/* Gender Distribution */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Audience Gender</h3>
              <GenderChart 
                data={{
                  female: influencer.audience?.gender?.female || 23,
                  male: influencer.audience?.gender?.male || 77
                }}
              />
            </div>

            {/* Content Categories */}
            <div>
              <h3 className="text-lg font-semibold mb-3">Content Categories</h3>
              <div className="flex flex-wrap gap-2">
                {influencer.niche?.map((category, index) => (
                  <Badge 
                    key={index}
                    variant="secondary" 
                    className="px-3 py-1 bg-gradient-to-r from-purple-100 to-pink-100"
                  >
                    {category}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Top Countries */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Top Countries</h3>
              <div className="space-y-3">
                {influencer.audience?.countries?.slice(0, 3).map((country, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Globe className="w-4 h-4 text-gray-600" />
                      <span>{country.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-32 h-2 rounded-full bg-gradient-to-r from-purple-200 to-pink-200">
                        <div 
                          className="h-full rounded-full bg-gradient-to-r from-purple-500 to-pink-500"
                          style={{ width: `${country.percentage}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium w-12 text-right">
                        {country.percentage}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Top Cities */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Top Cities</h3>
              <div className="space-y-3">
                {influencer.audience?.cities?.slice(0, 3).map((city, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-gray-600" />
                      <span>{city.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-32 h-2 rounded-full bg-gradient-to-r from-purple-200 to-pink-200">
                        <div 
                          className="h-full rounded-full bg-gradient-to-r from-purple-500 to-pink-500"
                          style={{ width: `${city.percentage}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium w-12 text-right">
                        {city.percentage}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Age Groups */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Age Groups</h3>
              <div className="space-y-3">
                {influencer.audience?.age_groups?.map((group, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span>{group.range}</span>
                    <div className="flex items-center gap-2">
                      <div className="w-32 h-2 rounded-full bg-gradient-to-r from-purple-200 to-pink-200">
                        <div 
                          className="h-full rounded-full bg-gradient-to-r from-purple-500 to-pink-500"
                          style={{ width: `${group.percentage}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium w-12 text-right">
                        {group.percentage}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}