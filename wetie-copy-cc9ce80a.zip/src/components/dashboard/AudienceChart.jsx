import React from "react";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, ResponsiveContainer } from "recharts";

const GENDER_COLORS = ["#C625FF", "#2A0845"];
const AGE_COLORS = ["#FFB6C1", "#C625FF", "#9370DB", "#6A5ACD", "#483D8B"];

export default function AudienceChart({ genderData, ageData }) {
  // Format gender data for pie chart
  const genderChartData = [
    { name: "Female", value: genderData.female },
    { name: "Male", value: genderData.male }
  ];

  // Format age data for bar chart
  const ageChartData = [
    { name: "13-17", value: ageData["13_17"] },
    { name: "18-24", value: ageData["18_24"] },
    { name: "25-34", value: ageData["25_34"] },
    { name: "35-44", value: ageData["35_44"] },
    { name: "45+", value: ageData["45_plus"] }
  ];

  return (
    <div className="space-y-8">
      {/* Gender Distribution */}
      <div>
        <h3 className="text-sm font-medium text-gray-700 mb-4">Gender Split</h3>
        <div className="flex items-center">
          <div className="w-32 h-32">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={genderChartData}
                  innerRadius={25}
                  outerRadius={40}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {genderChartData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={GENDER_COLORS[index % GENDER_COLORS.length]}
                    />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          <div className="flex-1 ml-4">
            <div className="space-y-2">
              {genderChartData.map((entry, index) => (
                <div key={entry.name} className="flex items-center">
                  <div 
                    className="w-3 h-3 rounded-full mr-2"
                    style={{ backgroundColor: GENDER_COLORS[index] }}
                  />
                  <span className="text-sm text-gray-600">{entry.name}</span>
                  <span className="ml-auto font-medium">{entry.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Age Distribution */}
      <div>
        <h3 className="text-sm font-medium text-gray-700 mb-4">Age Groups</h3>
        <div className="h-40">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={ageChartData}>
              <XAxis 
                dataKey="name" 
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 12, fill: '#6B7280' }}
              />
              <YAxis 
                hide={true}
                domain={[0, 100]}
              />
              <Bar 
                dataKey="value" 
                radius={[4, 4, 0, 0]}
              >
                {ageChartData.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`}
                    fill={AGE_COLORS[index % AGE_COLORS.length]}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}