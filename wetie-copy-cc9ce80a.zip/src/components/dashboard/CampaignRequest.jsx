
import React from "react";
import { Button } from "@/components/ui/button";
import { ChevronRight } from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";

export default function CampaignRequest({ request }) {

  // Add status indicator based on campaign state
  const getStatusIndicator = (request) => {
    if (request.status === "campaign_negotiation") {
      return (
        <Badge className="bg-blue-100 text-blue-700">
          In Discussion
        </Badge>
      );
    }
    if (request.status === "campaign_pending") {
      if (request.campaign_details?.brief_status === "waiting_for_brief") {
        return (
          <Badge className="bg-amber-100 text-amber-700">
            Awaiting Brief
          </Badge>
        );
      }
      if (request.campaign_details?.brief_status === "brief_sent") {
        return (
          <Badge className="bg-green-100 text-green-700">
            Brief Received
          </Badge>
        );
      }
    }
    return null;
  };

  return (
    <motion.div
      whileHover={{ scale: 1.01, y: -1 }}
      whileTap={{ scale: 0.99 }}
      className="p-4 rounded-xl bg-white border border-gray-100 hover:border-purple-100 hover:shadow-sm transition-all duration-300"
    >
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-full bg-gray-50 flex items-center justify-center overflow-hidden border border-gray-100">
          <img 
            src={request.business?.logo_url || "https://via.placeholder.com/40"} 
            alt={request.business?.company_name}
            className="w-8 h-8 object-contain"
          />
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-medium text-gray-900 truncate">
              {request.business?.company_name || "Brand Name"}
            </h3>
            {getStatusIndicator(request)}
          </div>
          <p className="text-sm text-gray-500 truncate">
            {request.campaign_details?.content_type || "Content Creation"} Campaign
          </p>
        </div>

        <Button 
          variant="ghost" 
          size="icon"
          className="text-gray-400 hover:text-purple-600 hover:bg-purple-50"
        >
          <ChevronRight className="w-5 h-5" />
        </Button>
      </div>
    </motion.div>
  );
}
