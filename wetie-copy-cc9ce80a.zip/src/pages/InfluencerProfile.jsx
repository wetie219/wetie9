import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Influencer } from "@/api/entities";
import { InfluencerStats } from "@/api/entities";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  Star,
  MapPin,
  Instagram,
  Youtube,
  Music as TikTok,
  CheckCircle2,
  Link2,
  Share2,
  Eye,
  Upload,
  Settings,
  Copy,
  ExternalLink,
  Lock,
  Grid,
  BarChart3,
  Camera,
  ChevronRight,
  Users,
  TrendingUp,
  Award,
  Sparkles,
  Globe,
  CalendarDays
} from "lucide-react";
import { UploadFile } from "@/api/integrations";

// Import sub-components
import InfluencerHeader from "../components/influencer/InfluencerHeader";
import PlatformConnector from "../components/influencer/PlatformConnector";
import StatisticsCard from "../components/influencer/StatisticsCard";
import AudienceDemo from "../components/influencer/AudienceDemo";
import ContentCategorySelector from "../components/influencer/ContentCategorySelector";
import CompletionRing from "../components/influencer/CompletionRing";
import PortfolioSection from "../components/influencer/PortfolioSection";

export default function InfluencerProfile() {
  const [user, setUser] = useState(null);
  const [influencer, setInfluencer] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editMode, setEditMode] = useState(true);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  
  // Form state - specifically for influencers
  const [formData, setFormData] = useState({
    full_name: "",
    username: "",
    bio: "",
    tagline: "",
    location: "",
    profile_picture: "",
    niche: [],
    languages: [],
    portfolio_url: "",
    platforms: {
      instagram: { handle: "", connected: false },
      tiktok: { handle: "", connected: false },
      youtube: { handle: "", connected: false }
    },
    portfolio_items: []
  });
  
  // Privacy settings
  const [privacySettings, setPrivacySettings] = useState({
    showStats: true,
    showAudience: true,
    showPortfolio: true
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      // Load influencer profile
      const influencerList = await Influencer.filter({ user_id: userData.id });
      if (influencerList.length > 0) {
        const influencerData = influencerList[0];
        setInfluencer(influencerData);
        
        // Set form data
        setFormData({
          full_name: influencerData.full_name || "",
          username: influencerData.username || userData.full_name?.split(' ')[0]?.toLowerCase() || "",
          bio: influencerData.bio || "",
          tagline: influencerData.tagline || "",
          location: influencerData.location || "",
          profile_picture: influencerData.profile_picture || "",
          niche: influencerData.niche || [],
          languages: influencerData.languages || [],
          portfolio_url: influencerData.portfolio_url || "",
          platforms: influencerData.platforms || {
            instagram: { handle: "", connected: false },
            tiktok: { handle: "", connected: false },
            youtube: { handle: "", connected: false }
          },
          portfolio_items: influencerData.portfolio_items || []
        });

        // Load stats if available
        const statsList = await InfluencerStats.filter({ influencer_id: influencerData.id });
        if (statsList.length > 0) {
          setStats(statsList[0]);
          
          // Update connected status based on stats
          setFormData(prev => ({
            ...prev,
            platforms: {
              instagram: { 
                ...prev.platforms.instagram, 
                connected: statsList[0].instagram?.connected || false
              },
              tiktok: { 
                ...prev.platforms.tiktok, 
                connected: statsList[0].tiktok?.connected || false
              },
              youtube: { 
                ...prev.platforms.youtube, 
                connected: statsList[0].youtube?.connected || false
              }
            }
          }));
        }
      }
    } catch (error) {
      console.error("Error loading profile data:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handlePlatformChange = (platform, handle) => {
    setFormData(prev => ({
      ...prev,
      platforms: {
        ...prev.platforms,
        [platform]: {
          ...prev.platforms[platform],
          handle
        }
      }
    }));
  };

  const handleNicheToggle = (category) => {
    setFormData(prev => {
      const currentNiche = prev.niche || [];
      if (currentNiche.includes(category)) {
        return {
          ...prev,
          niche: currentNiche.filter(item => item !== category)
        };
      } else {
        // Limit to 5 categories
        if (currentNiche.length < 5) {
          return {
            ...prev,
            niche: [...currentNiche, category]
          };
        }
        return prev;
      }
    });
  };

  const handleProfilePictureUpload = async (file) => {
    try {
      setUploadingImage(true);
      setUploadProgress(0);
      
      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => Math.min(prev + 10, 90));
      }, 200);
      
      const result = await UploadFile({ file });
      clearInterval(progressInterval);
      setUploadProgress(100);
      
      setFormData(prev => ({
        ...prev,
        profile_picture: result.file_url
      }));
      
      setTimeout(() => {
        setUploadProgress(0);
        setUploadingImage(false);
      }, 500);
    } catch (error) {
      console.error("Error uploading profile picture:", error);
      setUploadingImage(false);
    }
  };

  const handlePortfolioItemUpload = async (file) => {
    try {
      setUploadingImage(true);
      setUploadProgress(0);
      
      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => Math.min(prev + 10, 90));
      }, 200);
      
      const result = await UploadFile({ file });
      clearInterval(progressInterval);
      setUploadProgress(100);
      
      // Add new portfolio item
      setFormData(prev => ({
        ...prev,
        portfolio_items: [
          ...prev.portfolio_items,
          {
            image_url: result.file_url,
            title: "",
            description: "",
            created_date: new Date().toISOString()
          }
        ]
      }));
      
      setTimeout(() => {
        setUploadProgress(0);
        setUploadingImage(false);
      }, 500);
    } catch (error) {
      console.error("Error uploading portfolio item:", error);
      setUploadingImage(false);
    }
  };

  const handleSaveProfile = async () => {
    try {
      setSaving(true);
      
      if (influencer) {
        await Influencer.update(influencer.id, formData);
      } else {
        await Influencer.create({
          ...formData,
          user_id: user.id
        });
      }
      
      // Reload data
      await loadData();
      setEditMode(false);
    } catch (error) {
      console.error("Error saving profile:", error);
    } finally {
      setSaving(false);
    }
  };

  const calculateCompletionPercentage = () => {
    const requiredFields = [
      'full_name',
      'bio',
      'location',
      'profile_picture',
      'niche'
    ];
    
    const platformFields = [
      'platforms.instagram.handle'
    ];
    
    // Check required fields (70% weight)
    const requiredCompleted = requiredFields.filter(field => {
      const value = field.includes('.') 
        ? formData[field.split('.')[0]]?.[field.split('.')[1]]
        : formData[field];
      return value && (Array.isArray(value) ? value.length > 0 : true);
    }).length;
    
    // Check platform fields (30% weight)
    const platformsCompleted = platformFields.filter(field => {
      const [parent, child, subChild] = field.split('.');
      return formData[parent]?.[child]?.[subChild];
    }).length;
    
    const requiredPercentage = (requiredCompleted / requiredFields.length) * 70;
    const platformPercentage = (platformsCompleted / platformFields.length) * 30;
    
    return Math.round(requiredPercentage + platformPercentage);
  };

  const connectInstagram = () => {
    // Simulate connecting to Instagram API
    setFormData(prev => ({
      ...prev,
      platforms: {
        ...prev.platforms,
        instagram: {
          ...prev.platforms.instagram,
          connected: true
        }
      }
    }));

    // In real implementation, this would redirect to an Instagram oAuth flow
    alert("In a real implementation, this would redirect to Instagram's API authentication flow.");
  };

  const connectTikTok = () => {
    // Simulate connecting to TikTok API
    setFormData(prev => ({
      ...prev,
      platforms: {
        ...prev.platforms,
        tiktok: {
          ...prev.platforms.tiktok,
          connected: true
        }
      }
    }));

    // In real implementation, this would redirect to a TikTok oAuth flow
    alert("In a real implementation, this would redirect to TikTok's API authentication flow.");
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      {/* Floating profile completion indicator */}
      <div className="fixed top-4 right-4 z-50">
        <CompletionRing percentage={calculateCompletionPercentage()} />
      </div>
      
      {/* Edit/Preview toggle */}
      <div className="fixed top-4 left-4 z-50">
        <Button
          size="sm"
          variant="ghost"
          className="bg-white shadow-sm rounded-full px-4"
          onClick={() => setEditMode(!editMode)}
        >
          {editMode ? (
            <>
              <Eye className="w-4 h-4 mr-2" />
              Preview
            </>
          ) : (
            <>
              <Settings className="w-4 h-4 mr-2" />
              Edit
            </>
          )}
        </Button>
      </div>
      
      <div className="max-w-4xl mx-auto p-4 space-y-8 pt-16 pb-24">
        {/* Header section with profile basics */}
        <section>
          <InfluencerHeader
            profile={formData}
            editMode={editMode}
            onProfilePictureUpload={handleProfilePictureUpload}
            uploadProgress={uploadProgress}
            uploadingImage={uploadingImage}
          />
          
          {editMode && (
            <Card className="mt-6">
              <CardContent className="p-6 space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1">Full Name</label>
                  <Input
                    name="full_name"
                    value={formData.full_name}
                    onChange={handleInputChange}
                    placeholder="Your full name"
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1">Username</label>
                  <div className="flex">
                    <span className="bg-gray-100 p-2 rounded-l-md text-gray-500">@</span>
                    <Input
                      name="username"
                      value={formData.username}
                      onChange={handleInputChange}
                      placeholder="username"
                      className="rounded-l-none"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1">
                    Tagline <span className="text-gray-400 text-xs">(Short description of what you do)</span>
                  </label>
                  <Input
                    name="tagline"
                    value={formData.tagline}
                    onChange={handleInputChange}
                    placeholder="Lifestyle creator, sharing fashion tips and travel"
                    maxLength={60}
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1">Bio</label>
                  <Textarea
                    name="bio"
                    value={formData.bio}
                    onChange={handleInputChange}
                    placeholder="Tell brands about yourself, your content style, and what makes you unique..."
                    className="h-24"
                    maxLength={300}
                  />
                  <div className="text-xs text-gray-400 mt-1">
                    {formData.bio?.length || 0}/300 characters
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1">Location</label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                    <Input
                      name="location"
                      value={formData.location}
                      onChange={handleInputChange}
                      placeholder="City, Country"
                      className="pl-10"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700 block mb-1">Portfolio URL</label>
                  <div className="relative">
                    <Link2 className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                    <Input
                      name="portfolio_url"
                      value={formData.portfolio_url}
                      onChange={handleInputChange}
                      placeholder="https://your-portfolio.com or Linktree URL"
                      className="pl-10"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </section>
        
        {/* Platform connections */}
        <section>
          <h2 className="text-xl font-bold mb-4 flex items-center">
            <Link2 className="w-5 h-5 mr-2 text-purple-600" />
            Connected Platforms
          </h2>
          
          <div className="grid gap-4 md:grid-cols-3">
            <PlatformConnector
              type="instagram"
              icon={Instagram}
              label="Instagram"
              handle={formData.platforms.instagram.handle}
              connected={formData.platforms.instagram.connected}
              editMode={editMode}
              onConnect={connectInstagram}
              onChange={(value) => handlePlatformChange('instagram', value)}
              iconColor="text-pink-600"
              gradientFrom="from-pink-500"
              gradientTo="to-purple-500"
            />
            
            <PlatformConnector
              type="tiktok"
              icon={TikTok}
              label="TikTok"
              handle={formData.platforms.tiktok.handle}
              connected={formData.platforms.tiktok.connected}
              editMode={editMode}
              onConnect={connectTikTok}
              onChange={(value) => handlePlatformChange('tiktok', value)}
              iconColor="text-black"
              gradientFrom="from-gray-900"
              gradientTo="to-gray-700"
            />
            
            <PlatformConnector
              type="youtube"
              icon={Youtube}
              label="YouTube"
              handle={formData.platforms.youtube.handle}
              connected={formData.platforms.youtube.connected}
              editMode={editMode}
              onConnect={() => {}}
              onChange={(value) => handlePlatformChange('youtube', value)}
              iconColor="text-red-600"
              gradientFrom="from-red-600"
              gradientTo="to-red-700"
            />
          </div>
        </section>
        
        {/* Stats & Performance */}
        <AnimatePresence>
          {(stats || formData.platforms.instagram.connected) && (
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2 text-purple-600" />
                  Performance Stats
                </h2>
                
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-gray-400" />
                  <Switch
                    checked={privacySettings.showStats}
                    onCheckedChange={(checked) => 
                      setPrivacySettings(prev => ({ ...prev, showStats: checked }))
                    }
                  />
                  <span className="text-sm text-gray-500">Public</span>
                </div>
              </div>
              
              <div className="grid gap-4 md:grid-cols-4">
                <StatisticsCard
                  icon={Users}
                  label="Followers"
                  value={stats?.instagram?.followers || 25400}
                  format="number"
                  trend="+12%"
                  trendUp={true}
                  iconColor="text-pink-600"
                  bgClass="bg-pink-50"
                />
                
                <StatisticsCard
                  icon={TrendingUp}
                  label="Engagement"
                  value={stats?.instagram?.engagement_rate || 4.3}
                  format="percent"
                  trend="+0.8%"
                  trendUp={true}
                  iconColor="text-purple-600"
                  bgClass="bg-purple-50"
                />
                
                <StatisticsCard
                  icon={Award}
                  label="Avg. Likes"
                  value={stats?.instagram?.average_likes || 2340}
                  format="number"
                  trend="+5%"
                  trendUp={true}
                  iconColor="text-indigo-600"
                  bgClass="bg-indigo-50"
                />
                
                <StatisticsCard
                  icon={Eye}
                  label="Reach"
                  value={stats?.instagram?.reach || 45600}
                  format="number"
                  trend="+18%"
                  trendUp={true}
                  iconColor="text-blue-600"
                  bgClass="bg-blue-50"
                />
              </div>
            </motion.section>
          )}
        </AnimatePresence>
        
        {/* Audience Demographics */}
        <AnimatePresence>
          {(stats || formData.platforms.instagram.connected) && (
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold flex items-center">
                  <Users className="w-5 h-5 mr-2 text-purple-600" />
                  Audience Insights
                </h2>
                
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-gray-400" />
                  <Switch
                    checked={privacySettings.showAudience}
                    onCheckedChange={(checked) => 
                      setPrivacySettings(prev => ({ ...prev, showAudience: checked }))
                    }
                  />
                  <span className="text-sm text-gray-500">Public</span>
                </div>
              </div>
              
              <AudienceDemo
                audienceData={stats?.instagram || {
                  gender_split: { male: 35, female: 65 },
                  age_distribution: {
                    '13-17': 5,
                    '18-24': 45,
                    '25-34': 30,
                    '35-44': 15,
                    '45-plus': 5
                  },
                  top_locations: [
                    { country: 'Qatar', percentage: 65 },
                    { country: 'UAE', percentage: 15 },
                    { country: 'United States', percentage: 10 }
                  ]
                }}
                isPrivate={!privacySettings.showAudience && !editMode}
              />
              
              <div className="text-center mt-2 text-xs text-gray-500 flex items-center justify-center">
                <CalendarDays className="w-3 h-3 mr-1" />
                Last updated: {new Date().toLocaleDateString()} via Instagram API
              </div>
            </motion.section>
          )}
        </AnimatePresence>
        
        {/* Content Categories */}
        <section>
          <h2 className="text-xl font-bold mb-4 flex items-center">
            <Sparkles className="w-5 h-5 mr-2 text-purple-600" />
            Content Categories
            <span className="ml-2 text-sm text-gray-500 font-normal">
              (Select up to 5)
            </span>
          </h2>
          
          <ContentCategorySelector
            selectedCategories={formData.niche}
            onToggleCategory={handleNicheToggle}
            editMode={editMode}
          />
        </section>
        
        {/* Portfolio / Past Work */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold flex items-center">
              <Grid className="w-5 h-5 mr-2 text-purple-600" />
              Portfolio & Past Work
            </h2>
            
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-gray-400" />
              <Switch
                checked={privacySettings.showPortfolio}
                onCheckedChange={(checked) => 
                  setPrivacySettings(prev => ({ ...prev, showPortfolio: checked }))
                }
              />
              <span className="text-sm text-gray-500">Public</span>
            </div>
          </div>
          
          <PortfolioSection
            portfolioItems={formData.portfolio_items}
            editMode={editMode}
            onUpload={handlePortfolioItemUpload}
            uploadingImage={uploadingImage}
            uploadProgress={uploadProgress}
            isPrivate={!privacySettings.showPortfolio && !editMode}
          />
        </section>
      </div>
      
      {/* Fixed action buttons */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/80 backdrop-blur-sm border-t z-50">
        <div className="max-w-4xl mx-auto flex justify-between gap-4">
          {editMode ? (
            <>
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => setEditMode(false)}
              >
                <Eye className="w-4 h-4 mr-2" />
                Preview
              </Button>
              
              <Button
                className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white"
                onClick={handleSaveProfile}
                disabled={saving}
              >
                {saving ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Saving...
                  </>
                ) : (
                  'Save Profile'
                )}
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => {
                  navigator.clipboard.writeText(window.location.href);
                  alert("Profile link copied to clipboard!");
                }}
              >
                <Copy className="w-4 h-4 mr-2" />
                Share Profile
              </Button>
              
              <Button
                className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white"
                onClick={() => setEditMode(true)}
              >
                <Settings className="w-4 h-4 mr-2" />
                Edit Profile
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}