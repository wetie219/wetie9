import { useState, useEffect, createContext, useContext } from 'react';

// Default language is English
const defaultLanguage = 'en';

// Available languages
export const languages = {
  en: {
    name: 'English',
    dir: 'ltr',
    code: 'en'
  },
  he: {
    name: 'עברית',
    dir: 'rtl',
    code: 'he'
  },
  ar: {
    name: 'العربية',
    dir: 'rtl',
    code: 'ar'
  }
};

// Create language context
export const LanguageContext = createContext({
  language: defaultLanguage,
  setLanguage: () => {},
  dir: 'ltr',
  t: (key) => key
});

// Language provider component
export function LanguageProvider({ children }) {
  // Try to get language from localStorage
  const getInitialLanguage = () => {
    if (typeof window !== 'undefined') {
      const savedLanguage = localStorage.getItem('language');
      return savedLanguage && languages[savedLanguage] ? savedLanguage : defaultLanguage;
    }
    return defaultLanguage;
  };

  const [language, setLanguageState] = useState(getInitialLanguage());
  const [translations, setTranslations] = useState({});
  const [loading, setLoading] = useState(true);

  const setLanguage = (lang) => {
    if (languages[lang]) {
      setLanguageState(lang);
      localStorage.setItem('language', lang);
      
      // Set document direction based on language
      document.documentElement.dir = languages[lang].dir;
      document.documentElement.lang = lang;
    }
  };

  useEffect(() => {
    // Set initial document direction
    document.documentElement.dir = languages[language].dir;
    document.documentElement.lang = language;
    
    // Load translations 
    const translationsMap = {
      'en': enTranslations,
      'he': heTranslations,
      'ar': arTranslations
    };
    
    setTranslations(translationsMap[language] || {});
    setLoading(false);
  }, [language]);

  // Translation function
  const t = (key) => {
    if (loading) return key;
    return translations[key] || key;
  };

  return (
    <LanguageContext.Provider 
      value={{ 
        language, 
        setLanguage, 
        dir: languages[language].dir,
        t,
        loading
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
}

// Custom hook to use translations
export function useTranslation() {
  return useContext(LanguageContext);
}

// English translations
const enTranslations = {
  // General
  "app_name": "WETIE",
  "loading": "Loading...",
  "error": "An error occurred",
  "save": "Save",
  "cancel": "Cancel",
  "edit": "Edit",
  "delete": "Delete",
  "search": "Search",
  "filter": "Filter",
  "sort": "Sort",
  "view_all": "View All",
  "clear": "Clear",
  "next": "Next",
  "back": "Back",
  "done": "Done",
  "complete": "Complete",
  
  // Navigation
  "nav_home": "Home",
  "nav_matches": "Matches", 
  "nav_campaigns": "Campaigns",
  "nav_messages": "Messages",
  "nav_profile": "Profile",
  
  // Authentication
  "login": "Login",
  "signup": "Sign Up",
  "logout": "Logout",
  "welcome_back": "Welcome back",
  "create_account": "Create Account",
  
  // Onboarding
  "onboarding_complete": "Onboarding Complete",
  "are_you": "ARE YOU?",
  "brand": "BRAND",
  "influencer": "INFLUENCER",
  "select_role": "Select your role",
  
  // Dashboard
  "welcome": "Welcome",
  "pending_requests": "Pending Requests",
  "active_campaigns": "Active Campaigns",
  "completed": "Completed",
  "total_earnings": "Total Earnings",
  "recent_requests": "Recent Requests",
  "more_collaborations": "Want to get more collaborations?",
  "discover_brands": "Discover brands looking for creators like you",
  "apply_to_campaigns": "Apply to Campaigns",
  "no_requests_yet": "No Requests Yet",
  "new_requests_appear": "New campaign requests will appear here",
  
  // Matches
  "match_requests": "Match Requests",
  "no_matches_yet": "No Match Requests Yet",
  "match_description": "When brands are interested in collaborating with you, their requests will appear here.",
  "return_to_dashboard": "Return to Dashboard",
  "sort_recent": "Most Recent",
  "sort_best_match": "Best Match",
  "search_matches": "Search matches...",
  "accept_match": "Accept",
  "decline_match": "Decline",
  "match_date": "Match Date",
  "today": "Today",
  "yesterday": "Yesterday",
  "days_ago": "days ago",
  
  // Messages
  "messages": "Messages",
  "no_messages": "No messages yet",
  "start_conversation": "Start a conversation",
  "type_message": "Type a message...",
  "unread": "Unread",
  "favorites": "Favorites",
  "active_only": "Active Only",
  "start_chat": "Start Your First Chat",
  "connect_creators": "Connect with amazing creators and start building meaningful partnerships today!",
  "discover_creators": "Discover Creators",
  "boost_brand": "Boost Your Brand",
  "connect_faster": "Connect faster with creators",
  "try_premium": "Try Premium",
  
  // Campaigns
  "campaigns": "Campaigns",
  "pending": "Pending",
  "active": "Active",
  "completed": "Completed",
  "newest_first": "Newest First",
  "best_match_first": "Best Match First",
  "no_campaigns": "No {status} campaigns at the moment",
  "suggested_collaborations": "Suggested Collaborations",
  "successful_campaigns": "Based on your successful campaigns, consider working with:",
  
  // Profile
  "business_profile": "Business Profile",
  "company_information": "Company Information",
  "company_name": "Company Name",
  "industry": "Industry",
  "description": "Description",
  "company_logo": "Company Logo",
  "upload_logo": "Upload Logo",
  "campaign_preferences": "Campaign Preferences",
  "campaign_goals": "Campaign Goals",
  "budget_range": "Budget Range",
  "preferred_platforms": "Preferred Platforms",
  "update_profile": "Update Profile",
  "create_profile": "Create Profile",
  
  // Match Cards
  "match_score": "Match Score",
  
  // Industries/Categories
  "fashion": "Fashion",
  "beauty": "Beauty",
  "tech": "Technology",
  "food": "Food & Beverage",
  "fitness": "Fitness",
  "lifestyle": "Lifestyle",
  "gaming": "Gaming",
  "education": "Education",
  "travel": "Travel",
  "other": "Other",
  
  // Campaign Goals
  "brand_awareness": "Brand Awareness",
  "product_launch": "Product Launch",
  "sales_boost": "Sales Boost",
  "community_engagement": "Community Engagement",
  "content_creation": "Content Creation",
  "sales_conversion": "Sales Conversion",
  "event_promotion": "Event Promotion",

  // Platforms
  "instagram": "Instagram",
  "tiktok": "TikTok",
  "youtube": "YouTube"
};

// Hebrew translations
const heTranslations = {
  // General
  "app_name": "WETIE",
  "loading": "טוען...",
  "error": "אירעה שגיאה",
  "save": "שמור",
  "cancel": "ביטול",
  "edit": "ערוך",
  "delete": "מחק",
  "search": "חיפוש",
  "filter": "סינון",
  "sort": "מיון",
  "view_all": "הצג הכל",
  "clear": "נקה",
  "next": "הבא",
  "back": "חזרה",
  "done": "סיום",
  "complete": "השלם",
  
  // Navigation
  "nav_home": "בית",
  "nav_matches": "התאמות", 
  "nav_campaigns": "קמפיינים",
  "nav_messages": "הודעות",
  "nav_profile": "פרופיל",
  
  // Authentication
  "login": "התחברות",
  "signup": "הרשמה",
  "logout": "התנתקות",
  "welcome_back": "ברוך שובך",
  "create_account": "צור חשבון",
  
  // Onboarding
  "onboarding_complete": "תהליך ההכרות הושלם",
  "are_you": "האם אתה?",
  "brand": "מותג",
  "influencer": "משפיען",
  "select_role": "בחר את התפקיד שלך",
  
  // Dashboard
  "welcome": "ברוך הבא",
  "pending_requests": "בקשות ממתינות",
  "active_campaigns": "קמפיינים פעילים",
  "completed": "הושלמו",
  "total_earnings": "סך הכנסות",
  "recent_requests": "בקשות אחרונות",
  "more_collaborations": "רוצה לקבל יותר שיתופי פעולה?",
  "discover_brands": "גלה מותגים שמחפשים יוצרים כמוך",
  "apply_to_campaigns": "הגש מועמדות לקמפיינים",
  "no_requests_yet": "אין בקשות עדיין",
  "new_requests_appear": "בקשות קמפיין חדשות יופיעו כאן",
  
  // Matches
  "match_requests": "בקשות התאמה",
  "no_matches_yet": "אין בקשות התאמה עדיין",
  "match_description": "כאשר מותגים מעוניינים לשתף פעולה איתך, הבקשות שלהם יופיעו כאן.",
  "return_to_dashboard": "חזור ללוח הבקרה",
  "sort_recent": "החדש ביותר",
  "sort_best_match": "ההתאמה הטובה ביותר",
  "search_matches": "חפש התאמות...",
  "accept_match": "קבל",
  "decline_match": "דחה",
  "match_date": "תאריך התאמה",
  "today": "היום",
  "yesterday": "אתמול",
  "days_ago": "ימים",
  
  // Messages
  "messages": "הודעות",
  "no_messages": "אין הודעות עדיין",
  "start_conversation": "התחל שיחה",
  "type_message": "הקלד הודעה...",
  "unread": "לא נקרא",
  "favorites": "מועדפים",
  "active_only": "פעילים בלבד",
  "start_chat": "התחל את הצ'אט הראשון שלך",
  "connect_creators": "התחבר עם יוצרים מדהימים והתחל לבנות שותפויות משמעותיות היום!",
  "discover_creators": "גלה יוצרים",
  "boost_brand": "חזק את המותג שלך",
  "connect_faster": "התחבר מהר יותר עם יוצרים",
  "try_premium": "נסה פרימיום",
  
  // Campaigns
  "campaigns": "קמפיינים",
  "pending": "ממתינים",
  "active": "פעילים",
  "completed": "הושלמו",
  "newest_first": "החדש ביותר תחילה",
  "best_match_first": "ההתאמה הטובה ביותר תחילה",
  "no_campaigns": "אין קמפיינים {status} כרגע",
  "suggested_collaborations": "שיתופי פעולה מוצעים",
  "successful_campaigns": "בהתבסס על הקמפיינים המוצלחים שלך, שקול לעבוד עם:",
  
  // Profile
  "business_profile": "פרופיל עסקי",
  "company_information": "מידע על החברה",
  "company_name": "שם החברה",
  "industry": "תעשייה",
  "description": "תיאור",
  "company_logo": "לוגו חברה",
  "upload_logo": "העלה לוגו",
  "campaign_preferences": "העדפות קמפיין",
  "campaign_goals": "מטרות קמפיין",
  "budget_range": "טווח תקציב",
  "preferred_platforms": "פלטפורמות מועדפות",
  "update_profile": "עדכן פרופיל",
  "create_profile": "צור פרופיל",
  
  // Match Cards
  "match_score": "ציון התאמה",
  
  // Industries/Categories
  "fashion": "אופנה",
  "beauty": "יופי",
  "tech": "טכנולוגיה",
  "food": "מזון ומשקאות",
  "fitness": "כושר",
  "lifestyle": "לייף סטייל",
  "gaming": "גיימינג",
  "education": "חינוך",
  "travel": "נסיעות",
  "other": "אחר",
  
  // Campaign Goals
  "brand_awareness": "מודעות למותג",
  "product_launch": "השקת מוצר",
  "sales_boost": "הגברת מכירות",
  "community_engagement": "מעורבות קהילה",
  "content_creation": "יצירת תוכן",
  "sales_conversion": "המרת מכירות",
  "event_promotion": "קידום אירועים",

  // Platforms
  "instagram": "אינסטגרם",
  "tiktok": "טיקטוק",
  "youtube": "יוטיוב"
};

// Arabic translations
const arTranslations = {
  // General
  "app_name": "WETIE",
  "loading": "جاري التحميل...",
  "error": "حدث خطأ",
  "save": "حفظ",
  "cancel": "إلغاء",
  "edit": "تعديل",
  "delete": "حذف",
  "search": "بحث",
  "filter": "تصفية",
  "sort": "ترتيب",
  "view_all": "عرض الكل",
  "clear": "مسح",
  "next": "التالي",
  "back": "رجوع",
  "done": "تم",
  "complete": "إكمال",
  
  // Navigation
  "nav_home": "الرئيسية",
  "nav_matches": "التطابقات", 
  "nav_campaigns": "الحملات",
  "nav_messages": "الرسائل",
  "nav_profile": "الملف الشخصي",
  
  // Authentication
  "login": "تسجيل الدخول",
  "signup": "إنشاء حساب",
  "logout": "تسجيل الخروج",
  "welcome_back": "مرحبًا بعودتك",
  "create_account": "إنشاء حساب",
  
  // Onboarding
  "onboarding_complete": "اكتمل التعريف",
  "are_you": "هل أنت؟",
  "brand": "علامة تجارية",
  "influencer": "مؤثر",
  "select_role": "اختر دورك",
  
  // Dashboard
  "welcome": "مرحبًا",
  "pending_requests": "طلبات معلقة",
  "active_campaigns": "حملات نشطة",
  "completed": "مكتملة",
  "total_earnings": "إجمالي الأرباح",
  "recent_requests": "الطلبات الأخيرة",
  "more_collaborations": "هل تريد الحصول على المزيد من التعاون؟",
  "discover_brands": "اكتشف العلامات التجارية التي تبحث عن مبدعين مثلك",
  "apply_to_campaigns": "التقدم للحملات",
  "no_requests_yet": "لا توجد طلبات بعد",
  "new_requests_appear": "ستظهر طلبات الحملة الجديدة هنا",
  
  // Matches
  "match_requests": "طلبات التطابق",
  "no_matches_yet": "لا توجد طلبات تطابق بعد",
  "match_description": "عندما تهتم العلامات التجارية بالتعاون معك، ستظهر طلباتهم هنا.",
  "return_to_dashboard": "العودة إلى لوحة المعلومات",
  "sort_recent": "الأحدث",
  "sort_best_match": "أفضل تطابق",
  "search_matches": "البحث عن تطابقات...",
  "accept_match": "قبول",
  "decline_match": "رفض",
  "match_date": "تاريخ التطابق",
  "today": "اليوم",
  "yesterday": "أمس",
  "days_ago": "أيام مضت",
  
  // Messages
  "messages": "الرسائل",
  "no_messages": "لا توجد رسائل بعد",
  "start_conversation": "بدء محادثة",
  "type_message": "اكتب رسالة...",
  "unread": "غير مقروءة",
  "favorites": "المفضلة",
  "active_only": "النشطة فقط",
  "start_chat": "ابدأ محادثتك الأولى",
  "connect_creators": "تواصل مع المبدعين الرائعين وابدأ ببناء شراكات هادفة اليوم!",
  "discover_creators": "اكتشف المبدعين",
  "boost_brand": "عزز علامتك التجارية",
  "connect_faster": "تواصل بشكل أسرع مع المبدعين",
  "try_premium": "جرب الإصدار المميز",
  
  // Campaigns
  "campaigns": "الحملات",
  "pending": "معلقة",
  "active": "نشطة",
  "completed": "مكتملة",
  "newest_first": "الأحدث أولاً",
  "best_match_first": "أفضل تطابق أولاً",
  "no_campaigns": "لا توجد حملات {status} في الوقت الحالي",
  "suggested_collaborations": "تعاونات مقترحة",
  "successful_campaigns": "بناءً على حملاتك الناجحة، فكر في العمل مع:",
  
  // Profile
  "business_profile": "الملف التجاري",
  "company_information": "معلومات الشركة",
  "company_name": "اسم الشركة",
  "industry": "الصناعة",
  "description": "الوصف",
  "company_logo": "شعار الشركة",
  "upload_logo": "تحميل الشعار",
  "campaign_preferences": "تفضيلات الحملة",
  "campaign_goals": "أهداف الحملة",
  "budget_range": "نطاق الميزانية",
  "preferred_platforms": "المنصات المفضلة",
  "update_profile": "تحديث الملف",
  "create_profile": "إنشاء ملف",
  
  // Match Cards
  "match_score": "درجة التطابق",
  
  // Industries/Categories
  "fashion": "أزياء",
  "beauty": "جمال",
  "tech": "تكنولوجيا",
  "food": "طعام ومشروبات",
  "fitness": "لياقة بدنية",
  "lifestyle": "نمط حياة",
  "gaming": "ألعاب",
  "education": "تعليم",
  "travel": "سفر",
  "other": "أخرى",
  
  // Campaign Goals
  "brand_awareness": "الوعي بالعلامة التجارية",
  "product_launch": "إطلاق منتج",
  "sales_boost": "تعزيز المبيعات",
  "community_engagement": "مشاركة المجتمع",
  "content_creation": "إنشاء محتوى",
  "sales_conversion": "تحويل المبيعات",
  "event_promotion": "الترويج للفعاليات",

  // Platforms
  "instagram": "انستغرام",
  "tiktok": "تيك توك",
  "youtube": "يوتيوب"
}