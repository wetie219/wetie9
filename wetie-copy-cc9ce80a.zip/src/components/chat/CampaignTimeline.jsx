import React from 'react';
import { Card } from "@/components/ui/card";
import { 
  CheckCircle, 
  MessageSquare, 
  Briefcase, 
  CreditCard, 
  Clock
} from "lucide-react";

export default function CampaignTimeline({ campaign }) {
  const steps = [
    { 
      icon: CheckCircle, 
      label: 'Matched',
      date: campaign.match_date,
      completed: true
    },
    { 
      icon: MessageSquare, 
      label: 'Chat Started',
      date: campaign.chat_start_date,
      completed: true
    },
    { 
      icon: Briefcase, 
      label: 'Deal Agreed',
      date: campaign.campaign_details?.proposal_date,
      completed: !!campaign.campaign_details?.proposal_date
    },
    { 
      icon: CreditCard, 
      label: 'Payment Secured',
      date: campaign.campaign_details?.payment_date,
      completed: campaign.campaign_details?.payment_status === 'escrow'
    },
    { 
      icon: CheckCircle, 
      label: 'Completed',
      date: campaign.campaign_details?.completion_date,
      completed: campaign.status === 'campaign_completed'
    }
  ];

  return (
    <Card className="p-4 bg-white/50 backdrop-blur-sm">
      <div className="relative">
        {/* Vertical Line */}
        <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-200" />
        
        {/* Timeline Steps */}
        {steps.map((step, index) => (
          <div key={index} className="flex items-center mb-4 relative">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 
              ${step.completed 
                ? 'bg-green-100 text-green-600' 
                : 'bg-gray-100 text-gray-400'}`}
            >
              <step.icon className="w-4 h-4" />
            </div>
            <div className="ml-4">
              <p className="font-medium">{step.label}</p>
              {step.date && (
                <p className="text-sm text-gray-500">
                  {new Date(step.date).toLocaleDateString()}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}