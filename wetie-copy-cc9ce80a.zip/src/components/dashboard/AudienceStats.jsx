import React from 'react';
import { Bar } from 'recharts';
import { Globe, MapPin, Users } from 'lucide-react';

export default function AudienceStats({ influencer }) {
  // Sample data - in real app, this would come from the influencer object
  const topCountries = [
    { name: 'Qatar', value: 45 },
    { name: 'UAE', value: 25 },
    { name: 'Saudi Arabia', value: 15 },
    { name: 'Kuwait', value: 10 },
    { name: 'Bahrain', value: 5 }
  ];

  const ageGroups = [
    { age: '13-17', percentage: 5 },
    { age: '18-24', percentage: 35 },
    { age: '25-34', percentage: 40 },
    { age: '35-44', percentage: 15 },
    { age: '45+', percentage: 5 }
  ];

  const topCities = [
    { name: 'Doha', value: 40 },
    { name: 'Dubai', value: 20 },
    { name: 'Riyadh', value: 15 },
    { name: 'Abu Dhabi', value: 10 },
    { name: 'Kuwait City', value: 5 }
  ];

  const StatBar = ({ label, value, color = "purple" }) => (
    <div className="space-y-1">
      <div className="flex justify-between items-center text-sm">
        <span>{label}</span>
        <span className="font-medium">{value}%</span>
      </div>
      <div className="h-2 rounded-full bg-gray-100">
        <div 
          className={`h-full rounded-full bg-gradient-to-r from-[#2F2C7F] to-[#E010CD]`}
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Top Countries */}
      <div className="bg-white rounded-2xl shadow-sm p-4">
        <div className="flex items-center gap-2 mb-4">
          <Globe className="w-5 h-5 text-[#2F2C7F]" />
          <h3 className="text-lg font-semibold">Top Countries</h3>
        </div>
        <div className="space-y-3">
          {topCountries.map(country => (
            <StatBar 
              key={country.name}
              label={country.name}
              value={country.value}
            />
          ))}
        </div>
      </div>

      {/* Top Cities */}
      <div className="bg-white rounded-2xl shadow-sm p-4">
        <div className="flex items-center gap-2 mb-4">
          <MapPin className="w-5 h-5 text-[#2F2C7F]" />
          <h3 className="text-lg font-semibold">Top Cities</h3>
        </div>
        <div className="space-y-3">
          {topCities.map(city => (
            <StatBar 
              key={city.name}
              label={city.name}
              value={city.value}
            />
          ))}
        </div>
      </div>

      {/* Age Groups */}
      <div className="bg-white rounded-2xl shadow-sm p-4">
        <div className="flex items-center gap-2 mb-4">
          <Users className="w-5 h-5 text-[#2F2C7F]" />
          <h3 className="text-lg font-semibold">Age Groups</h3>
        </div>
        <div className="space-y-3">
          {ageGroups.map(group => (
            <StatBar 
              key={group.age}
              label={group.age}
              value={group.percentage}
            />
          ))}
        </div>
      </div>
    </div>
  );
}