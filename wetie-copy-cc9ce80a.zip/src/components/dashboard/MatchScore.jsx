import React from 'react';
import { motion } from 'framer-motion';

export default function MatchScore({ percentage }) {
  const radius = 30;
  const circumference = 2 * Math.PI * radius;
  const progress = (percentage / 100) * circumference;
  const dashoffset = circumference - progress;

  return (
    <motion.div 
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="relative h-20 w-20 flex items-center justify-center"
    >
      <svg className="absolute transform -rotate-90" width="80" height="80">
        {/* Background circle */}
        <circle
          cx="40"
          cy="40"
          r={radius}
          stroke="#E5E7EB"
          strokeWidth="6"
          fill="none"
        />
        
        {/* Progress circle */}
        <circle
          cx="40"
          cy="40"
          r={radius}
          stroke="url(#gradient)"
          strokeWidth="6"
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={dashoffset}
          strokeLinecap="round"
        />
        
        {/* Gradient definition */}
        <defs>
          <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#2F2C7F" />
            <stop offset="100%" stopColor="#E010CD" />
          </linearGradient>
        </defs>
      </svg>
      
      {/* Percentage text */}
      <div className="z-10 flex flex-col items-center">
        <span className="text-xl font-bold">{percentage}%</span>
        <span className="text-xs text-gray-500">Match</span>
      </div>
    </motion.div>
  );
}