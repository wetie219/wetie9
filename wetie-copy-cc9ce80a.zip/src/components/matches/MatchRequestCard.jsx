import React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  CheckCircle,
  X,
  Loader2,
  Award,
  Tag,
  Timer
} from "lucide-react";

export default function MatchRequestCard({ match, processing, onAccept, onDecline }) {
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInDays = Math.floor((now - date) / (1000 * 60 * 60 * 24));
    
    if (diffInDays === 0) {
      return "Today";
    } else if (diffInDays === 1) {
      return "Yesterday";
    } else if (diffInDays < 7) {
      return `${diffInDays} days ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20, transition: { duration: 0.2 } }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: "spring", stiffness: 400, damping: 17 }}
    >
      <Card className="overflow-hidden border-gray-200">
        <div className="p-5">
          <div className="flex gap-4">
            {/* Business Logo/Image */}
            <div className="w-16 h-16 rounded-xl bg-gray-100 border border-gray-200 flex items-center justify-center overflow-hidden">
              {match.business?.logo_url ? (
                <img 
                  src={match.business.logo_url} 
                  alt={match.business.company_name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-purple-100 to-pink-100 flex items-center justify-center text-purple-600 font-semibold text-xl">
                  {match.business?.company_name?.charAt(0) || "B"}
                </div>
              )}
            </div>

            {/* Match Details */}
            <div className="flex-1">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className="font-semibold text-gray-900">{match.business?.company_name}</h3>
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <Timer className="w-4 h-4" />
                    {formatDate(match.created_date)}
                  </div>
                </div>
                
                {match.match_percentage && (
                  <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                    {match.match_percentage}% Match
                  </Badge>
                )}
              </div>

              {/* Business Categories/Tags */}
              <div className="flex flex-wrap gap-2 mt-3">
                {match.business?.industry && (
                  <Badge variant="secondary" className="bg-purple-50 text-purple-700">
                    {match.business.industry}
                  </Badge>
                )}
                {match.business?.campaign_goals?.[0] && (
                  <Badge variant="secondary" className="bg-pink-50 text-pink-700">
                    {match.business.campaign_goals[0]}
                  </Badge>
                )}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-3 mt-4">
            <Button
              variant="outline"
              className="border-red-200 text-red-600 hover:bg-red-50"
              onClick={() => onDecline(match.id)}
              disabled={processing === match.id}
            >
              {processing === match.id ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <X className="w-4 h-4 mr-2" />
              )}
              Decline
            </Button>
            
            <Button
              className="bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700"
              onClick={() => onAccept(match.id)}
              disabled={processing === match.id}
            >
              {processing === match.id ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <CheckCircle className="w-4 h-4 mr-2" />
              )}
              Accept
            </Button>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}