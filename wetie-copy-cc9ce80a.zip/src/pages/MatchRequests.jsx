
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Match } from "@/api/entities";
import { Business } from "@/api/entities";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  CheckCircle,
  X,
  MessageCircle,
  Sparkles,
  Filter,
  ArrowDown,
  Heart,
  Zap
} from "lucide-react";
import MatchRequestCard from "../components/matches/MatchRequestCard";

export default function MatchRequests() {
  const navigate = useNavigate();
  const [matchRequests, setMatchRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [processingAction, setProcessingAction] = useState(null);
  const [sortBy, setSortBy] = useState("recent");
  const [showFilterOptions, setShowFilterOptions] = useState(false);

  useEffect(() => {
    checkUserType();
    loadMatchRequests();
  }, []);

  const checkUserType = async () => {
    try {
      const user = await User.me();
      // Redirect if not an influencer
      if (user.user_type !== "influencer") {
        navigate(createPageUrl("Dashboard"));
      }
    } catch (error) {
      console.error("Error checking user type:", error);
      navigate(createPageUrl("Landing"));
    }
  };

  const loadMatchRequests = async () => {
    try {
      const user = await User.me();
      
      // Get all match requests for this influencer with pending status
      const matchData = await Match.filter({
        influencer_id: user.id,
        status: "pending_match"
      });

      // Load business details for each match
      const matchesWithBusinesses = await Promise.all(
        matchData.map(async (match) => {
          try {
            const business = await Business.get(match.business_id);
            return {
              ...match,
              business
            };
          } catch (error) {
            console.error(`Error loading business for match ${match.id}:`, error);
            return {
              ...match,
              business: { company_name: "Unknown Brand" }
            };
          }
        })
      );

      // Sort matches based on criteria
      const sorted = sortMatchRequests(matchesWithBusinesses, sortBy);
      setMatchRequests(sorted);
    } catch (error) {
      console.error("Error loading match requests:", error);
    } finally {
      setLoading(false);
    }
  };

  const sortMatchRequests = (matches, criteria) => {
    switch (criteria) {
      case "match_score":
        return [...matches].sort((a, b) => 
          (b.match_percentage || 0) - (a.match_percentage || 0)
        );
      case "recent":
      default:
        return [...matches].sort((a, b) => 
          new Date(b.created_date) - new Date(a.created_date)
        );
    }
  };

  const handleAcceptMatch = async (matchId) => {
    setProcessingAction(matchId);
    try {
      const match = matchRequests.find(m => m.id === matchId);
      
      if (match.initiated_by === "business") {
        // Update match to show influencer approved
        await Match.update(matchId, {
          influencer_approved: true,
          status: match.business_approved ? "matched" : "pending_business_approval",
          match_date: match.business_approved ? new Date().toISOString() : null
        });
      } else {
        // Update match to show business approved
        await Match.update(matchId, {
          business_approved: true,
          status: match.influencer_approved ? "matched" : "pending_influencer_approval",
          match_date: match.influencer_approved ? new Date().toISOString() : null
        });
      }

      // Remove from current list
      setMatchRequests(prev => prev.filter(m => m.id !== matchId));
      
      // If both approved, navigate to messages
      if ((match.initiated_by === "business" && match.business_approved) ||
          (match.initiated_by === "influencer" && match.influencer_approved)) {
        navigate(createPageUrl("Messages") + `?match=${matchId}`);
      }
    } catch (error) {
      console.error("Error accepting match:", error);
    } finally {
      setProcessingAction(null);
    }
  };

  const handleDeclineMatch = async (matchId) => {
    setProcessingAction(matchId);
    try {
      // Update match status to declined
      await Match.update(matchId, {
        status: "match_declined"
      });
      
      // Remove from list with animation
      setMatchRequests(prev => prev.filter(m => m.id !== matchId));
    } catch (error) {
      console.error("Error declining match:", error);
    } finally {
      setProcessingAction(null);
    }
  };

  const handleSortChange = (criteria) => {
    setSortBy(criteria);
    const sorted = sortMatchRequests(matchRequests, criteria);
    setMatchRequests(sorted);
    setShowFilterOptions(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAFA] pb-24">
      {/* Header */}
      <div className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-xl mx-auto px-4 py-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-gray-900">Match Requests</h1>
              {matchRequests.length > 0 && (
                <Badge className="bg-purple-600">
                  {matchRequests.length}
                </Badge>
              )}
            </div>
            
            <div className="relative">
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-600 gap-1"
                onClick={() => setShowFilterOptions(!showFilterOptions)}
              >
                <Filter className="w-4 h-4" />
                Sort
                <ArrowDown className="w-3 h-3 ml-1" />
              </Button>
              
              {showFilterOptions && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute right-0 mt-1 bg-white shadow-lg rounded-lg w-48 py-1 z-20"
                >
                  <button 
                    className={`w-full text-left px-4 py-2 text-sm hover:bg-purple-50 ${
                      sortBy === 'recent' ? 'text-purple-600 font-medium' : 'text-gray-700'
                    }`}
                    onClick={() => handleSortChange('recent')}
                  >
                    Most Recent
                  </button>
                  <button 
                    className={`w-full text-left px-4 py-2 text-sm hover:bg-purple-50 ${
                      sortBy === 'match_score' ? 'text-purple-600 font-medium' : 'text-gray-700'
                    }`}
                    onClick={() => handleSortChange('match_score')}
                  >
                    Highest Match Score
                  </button>
                </motion.div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-xl mx-auto px-4 py-6">
        <AnimatePresence>
          {matchRequests.length > 0 ? (
            <div className="space-y-4">
              {matchRequests.map((match) => (
                <MatchRequestCard 
                  key={match.id}
                  match={match}
                  processing={processingAction === match.id}
                  onAccept={() => handleAcceptMatch(match.id)}
                  onDecline={() => handleDeclineMatch(match.id)}
                />
              ))}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col items-center justify-center py-16 text-center"
            >
              <div className="w-36 h-36 mb-6">
                <motion.div
                  animate={{
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    repeatType: "reverse"
                  }}
                  className="w-full h-full bg-gradient-to-br from-purple-400/20 to-pink-400/20 rounded-full flex items-center justify-center relative"
                >
                  <motion.div
                    animate={{
                      rotate: 360
                    }}
                    transition={{
                      duration: 20,
                      repeat: Infinity,
                      ease: "linear"
                    }}
                    className="absolute inset-0 rounded-full bg-gradient-to-r from-purple-400/10 to-transparent"
                  />
                  <Sparkles className="w-16 h-16 text-purple-500" />
                </motion.div>
              </div>
              
              <h2 className="text-2xl font-bold text-gray-900 mb-3">No Matches Yet</h2>
              <p className="text-gray-600 max-w-sm mb-8">
                Start swiping to discover brands & creators or wait for brands to match with you!
              </p>
              <Button
                className="bg-gradient-to-r from-[#2A0845] to-[#C625FF] text-white shadow-md"
                onClick={() => navigate(createPageUrl("Discover"))}
              >
                <Zap className="w-4 h-4 mr-2" />
                Discover Brands
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
