import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  CreditCard, 
  Lock, 
  Shield, 
  CheckCircle, 
  Calendar, 
  DollarSign,
  Briefcase
} from "lucide-react";

/**
 * Campaign Confirmation component
 * Shown when both parties have agreed to a campaign proposal
 */
export default function CampaignConfirmation({ onClose, onConfirm, campaignData, partnerName }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="bg-white rounded-xl w-full max-w-md overflow-hidden"
      >
        <div className="p-6">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </div>
          
          <h2 className="text-xl font-bold text-center mb-6">
            Ready to Secure Campaign
          </h2>
          
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="flex items-center mb-4">
              <Briefcase className="text-gray-600 w-5 h-5 mr-2" />
              <span className="font-medium">{campaignData?.title || "Campaign"}</span>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Partner:</span>
                <span className="font-medium">{partnerName}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Content type:</span>
                <span>{campaignData?.content_type || "Post"}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Quantity:</span>
                <span>{campaignData?.quantity || 1} posts</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Budget:</span>
                <span className="font-bold text-lg flex items-center">
                  <DollarSign className="w-4 h-4" />
                  {campaignData?.budget || "0"}
                </span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Deadline:</span>
                <span className="flex items-center">
                  <Calendar className="w-4 h-4 mr-1 text-gray-500" />
                  {campaignData?.deadline || "TBD"}
                </span>
              </div>
            </div>
          </div>
          
          <div className="bg-blue-50 border border-blue-100 rounded-lg p-3 mb-6">
            <div className="flex items-start">
              <Shield className="text-blue-600 w-5 h-5 mt-0.5 mr-2 flex-shrink-0" />
              <p className="text-sm text-blue-800">
                Funds will be held securely in escrow and released to the creator only when the work is completed and approved.
              </p>
            </div>
          </div>
          
          <div className="flex gap-3">
            <Button
              variant="outline"
              className="flex-1"
              onClick={onClose}
            >
              Cancel
            </Button>
            
            <Button
              className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white"
              onClick={onConfirm}
            >
              <CreditCard className="mr-2 h-4 w-4" />
              Secure Campaign
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}