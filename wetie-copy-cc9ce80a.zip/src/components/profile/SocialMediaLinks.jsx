import React from 'react';
import { Input } from "@/components/ui/input";
import { Instagram, Youtube, Music, Linkedin, Facebook } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export default function SocialMediaLinks({ socialMedia, onChange }) {
  const platforms = [
    { 
      id: 'instagram',
      icon: Instagram,
      color: 'text-pink-600',
      placeholder: 'Instagram handle (without @)',
      tooltip: 'Link your Instagram to get matched with relevant Instagram influencers'
    },
    { 
      id: 'tiktok',
      icon: Music,
      color: 'text-black',
      placeholder: 'TikTok handle',
      tooltip: 'TikTok creators love to see your presence on the platform'
    },
    { 
      id: 'linkedin',
      icon: Linkedin,
      color: 'text-blue-600',
      placeholder: 'LinkedIn company name',
      tooltip: 'Adding LinkedIn enhances your brand credibility'
    },
    { 
      id: 'facebook',
      icon: Facebook,
      color: 'text-blue-700',
      placeholder: 'Facebook page name',
      tooltip: 'Facebook links help with cross-platform campaigns'
    }
  ];

  return (
    <div className="space-y-3">
      {platforms.map(platform => (
        <div key={platform.id} className="relative">
          <div className="flex items-center gap-3">
            <div className={`${platform.color}`}>
              <platform.icon className="w-5 h-5" />
            </div>
            <div className="relative flex-1">
              <Input
                value={socialMedia[platform.id] || ''}
                onChange={(e) => onChange(platform.id, e.target.value)}
                placeholder={platform.placeholder}
                className="pl-9 border-gray-200 focus:border-purple-400 transition-colors"
              />
              <div className="absolute left-3 top-1/2 -translate-y-1/2">
                <platform.icon className="w-4 h-4 text-gray-400" />
              </div>
            </div>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger className="text-gray-400 hover:text-gray-600">
                  <div className="w-5 h-5 rounded-full border border-gray-300 flex items-center justify-center text-xs">?</div>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="text-sm max-w-xs">{platform.tooltip}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
      ))}
    </div>
  );
}