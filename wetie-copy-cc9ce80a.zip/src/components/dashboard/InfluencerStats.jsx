import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Instagram, Music2 } from "lucide-react";
import StatsSync from './StatsSync';
import InstagramStats from '../stats/InstagramStats';
import TikTokStats from '../stats/TikTokStats';
import { InfluencerStats as InfluencerStatsEntity } from '@/api/entities';
import { User } from '@/api/entities';

/**
 * Main Influencer Statistics Component
 * Manages social media stats and their display
 */
export default function InfluencerStats() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('instagram');

  useEffect(() => {
    loadStats();
  }, []);

  /**
   * Load influencer statistics from the database
   */
  const loadStats = async () => {
    try {
      setLoading(true);
      const user = await User.me();
      const statsData = await InfluencerStatsEntity.filter({ influencer_id: user.id });
      
      if (statsData.length > 0) {
        setStats(statsData[0]);
        // Set active tab based on connected platforms
        if (!statsData[0].instagram?.connected && statsData[0].tiktok?.connected) {
          setActiveTab('tiktok');
        }
      }
    } catch (error) {
      console.error('Error loading influencer stats:', error);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Handle manual refresh of statistics
   */
  const handleRefresh = async () => {
    await loadStats();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Sync Status */}
      <StatsSync onRefresh={handleRefresh} />

      {/* Stats Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-2">
          <TabsTrigger 
            value="instagram"
            disabled={!stats?.instagram?.connected}
            className="flex items-center gap-2"
          >
            <Instagram className="w-4 h-4" />
            Instagram
          </TabsTrigger>
          <TabsTrigger 
            value="tiktok"
            disabled={!stats?.tiktok?.connected}
            className="flex items-center gap-2"
          >
            <Music2 className="w-4 h-4" />
            TikTok
          </TabsTrigger>
        </TabsList>

        <TabsContent value="instagram" className="mt-6">
          <InstagramStats stats={stats?.instagram} />
        </TabsContent>

        <TabsContent value="tiktok" className="mt-6">
          <TikTokStats stats={stats?.tiktok} />
        </TabsContent>
      </Tabs>
    </div>
  );
}