
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Match } from "@/api/entities";
import { Influencer } from "@/api/entities";
import { Business } from "@/api/entities";
import { User } from "@/api/entities";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Search, 
  MessageSquare, 
  ArrowUpRight, 
  Star,
  Sparkles,
  Rocket,
  Filter,
  BellRing,
  Zap
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

/**
 * Animated dot component with pulse effect
 * Shows online status and unread message indicator
 */
const StatusDot = ({ status, hasUnread }) => (
  <motion.span 
    className={`absolute bottom-0 right-0 w-3 h-3 border-2 border-white rounded-full ${
      status === 'online' ? 'bg-emerald-500' : 
      status === 'busy' ? 'bg-red-500' : 
      'bg-gray-400'
    }`}
    animate={hasUnread ? {
      scale: [1, 1.2, 1],
      opacity: [1, 0.8, 1]
    } : {}}
    transition={{
      duration: 2,
      repeat: Infinity,
      ease: "easeInOut"
    }}
  />
);

/**
 * Messages page component
 * Shows conversation threads with matched influencers/businesses
 */
export default function Messages() {
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedFilter, setSelectedFilter] = useState("all");
  const [showActiveOnly, setShowActiveOnly] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    loadMessages();
  }, []);

  /**
   * Load message threads based on user's matches
   */
  const loadMessages = async () => {
    try {
      setLoading(true);
      const user = await User.me();
      setCurrentUser(user);
      
      let matchesData;
      
      // Load only matched conversations (where both parties approved)
      if (user.user_type === "influencer") {
        matchesData = await Match.filter({
          influencer_id: user.id,
          status: ["matched", "campaign_negotiation", "campaign_active", "campaign_completed"]
        });
      } else {
        matchesData = await Match.filter({
          business_id: user.id,
          status: ["matched", "campaign_negotiation", "campaign_active", "campaign_completed"]
        });
      }

      // Early return if no matches
      if (matchesData.length === 0) {
        setMatches([]);
        setLoading(false);
        return;
      }

      // Fetch profile data for each match
      let profilesData = [];
      if (user.user_type === "influencer") {
        // For influencers, load business data
        profilesData = await Promise.all(
          matchesData.map(match => Business.get(match.business_id))
        );
      } else {
        // For businesses, load influencer data
        profilesData = await Promise.all(
          matchesData.map(match => Influencer.get(match.influencer_id))
        );
      }

      // Create a map of profiles for easy access
      const profileMap = {};
      profilesData.forEach(profile => {
        // Using id as key
        profileMap[profile.id] = profile;
      });

      // Combine match data with profile information
      const processedMatches = matchesData.map(match => {
        const profileId = user.user_type === "influencer" 
          ? match.business_id 
          : match.influencer_id;
        
        // Generate a placeholder last message based on campaign state
        let lastMessage = getLastMessage(match);
        
        return {
          ...match,
          profile: profileMap[profileId],
          unread: Math.random() > 0.7, // Simulate unread state
          lastActive: new Date(Date.now() - Math.random() * 86400000 * 5), // Random time in last 5 days
          online: Math.random() > 0.7, // Simulate online status
          lastMessage
        };
      });

      setMatches(processedMatches);
    } catch (error) {
      console.error("Error loading messages:", error);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Format timestamp to relative time
   * @param {Date} date - Date to format
   * @returns {string} - Formatted time (e.g. "Just now", "5m ago", "2h ago", "3d ago")
   */
  const formatTimeAgo = (date) => {
    const now = new Date();
    const diff = (now - date) / 1000; // in seconds

    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
  };

  /**
   * Generate a placeholder last message
   */
  const getLastMessage = (match) => {
    // Campaign-specific messages based on status
    if (match.status === "campaign_negotiation") {
      return "Let's discuss the campaign details 📊";
    } else if (match.status === "campaign_active") {
      return "The campaign is going great! 🎯";
    } else if (match.status === "campaign_completed") {
      return "Thanks for the successful collaboration! 🌟";
    }
    
    // Generic messages for regular matches
    const messages = [
      "Let's discuss a potential collaboration!",
      "Great work on the last post! 🎯",
      "When can we schedule the next shoot? 📸",
      "The content looks amazing! 🌟",
      "Perfect! I'll send the brief shortly ✍️"
    ];
    return messages[Math.floor(Math.random() * messages.length)];
  };

  /**
   * Filter matches based on search term and active filter
   */
  const getFilteredMatches = () => {
    return matches.filter(match => {
      // Skip if no profile loaded
      if (!match.profile) return false;
      
      // Filter by search term
      if (searchTerm) {
        const name = currentUser.user_type === "influencer" 
          ? match.profile.company_name 
          : match.profile.full_name;
          
        if (!name.toLowerCase().includes(searchTerm.toLowerCase())) {
          return false;
        }
      }
      
      // Filter by selected filter
      if (selectedFilter === "unread" && !match.unread) {
        return false;
      }
      
      // Filter by active only
      if (showActiveOnly && !match.online) {
        return false;
      }
      
      return true;
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#FDFDFD]">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-8 h-8 border-2 border-purple-600 border-t-transparent rounded-full"
        />
      </div>
    );
  }

  // Empty state with personality
  if (matches.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-6 bg-[#FDFDFD]">
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="w-32 h-32 mb-8 relative"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full blur-xl" />
          <MessageSquare className="w-full h-full text-[#E010CD]" />
        </motion.div>
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center"
        >
          <h2 className="text-2xl font-bold mb-3">Start Your First Chat ✨</h2>
          <p className="text-gray-600 mb-8 max-w-sm">
            Connect with amazing creators and start building meaningful partnerships today!
          </p>
          <Link to={createPageUrl("Discover")}>
            <Button className="bg-gradient-to-r from-[#2F2C7F] to-[#E010CD] text-white px-8 py-6 rounded-full font-medium text-lg hover:shadow-xl transition-all duration-300">
              <Rocket className="w-5 h-5 mr-2" />
              Discover Creators
            </Button>
          </Link>
        </motion.div>
      </div>
    );
  }

  const filteredMatches = getFilteredMatches();

  return (
    <div className="min-h-screen bg-[#FDFDFD]">
      {/* Premium Banner with personality */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-[#2F2C7F] to-[#E010CD] p-4 relative overflow-hidden"
      >
        <motion.div 
          className="absolute inset-0 bg-white opacity-10"
          animate={{ 
            backgroundPosition: ["0% 0%", "100% 100%"],
            scale: [1, 1.2, 1]
          }}
          transition={{ 
            duration: 3,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        />
        <div className="flex items-center justify-between max-w-xl mx-auto relative z-10">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-full">
              <Rocket className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-medium text-white">Boost Your Brand 🚀</div>
              <div className="text-sm text-white/80">Connect faster with creators</div>
            </div>
          </div>
          <Button variant="ghost" className="text-white hover:bg-white/10 transition-all duration-300">
            Try Premium
          </Button>
        </div>
      </motion.div>

      {/* Header */}
      <div className="sticky top-0 z-10 bg-white/80 backdrop-blur-xl border-b shadow-sm">
        <div className="p-4 max-w-xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-[#2F2C7F] to-[#E010CD] bg-clip-text text-transparent">
              Messages
            </h1>
          </div>

          {/* Enhanced Search */}
          <motion.div 
            className="relative flex gap-2"
            animate={searchFocused ? { scale: 1.02 } : { scale: 1 }}
          >
            <div className="relative flex-1">
              <motion.div
                animate={searchFocused ? { x: [-2, 2, -2, 0] } : {}}
                transition={{ duration: 0.4 }}
              >
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              </motion.div>
              <Input
                placeholder="Search messages..."
                className="pl-10 bg-gray-50 border-gray-200 focus:border-[#E010CD] transition-all duration-300"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onFocus={() => setSearchFocused(true)}
                onBlur={() => setSearchFocused(false)}
              />
            </div>
            <Button 
              variant="outline" 
              size="icon"
              className="border-gray-200"
            >
              <Filter className="w-4 h-4 text-gray-600" />
            </Button>
          </motion.div>

          {/* Modern Filter Pills */}
          <div className="flex items-center gap-3 mt-4 overflow-x-auto pb-2">
            {[
              { id: 'all', label: 'All', icon: null },
              { id: 'unread', label: 'Unread', icon: <BellRing className="w-3 h-3" /> },
              { id: 'favorites', label: 'Favorites', icon: <Star className="w-3 h-3" /> }
            ].map((filter) => (
              <motion.div
                key={filter.id}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  variant={selectedFilter === filter.id ? 'default' : 'outline'}
                  className={`rounded-full ${
                    selectedFilter === filter.id 
                      ? 'bg-[#E010CD] hover:bg-[#E010CD]/90 shadow-lg shadow-[#E010CD]/20' 
                      : 'hover:bg-gray-100'
                  }`}
                  onClick={() => setSelectedFilter(filter.id)}
                >
                  {filter.icon}
                  <span className={filter.icon ? "ml-2" : ""}>{filter.label}</span>
                </Button>
              </motion.div>
            ))}
            
            <div className="flex-1" />
            
            {/* Active Toggle */}
            <Button
              variant="ghost"
              size="sm"
              className={`text-sm ${showActiveOnly ? 'text-[#E010CD]' : 'text-gray-600'}`}
              onClick={() => setShowActiveOnly(!showActiveOnly)}
            >
              <Zap className={`w-4 h-4 mr-1 ${showActiveOnly ? 'text-[#E010CD]' : 'text-gray-400'}`} />
              Active Only
            </Button>
          </div>
        </div>
      </div>

      {/* Message List */}
      <div className="max-w-xl mx-auto p-4">
        <AnimatePresence>
          {filteredMatches.length > 0 ? (
            filteredMatches.map((match, index) => (
              <motion.div
                key={match.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: index * 0.05 }}
                className="mb-3"
                whileHover={{ scale: 1.02 }}
                layout
              >
                <Card 
                  className="overflow-hidden cursor-pointer backdrop-blur-sm hover:bg-[#F3ECFC] transition-all duration-300"
                >
                  <div className="p-4 flex items-center gap-4">
                    {/* Profile Picture with Animated Status */}
                    <div className="relative">
                      <motion.div 
                        className={`w-12 h-12 rounded-full overflow-hidden ${
                          match.unread ? 'ring-2 ring-[#E010CD]' : 'ring-2 ring-purple-100'
                        }`}
                        animate={match.unread ? {
                          boxShadow: ['0 0 0 0px rgba(224, 16, 205, 0.2)', '0 0 0 4px rgba(224, 16, 205, 0.2)'],
                        } : {}}
                        transition={{ duration: 1, repeat: Infinity }}
                      >
                        <img 
                          src={match.profile.profile_picture || match.profile.logo_url} 
                          alt={match.profile.full_name || match.profile.company_name}
                          className="w-full h-full object-cover"
                        />
                      </motion.div>
                      <StatusDot status={match.online ? 'online' : 'offline'} hasUnread={match.unread} />
                    </div>

                    {/* Message Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h3 className="font-bold text-[16px] text-[#1A1A1A]">
                          {currentUser.user_type === "influencer" 
                            ? match.profile.company_name 
                            : match.profile.full_name}
                        </h3>
                        <span className="text-sm text-[#707070]">
                          {formatTimeAgo(match.lastActive)}
                        </span>
                      </div>
                      <p className="text-[14px] text-[#707070] truncate mt-1">
                        {match.lastMessage}
                      </p>
                    </div>

                    {/* Right Actions */}
                    {match.unread && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="flex flex-col items-center"
                      >
                        <Badge className="bg-[#E010CD] shadow-lg shadow-[#E010CD]/20">
                          New
                        </Badge>
                      </motion.div>
                    )}
                  </div>
                </Card>
              </motion.div>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <p className="text-gray-500 mb-4">No messages match your filters</p>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  setSearchTerm("");
                  setSelectedFilter("all");
                  setShowActiveOnly(false);
                }}
              >
                Clear Filters
              </Button>
            </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
