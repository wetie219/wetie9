import React from 'react';
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import {
  Users,
  TrendingUp,
  Globe,
  Hash,
  Heart,
  Eye
} from "lucide-react";

/**
 * Instagram Statistics Component
 * Displays real-time Instagram metrics
 */
export default function InstagramStats({ stats }) {
  if (!stats?.connected) {
    return null;
  }

  return (
    <div className="space-y-6">
      {/* Audience Overview */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Instagram Audience</h3>
        
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-purple-50 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Users className="w-5 h-5 text-purple-600" />
              <span className="text-sm text-gray-600">Followers</span>
            </div>
            <div className="text-2xl font-bold">
              {(stats.followers || 0).toLocaleString()}
            </div>
          </div>
          
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Eye className="w-5 h-5 text-blue-600" />
              <span className="text-sm text-gray-600">Reach</span>
            </div>
            <div className="text-2xl font-bold">
              {(stats.reach || 0).toLocaleString()}
            </div>
          </div>
        </div>

        {/* Engagement Rate */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Engagement Rate</span>
            <Badge variant="outline" className="font-mono">
              {stats.engagement_rate?.toFixed(2)}%
            </Badge>
          </div>
          <Progress value={stats.engagement_rate} className="h-2" />
        </div>

        {/* Demographics */}
        <div className="space-y-4">
          <h4 className="text-sm font-medium">Gender Distribution</h4>
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-pink-50 rounded p-2 text-center">
              <div className="text-sm text-gray-600">Female</div>
              <div className="font-bold">{stats.gender_split?.female || 0}%</div>
            </div>
            <div className="bg-blue-50 rounded p-2 text-center">
              <div className="text-sm text-gray-600">Male</div>
              <div className="font-bold">{stats.gender_split?.male || 0}%</div>
            </div>
          </div>
        </div>
      </Card>

      {/* Top Locations */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Top Locations</h3>
        <div className="space-y-3">
          {stats.top_locations?.map((location, index) => (
            <div 
              key={index}
              className="flex items-center justify-between p-2 bg-gray-50 rounded"
            >
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-gray-600" />
                <span>{location.city || location.country}</span>
              </div>
              <Badge variant="outline">{location.percentage}%</Badge>
            </div>
          ))}
        </div>
      </Card>

      {/* Content Categories */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Top Categories</h3>
        <div className="flex flex-wrap gap-2">
          {stats.top_categories?.map((category, index) => (
            <Badge 
              key={index}
              className="px-3 py-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white"
            >
              <Hash className="w-3 h-3 mr-1" />
              {category.category}
            </Badge>
          ))}
        </div>
      </Card>
    </div>
  );
}