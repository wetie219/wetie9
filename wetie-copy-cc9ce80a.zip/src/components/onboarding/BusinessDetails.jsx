import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function BusinessDetails({ formData, updateFormData }) {
  const industries = [
    "Fashion", "Beauty", "Technology", "Food & Beverage", "Fitness",
    "Lifestyle", "Gaming", "Education", "Travel", "Healthcare",
    "Entertainment", "Retail", "Finance", "Real Estate", "Other"
  ];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    updateFormData({ [name]: value });
  };

  const handleIndustryChange = (value) => {
    updateFormData({ industry: value });
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-center mb-2">Company Details</h2>
      <p className="text-gray-600 text-center mb-8">
        Tell us about your business
      </p>

      <div className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="company_name">Company Name</Label>
          <Input
            id="company_name"
            name="company_name"
            placeholder="Your company name"
            value={formData.company_name || ""}
            onChange={handleInputChange}
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="industry">Industry</Label>
          <Select
            value={formData.industry || ""}
            onValueChange={handleIndustryChange}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select your industry" />
            </SelectTrigger>
            <SelectContent>
              {industries.map(industry => (
                <SelectItem key={industry} value={industry.toLowerCase()}>
                  {industry}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="bio">Company Description</Label>
          <Textarea
            id="bio"
            name="bio"
            placeholder="Tell us about your company, products, and brand values..."
            value={formData.bio || ""}
            onChange={handleInputChange}
            className="resize-none h-36"
          />
          <p className="text-sm text-gray-500">
            {formData.bio?.length || 0}/500 characters
          </p>
        </div>
      </div>
    </div>
  );
}