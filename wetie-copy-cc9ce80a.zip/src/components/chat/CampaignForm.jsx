import React, { useState } from "react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, ArrowRight, Calendar, DollarSign, CheckCircle } from "lucide-react";

/**
 * Campaign Proposal Form Component
 * Used to create or edit campaign details between matches
 */
export default function CampaignForm({ onClose, onSubmit, userType = "business" }) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    content_type: "post",
    quantity: 1,
    timeline: "2_weeks",
    budget: "",
    deadline: "",
    additional_notes: ""
  });
  
  const [step, setStep] = useState(1);
  const [errors, setErrors] = useState({});

  /**
   * Handle form input changes
   */
  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
    
    // Clear error when field is updated
    if (errors[field]) {
      const newErrors = { ...errors };
      delete newErrors[field];
      setErrors(newErrors);
    }
  };

  /**
   * Validate form data
   */
  const validateForm = () => {
    const newErrors = {};
    
    if (step === 1) {
      if (!formData.title.trim()) newErrors.title = "Title is required";
      if (!formData.description.trim()) newErrors.description = "Description is required";
    } else if (step === 2) {
      if (!formData.budget) newErrors.budget = "Budget is required";
      if (!formData.deadline) newErrors.deadline = "Deadline is required";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  /**
   * Handle form submission
   */
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    if (step < 2) {
      setStep(step + 1);
      return;
    }
    
    onSubmit(formData);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="bg-white rounded-xl w-full max-w-lg overflow-hidden"
      >
        {/* Form Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            {step === 1 ? "Create Campaign" : "Campaign Details"}
          </h2>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-gray-500"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        {/* Form Content */}
        <form onSubmit={handleSubmit}>
          {/* Step indicators */}
          <div className="flex items-center justify-center py-3 px-4 bg-gray-50">
            <div className={`w-4 h-4 rounded-full ${step >= 1 ? "bg-purple-600" : "bg-gray-300"} flex items-center justify-center text-white text-xs`}>
              1
            </div>
            <div className={`w-20 h-1 ${step >= 2 ? "bg-purple-600" : "bg-gray-300"}`}></div>
            <div className={`w-4 h-4 rounded-full ${step >= 2 ? "bg-purple-600" : "bg-gray-300"} flex items-center justify-center text-white text-xs`}>
              2
            </div>
          </div>
          
          {/* Form Fields - Step 1 */}
          {step === 1 && (
            <div className="p-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Campaign Title</Label>
                <Input
                  id="title"
                  placeholder="e.g. Summer Collection Promotion"
                  value={formData.title}
                  onChange={(e) => handleChange("title", e.target.value)}
                  className={errors.title ? "border-red-500" : ""}
                />
                {errors.title && <p className="text-red-500 text-xs">{errors.title}</p>}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">Campaign Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe what this campaign is about..."
                  value={formData.description}
                  onChange={(e) => handleChange("description", e.target.value)}
                  className={`min-h-[100px] ${errors.description ? "border-red-500" : ""}`}
                />
                {errors.description && <p className="text-red-500 text-xs">{errors.description}</p>}
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="content-type">Content Type</Label>
                  <Select 
                    value={formData.content_type}
                    onValueChange={(value) => handleChange("content_type", value)}
                  >
                    <SelectTrigger id="content-type">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="post">Instagram Post</SelectItem>
                      <SelectItem value="story">Instagram Story</SelectItem>
                      <SelectItem value="reel">Instagram Reel</SelectItem>
                      <SelectItem value="tiktok">TikTok Video</SelectItem>
                      <SelectItem value="youtube">YouTube Video</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="quantity">Number of Posts</Label>
                  <Select
                    value={formData.quantity.toString()}
                    onValueChange={(value) => handleChange("quantity", parseInt(value))}
                  >
                    <SelectTrigger id="quantity">
                      <SelectValue placeholder="Select quantity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1</SelectItem>
                      <SelectItem value="2">2</SelectItem>
                      <SelectItem value="3">3</SelectItem>
                      <SelectItem value="4">4</SelectItem>
                      <SelectItem value="5">5</SelectItem>
                      <SelectItem value="6">6+</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          )}
          
          {/* Form Fields - Step 2 */}
          {step === 2 && (
            <div className="p-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="budget" className="flex items-center">
                  <DollarSign className="w-4 h-4 mr-1" />
                  Budget
                </Label>
                <Input
                  id="budget"
                  type="number"
                  placeholder="e.g. 500"
                  value={formData.budget}
                  onChange={(e) => handleChange("budget", e.target.value)}
                  className={errors.budget ? "border-red-500" : ""}
                />
                {errors.budget && <p className="text-red-500 text-xs">{errors.budget}</p>}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="timeline" className="flex items-center">
                  <Calendar className="w-4 h-4 mr-1" />
                  Timeline
                </Label>
                <Select
                  value={formData.timeline}
                  onValueChange={(value) => handleChange("timeline", value)}
                >
                  <SelectTrigger id="timeline">
                    <SelectValue placeholder="Select timeline" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1_week">1 Week</SelectItem>
                    <SelectItem value="2_weeks">2 Weeks</SelectItem>
                    <SelectItem value="1_month">1 Month</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="deadline">Deadline Date</Label>
                <Input
                  id="deadline"
                  type="date"
                  value={formData.deadline}
                  onChange={(e) => handleChange("deadline", e.target.value)}
                  className={errors.deadline ? "border-red-500" : ""}
                />
                {errors.deadline && <p className="text-red-500 text-xs">{errors.deadline}</p>}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="additional_notes">Additional Notes (Optional)</Label>
                <Textarea
                  id="additional_notes"
                  placeholder="Any specific requirements or details..."
                  value={formData.additional_notes}
                  onChange={(e) => handleChange("additional_notes", e.target.value)}
                  className="min-h-[80px]"
                />
              </div>
            </div>
          )}
          
          {/* Form Actions */}
          <div className="p-4 border-t flex justify-between">
            {step > 1 ? (
              <Button
                type="button"
                variant="outline"
                onClick={() => setStep(step - 1)}
              >
                Back
              </Button>
            ) : (
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
              >
                Cancel
              </Button>
            )}
            
            <Button
              type="submit"
              className="bg-gradient-to-r from-purple-600 to-pink-600 text-white"
            >
              {step < 2 ? (
                <>
                  Next Step
                  <ArrowRight className="ml-2 h-4 w-4" />
                </>
              ) : (
                <>
                  Submit Proposal
                  <CheckCircle className="ml-2 h-4 w-4" />
                </>
              )}
            </Button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
}