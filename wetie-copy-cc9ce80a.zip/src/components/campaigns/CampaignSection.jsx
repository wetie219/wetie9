import React from 'react';
import { motion } from 'framer-motion';
import CampaignCard from './CampaignCard';

export default function CampaignSection({ title, icon, campaigns, variant }) {
  if (campaigns.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-4"
    >
      <div className="flex items-center gap-2">
        <span className="text-2xl">{icon}</span>
        <h2 className="text-lg font-bold tracking-tight">{title}</h2>
        <span className="text-sm text-gray-500">({campaigns.length})</span>
      </div>

      <div className="space-y-4">
        {campaigns.map((campaign) => (
          <CampaignCard
            key={campaign.id}
            campaign={campaign}
            variant={variant}
          />
        ))}
      </div>
    </motion.div>
  );
}