import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Instagram, AlertCircle } from "lucide-react";

export default function InfluencerSocial({ formData, updateFormData }) {
  const [error, setError] = useState("");
  
  const handleInstagramChange = (e) => {
    const handle = e.target.value;
    
    // Remove @ if user added it
    const cleanHandle = handle.startsWith('@') ? handle.substring(1) : handle;
    
    // Validate: only letters, numbers, periods, and underscores
    if (cleanHandle && !/^[a-zA-Z0-9._]+$/.test(cleanHandle)) {
      setError("Instagram handle can only contain letters, numbers, periods, and underscores");
    } else {
      setError("");
    }
    
    // Update form data with platforms object
    updateFormData({
      platforms: {
        ...(formData.platforms || {}),
        instagram: {
          ...(formData.platforms?.instagram || {}),
          handle: cleanHandle
        }
      }
    });
  };
  
  return (
    <div>
      <h2 className="text-2xl font-bold text-center mb-2">Connect Your Social Media</h2>
      <p className="text-gray-600 text-center mb-8">
        Link your social accounts to help brands find you
      </p>
      
      <div className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="instagram_handle" className="flex items-center gap-2">
            <Instagram className="w-5 h-5 text-[#E1306C]" />
            Instagram Handle <span className="text-red-500">*</span>
          </Label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
              @
            </span>
            <Input 
              id="instagram_handle"
              className="pl-8"
              placeholder="yourusername"
              value={formData.platforms?.instagram?.handle || ""}
              onChange={handleInstagramChange}
              required
            />
          </div>
          {error && (
            <div className="text-red-500 text-sm flex items-center gap-1 mt-1">
              <AlertCircle className="w-4 h-4" />
              {error}
            </div>
          )}
          <p className="text-sm text-gray-500">
            We'll use this to help brands connect to your content
          </p>
        </div>
        
        {/* Additional social platforms can be added here in the future */}
      </div>
    </div>
  );
}