import React from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Target, 
  Users, 
  MapPin, 
  PieChart,
  Zap,
  Instagram,
  Music,
  Youtube,
  Megaphone,
  Rocket,
  ShoppingBag,
  FileText,
  ChevronRight,
  Sparkles
} from "lucide-react";
import { motion } from "framer-motion";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function MatchingPreview({ formData, suggestedInfluencers = [] }) {
  // Map campaign goals to icons
  const goalIcons = {
    "brand_awareness": Megaphone,
    "product_launch": Rocket,
    "sales_boost": ShoppingBag,
    "community_engagement": Users,
    "content_creation": FileText
  };
  
  // Map platforms to icons
  const platformIcons = {
    "instagram": Instagram,
    "tiktok": Music,
    "youtube": Youtube
  };

  // Check if we have enough data for matching
  const showMatchingPreview = 
    formData.industry && 
    (formData.preferred_platforms?.length > 0 || 
     formData.campaign_goals?.length > 0 || 
     formData.target_audience?.age_range?.length > 0);

  return (
    <Card className="p-6 bg-gradient-to-r from-gray-50 to-gray-100 shadow-sm">
      <h2 className="text-lg font-semibold flex items-center gap-2 mb-6">
        <Target className="w-5 h-5 text-purple-600" />
        Matching Preview
      </h2>
      
      <div className="space-y-5">
        {/* Platform Targeting */}
        {formData.preferred_platforms?.length > 0 && (
          <div>
            <h3 className="text-sm font-medium flex items-center gap-2 mb-3">
              <Zap className="w-4 h-4 text-gray-500" />
              Platform Targeting
            </h3>
            
            <div className="flex flex-wrap gap-2">
              {formData.preferred_platforms.map(platform => {
                const PlatformIcon = platformIcons[platform];
                return (
                  <Badge key={platform} className="bg-purple-100 text-purple-800 px-3 py-1.5">
                    {PlatformIcon && <PlatformIcon className="w-3 h-3 mr-1" />}
                    {platform.charAt(0).toUpperCase() + platform.slice(1)}
                  </Badge>
                );
              })}
            </div>
          </div>
        )}
        
        {/* Campaign Goals */}
        {formData.campaign_goals?.length > 0 && (
          <div>
            <h3 className="text-sm font-medium flex items-center gap-2 mb-3">
              <Target className="w-4 h-4 text-gray-500" />
              Campaign Goals
            </h3>
            
            <div className="flex flex-wrap gap-2">
              {formData.campaign_goals.map(goal => {
                const GoalIcon = goalIcons[goal];
                const label = goal.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
                
                return (
                  <Badge key={goal} className="bg-blue-100 text-blue-800 px-3 py-1.5">
                    {GoalIcon && <GoalIcon className="w-3 h-3 mr-1" />}
                    {label}
                  </Badge>
                );
              })}
            </div>
          </div>
        )}
        
        {/* Target Demographics */}
        {formData.target_audience?.age_range?.length > 0 && (
          <div>
            <h3 className="text-sm font-medium flex items-center gap-2 mb-3">
              <Users className="w-4 h-4 text-gray-500" />
              Target Demographics
            </h3>
            
            <div className="flex flex-wrap gap-2">
              {formData.target_audience.age_range.map(age => (
                <Badge key={age} className="bg-green-100 text-green-800 px-3 py-1.5">
                  <PieChart className="w-3 h-3 mr-1" />
                  Age {age}
                </Badge>
              ))}
              
              {formData.target_audience.gender?.length > 0 && 
                formData.target_audience.gender.map(gender => (
                  <Badge key={gender} className="bg-green-100 text-green-800 px-3 py-1.5">
                    <Users className="w-3 h-3 mr-1" />
                    {gender.charAt(0).toUpperCase() + gender.slice(1)}
                  </Badge>
                ))
              }
            </div>
          </div>
        )}
        
        {/* Location */}
        {formData.location && (
          <div>
            <h3 className="text-sm font-medium flex items-center gap-2 mb-3">
              <MapPin className="w-4 h-4 text-gray-500" />
              Location
            </h3>
            
            <Badge className="bg-amber-100 text-amber-800 px-3 py-1.5">
              <MapPin className="w-3 h-3 mr-1" />
              {formData.location}
            </Badge>
          </div>
        )}

        {/* Suggested Influencers */}
        {showMatchingPreview && suggestedInfluencers?.length > 0 && (
          <>
            <div className="border-t border-gray-200 my-4 pt-4">
              <h3 className="text-sm font-medium flex items-center gap-2 mb-4">
                <Sparkles className="w-4 h-4 text-amber-500" />
                Suggested Matches
              </h3>
              
              <div className="space-y-3">
                {suggestedInfluencers.map(influencer => (
                  <motion.div 
                    key={influencer.id}
                    whileHover={{ scale: 1.02 }}
                    className="bg-white rounded-lg p-3 flex items-center shadow-sm border border-gray-100"
                  >
                    <div className="flex-1 flex items-center gap-3">
                      <Avatar className="h-10 w-10 border border-gray-200">
                        <AvatarImage src={influencer.image} alt={influencer.name} />
                        <AvatarFallback>{influencer.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      
                      <div>
                        <h4 className="font-medium text-sm">{influencer.name}</h4>
                        <p className="text-xs text-gray-500">{influencer.handle}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <div className="bg-purple-50 text-purple-800 font-medium rounded-full px-2.5 py-1 text-xs">
                        {influencer.matchScore}% Match
                      </div>
                      
                      <button className="text-gray-400 hover:text-gray-600">
                        <ChevronRight className="w-5 h-5" />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
              
              <div className="mt-4">
                <Button 
                  variant="outline" 
                  className="w-full border-purple-200 text-purple-800 hover:bg-purple-50"
                >
                  See All Matches
                  <ChevronRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </div>
            
            <p className="text-sm text-gray-500 mt-4 italic">
              Tip: Complete your profile to improve your match quality
            </p>
          </>
        )}
        
        {!showMatchingPreview && (
          <div className="text-center py-4">
            <p className="text-gray-500 text-sm">
              Add more details to see your matching preview
            </p>
          </div>
        )}
      </div>
    </Card>
  );
}