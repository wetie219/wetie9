
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import {
  Instagram,
  Music2,
  ChevronRight,
  Shield,
  CheckCircle2,
  AlertCircle
} from "lucide-react";
import { motion } from "framer-motion";

// OAuth Configuration
const OAUTH_CONFIG = {
  INSTAGRAM: {
    CLIENT_ID: "your-instagram-client-id", // This should come from your environment variables
    REDIRECT_URI: window.location.origin + "/auth/instagram/callback",
    SCOPES: ["user_profile", "user_media"]
  },
  TIKTOK: {
    CLIENT_KEY: "your-tiktok-client-key", // This should come from your environment variables
    REDIRECT_URI: window.location.origin + "/auth/tiktok/callback",
    SCOPES: ["user.info.basic", "video.list"]
  }
};

/**
 * Social Media Connection Component
 * Handles OAuth connection to Instagram and TikTok
 */
export default function SocialMediaConnect({ onComplete }) {
  const [instagramConnected, setInstagramConnected] = useState(false);
  const [tiktokConnected, setTiktokConnected] = useState(false);
  const [privacySettings, setPrivacySettings] = useState({
    show_gender_stats: true,
    show_age_stats: true,
    show_location_stats: true,
    show_engagement_stats: true
  });

  /**
   * Handle Instagram OAuth Connection
   */
  const connectInstagram = async () => {
    try {
      // Initialize Instagram OAuth flow
      const instagramAuthUrl = `https://api.instagram.com/oauth/authorize?client_id=${OAUTH_CONFIG.INSTAGRAM.CLIENT_ID}&redirect_uri=${OAUTH_CONFIG.INSTAGRAM.REDIRECT_URI}&scope=${OAUTH_CONFIG.INSTAGRAM.SCOPES.join(',')}&response_type=code`;
      
      // Open OAuth popup
      const width = 600;
      const height = 600;
      const left = (window.innerWidth - width) / 2;
      const top = (window.innerHeight - height) / 2;
      
      window.open(
        instagramAuthUrl,
        'Connect Instagram',
        `width=${width},height=${height},left=${left},top=${top}`
      );

      // Handle the OAuth callback
      window.addEventListener('message', async (event) => {
        if (event.data.type === 'INSTAGRAM_AUTH') {
          const { code } = event.data;
          // Exchange code for access token
          // Store token and update UI
          setInstagramConnected(true);
        }
      });
    } catch (error) {
      console.error('Error connecting Instagram:', error);
    }
  };

  /**
   * Handle TikTok OAuth Connection
   */
  const connectTikTok = async () => {
    try {
      // Initialize TikTok OAuth flow
      const tiktokAuthUrl = `https://www.tiktok.com/auth/authorize?client_key=${OAUTH_CONFIG.TIKTOK.CLIENT_KEY}&response_type=code&scope=${OAUTH_CONFIG.TIKTOK.SCOPES.join(',')}&redirect_uri=${OAUTH_CONFIG.TIKTOK.REDIRECT_URI}`;
      
      // Open OAuth popup
      const width = 600;
      const height = 600;
      const left = (window.innerWidth - width) / 2;
      const top = (window.innerHeight - height) / 2;
      
      window.open(
        tiktokAuthUrl,
        'Connect TikTok',
        `width=${width},height=${height},left=${left},top=${top}`
      );

      // Handle the OAuth callback
      window.addEventListener('message', async (event) => {
        if (event.data.type === 'TIKTOK_AUTH') {
          const { code } = event.data;
          // Exchange code for access token
          // Store token and update UI
          setTiktokConnected(true);
        }
      });
    } catch (error) {
      console.error('Error connecting TikTok:', error);
    }
  };

  /**
   * Handle privacy setting changes
   */
  const handlePrivacyChange = (setting) => {
    setPrivacySettings(prev => ({
      ...prev,
      [setting]: !prev[setting]
    }));
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold mb-2">Connect Your Accounts</h2>
        <p className="text-gray-600">
          Connect your social media accounts to verify your influence and show brands real stats
        </p>
      </div>

      {/* Instagram Connection */}
      <Card className="relative overflow-hidden">
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-pink-500/10"
          animate={{
            opacity: [0.5, 0.8, 0.5],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
          }}
        />
        <div className="p-6 relative">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Instagram className="w-8 h-8 text-pink-600" />
              <div>
                <h3 className="font-semibold text-lg">Instagram</h3>
                <p className="text-sm text-gray-600">Connect your creator account</p>
              </div>
            </div>
            {instagramConnected ? (
              <CheckCircle2 className="w-6 h-6 text-green-500" />
            ) : (
              <Button onClick={connectInstagram}>
                Connect
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            )}
          </div>
        </div>
      </Card>

      {/* TikTok Connection */}
      <Card className="relative overflow-hidden">
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-red-500/10"
          animate={{
            opacity: [0.5, 0.8, 0.5],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
          }}
        />
        <div className="p-6 relative">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Music2 className="w-8 h-8 text-black" />
              <div>
                <h3 className="font-semibold text-lg">TikTok</h3>
                <p className="text-sm text-gray-600">Connect your creator account</p>
              </div>
            </div>
            {tiktokConnected ? (
              <CheckCircle2 className="w-6 h-6 text-green-500" />
            ) : (
              <Button onClick={connectTikTok}>
                Connect
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            )}
          </div>
        </div>
      </Card>

      {/* Privacy Settings */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Shield className="w-5 h-5 text-purple-600" />
          <h3 className="font-semibold">Privacy Settings</h3>
        </div>
        
        <div className="space-y-4">
          {Object.entries(privacySettings).map(([key, value]) => (
            <div key={key} className="flex items-center justify-between">
              <div>
                <p className="font-medium">
                  {key.split('_').map(word => 
                    word.charAt(0).toUpperCase() + word.slice(1)
                  ).join(' ')}
                </p>
                <p className="text-sm text-gray-600">
                  Show this data to brands
                </p>
              </div>
              <Switch
                checked={value}
                onCheckedChange={() => handlePrivacyChange(key)}
              />
            </div>
          ))}
        </div>
      </Card>

      {/* Warning if not connected */}
      {!instagramConnected && !tiktokConnected && (
        <div className="flex items-center gap-2 p-4 bg-orange-50 rounded-lg text-orange-700">
          <AlertCircle className="w-5 h-5" />
          <p className="text-sm">
            Connecting your accounts helps verify your influence and build trust with brands
          </p>
        </div>
      )}

      {/* Continue Button */}
      <Button
        className="w-full"
        onClick={onComplete}
        disabled={!instagramConnected && !tiktokConnected}
      >
        Continue
      </Button>
    </div>
  );
}
