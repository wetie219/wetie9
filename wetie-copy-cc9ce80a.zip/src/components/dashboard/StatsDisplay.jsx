
import React from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import {
  TrendingUp,
  Users,
  Globe,
  Clock,
  ChevronRight,
  Eye,
  Heart,
  MessageCircle
} from "lucide-react";
import { motion } from "framer-motion";

/**
 * Displays verified social media statistics
 */
export default function StatsDisplay({ stats, privacySettings }) {
  if (!stats) return null;

  const formatNumber = (num) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num;
  };

  return (
    <div className="space-y-6">
      {/* Instagram Stats */}
      {stats.instagram?.connected && (
        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold">Instagram Insights</h3>
            <Badge variant="secondary" className="bg-gradient-to-r from-purple-100 to-pink-100">
              <Clock className="w-3 h-3 mr-1" />
              Updated {new Date(stats.last_updated).toLocaleDateString()}
            </Badge>
          </div>

          {/* Followers and Engagement */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-gray-50 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Users className="w-4 h-4 text-gray-600" />
                <span className="text-sm text-gray-600">Followers</span>
              </div>
              <div className="text-2xl font-bold">
                {formatNumber(stats.instagram.followers)}
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-gray-600" />
                <span className="text-sm text-gray-600">Engagement</span>
              </div>
              <div className="text-2xl font-bold">
                {stats.instagram.engagement_rate}%
              </div>
            </div>
          </div>

          {/* Demographics */}
          {privacySettings.show_gender_stats && (
            <div className="mb-6">
              <h4 className="text-sm font-medium mb-2">Gender Distribution</h4>
              <div className="flex gap-4">
                <div className="flex-1">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Female</span>
                    <span>{stats.instagram.gender_split.female}%</span>
                  </div>
                  <Progress value={stats.instagram.gender_split.female} />
                </div>
                <div className="flex-1">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Male</span>
                    <span>{stats.instagram.gender_split.male}%</span>
                  </div>
                  <Progress value={stats.instagram.gender_split.male} />
                </div>
              </div>
            </div>
          )}

          {/* Age Distribution */}
          {privacySettings.show_age_stats && (
            <div className="mb-6">
              <h4 className="text-sm font-medium mb-2">Age Distribution</h4>
              <div className="space-y-2">
                {Object.entries(stats.instagram.age_distribution).map(([age, percentage]) => (
                  <div key={age}>
                    <div className="flex justify-between text-sm mb-1">
                      <span>{age}</span>
                      <span>{percentage}%</span>
                    </div>
                    <Progress value={percentage} />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Top Locations */}
          {privacySettings.show_location_stats && (
            <div>
              <h4 className="text-sm font-medium mb-2">Top Locations</h4>
              <div className="space-y-2">
                {stats.instagram.top_locations.map((location, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Globe className="w-4 h-4 text-gray-600" />
                    <span>{location.city}, {location.country}</span>
                    <span className="text-sm text-gray-600 ml-auto">
                      {location.percentage}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Card>
      )}

      {/* TikTok Stats */}
      {stats.tiktok?.connected && (
        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold">TikTok Insights</h3>
            <Badge variant="secondary" className="bg-gradient-to-r from-blue-100 to-red-100">
              <Clock className="w-3 h-3 mr-1" />
              Updated {new Date(stats.last_updated).toLocaleDateString()}
            </Badge>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="bg-gray-50 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Users className="w-4 h-4 text-gray-600" />
                <span className="text-sm text-gray-600">Followers</span>
              </div>
              <div className="text-xl font-bold">
                {formatNumber(stats.tiktok.followers)}
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Heart className="w-4 h-4 text-gray-600" />
                <span className="text-sm text-gray-600">Likes</span>
              </div>
              <div className="text-xl font-bold">
                {formatNumber(stats.tiktok.total_likes)}
              </div>
            </div>
            
            <div className="bg-gray-50 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Eye className="w-4 h-4 text-gray-600" />
                <span className="text-sm text-gray-600">Views</span>
              </div>
              <div className="text-xl font-bold">
                {formatNumber(stats.tiktok.video_views)}
              </div>
            </div>
          </div>

          {/* Demographics */}
          {privacySettings.show_gender_stats && stats.tiktok.demographics && (
            <div className="mb-6">
              <h4 className="text-sm font-medium mb-2">Audience Demographics</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h5 className="text-sm text-gray-600 mb-2">Gender</h5>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Female</span>
                      <span>{stats.tiktok.demographics.gender.female}%</span>
                    </div>
                    <Progress value={stats.tiktok.demographics.gender.female} />
                    <div className="flex justify-between text-sm">
                      <span>Male</span>
                      <span>{stats.tiktok.demographics.gender.male}%</span>
                    </div>
                    <Progress value={stats.tiktok.demographics.gender.male} />
                  </div>
                </div>
                
                <div>
                  <h5 className="text-sm text-gray-600 mb-2">Age Groups</h5>
                  <div className="space-y-2">
                    {Object.entries(stats.tiktok.demographics.age_groups).map(([age, percentage]) => (
                      <div key={age}>
                        <div className="flex justify-between text-sm">
                          <span>{age}</span>
                          <span>{percentage}%</span>
                        </div>
                        <Progress value={percentage} />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Top Locations */}
          {privacySettings.show_location_stats && (
            <div>
              <h4 className="text-sm font-medium mb-2">Top Locations</h4>
              <div className="space-y-2">
                {stats.tiktok.top_locations.map((location, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Globe className="w-4 h-4 text-gray-600" />
                    <span>{location.country}</span>
                    <span className="text-sm text-gray-600 ml-auto">
                      {location.percentage}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Card>
      )}

      {/* Not Connected State */}
      {(!stats.instagram?.connected && !stats.tiktok?.connected) && (
        <div className="text-center py-8">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="mb-4"
          >
            <Users className="w-16 h-16 mx-auto text-gray-400" />
          </motion.div>
          <h3 className="text-lg font-medium mb-2">Connect Your Accounts</h3>
          <p className="text-gray-600 mb-4">
            Connect your social media accounts to show verified stats to brands
          </p>
          <Button>
            Connect Now
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
      )}
    </div>
  );
}
