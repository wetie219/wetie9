import React from "react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

/**
 * Campaign tabs component
 * Allows switching between different campaign statuses
 * 
 * @param {string} activeTab - Currently active tab
 * @param {Function} setActiveTab - Function to set active tab
 * @param {Object} counts - Object containing counts for each tab
 */
export default function CampaignTabs({ activeTab, setActiveTab, counts = {} }) {
  /**
   * Get animation style for count badge
   * @param {string} tabId - Tab identifier
   * @returns {Object} - Animation properties
   */
  const getCountAnimation = (tabId) => {
    if (tabId === activeTab) {
      return { scale: [1, 1.2, 1], transition: { duration: 0.3 } };
    }
    return { scale: 1 };
  };

  return (
    <Tabs 
      value={activeTab} 
      onValueChange={setActiveTab}
      className="w-full"
    >
      <TabsList className="grid grid-cols-3 bg-gray-100/70 rounded-xl p-1 h-auto">
        <TabsTrigger 
          value="pending" 
          className="rounded-lg py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm"
        >
          <div className="relative">
            Pending
            {counts.pending > 0 && (
              <motion.div 
                animate={getCountAnimation('pending')}
                className="absolute -top-1 -right-4"
              >
                <Badge 
                  className="h-5 min-w-5 flex items-center justify-center rounded-full bg-orange-500 px-[5px] text-[10px] font-medium text-white"
                >
                  {counts.pending}
                </Badge>
              </motion.div>
            )}
          </div>
        </TabsTrigger>
        
        <TabsTrigger 
          value="active" 
          className="rounded-lg py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm"
        >
          <div className="relative">
            Active
            {counts.active > 0 && (
              <motion.div 
                animate={getCountAnimation('active')}
                className="absolute -top-1 -right-4"
              >
                <Badge 
                  className="h-5 min-w-5 flex items-center justify-center rounded-full bg-blue-500 px-[5px] text-[10px] font-medium text-white"
                >
                  {counts.active}
                </Badge>
              </motion.div>
            )}
          </div>
        </TabsTrigger>
        
        <TabsTrigger 
          value="completed" 
          className="rounded-lg py-2 data-[state=active]:bg-white data-[state=active]:shadow-sm"
        >
          <div className="relative">
            Completed
            {counts.completed > 0 && (
              <motion.div 
                animate={getCountAnimation('completed')}
                className="absolute -top-1 -right-4"
              >
                <Badge 
                  className="h-5 min-w-5 flex items-center justify-center rounded-full bg-green-500 px-[5px] text-[10px] font-medium text-white"
                >
                  {counts.completed}
                </Badge>
              </motion.div>
            )}
          </div>
        </TabsTrigger>
      </TabsList>
    </Tabs>
  );
}