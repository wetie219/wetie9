import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { MapPin, Globe } from "lucide-react";

export default function InfluencerLocation({ formData, updateFormData }) {
  const languages = [
    "English", "Arabic", "French", "Spanish", "Chinese", 
    "Hindi", "Russian", "Japanese", "Korean", "German"
  ];

  const handleLocationChange = (e) => {
    updateFormData({ location: e.target.value });
  };

  const toggleLanguage = (language) => {
    const currentLanguages = formData.languages || [];
    if (currentLanguages.includes(language)) {
      updateFormData({
        languages: currentLanguages.filter(lang => lang !== language)
      });
    } else {
      updateFormData({
        languages: [...currentLanguages, language]
      });
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-center mb-2">Location & Languages</h2>
      <p className="text-gray-600 text-center mb-8">
        Help brands find you based on your location
      </p>

      <div className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="location" className="flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            Your Location
          </Label>
          <Input
            id="location"
            placeholder="City, Country"
            value={formData.location || ""}
            onChange={handleLocationChange}
          />
          <p className="text-sm text-gray-500">
            Enter your primary content creation location
          </p>
        </div>

        <div className="space-y-2">
          <Label className="flex items-center gap-2">
            <Globe className="w-4 h-4" />
            Languages You Speak
          </Label>
          <div className="flex flex-wrap gap-2">
            {languages.map(language => (
              <Badge
                key={language}
                variant={formData.languages?.includes(language) ? "default" : "outline"}
                className={`cursor-pointer ${
                  formData.languages?.includes(language)
                    ? "bg-[#2F2C7F] hover:bg-[#23216d]"
                    : "hover:bg-gray-100"
                }`}
                onClick={() => toggleLanguage(language)}
              >
                {language}
              </Badge>
            ))}
          </div>
          <p className="text-sm text-gray-500">
            Select all languages you can create content in
          </p>
        </div>
      </div>
    </div>
  );
}