import React from 'react';
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import {
  Star,
  MapPin,
  Instagram,
  Youtube,
  Music as TikTok,
  Upload,
  CheckCircle2
} from "lucide-react";

export default function ProfileHeader({ profile, stats, editMode, onUpload, uploadProgress }) {
  return (
    <div className="text-center">
      {/* Profile Picture */}
      <div className="relative inline-block">
        <motion.div
          className="w-32 h-32 rounded-full overflow-hidden ring-4 ring-white shadow-xl relative group"
          whileHover={editMode ? { scale: 1.05 } : {}}
        >
          <img
            src={profile.profile_picture || "https://via.placeholder.com/200"}
            alt={profile.full_name}
            className="w-full h-full object-cover"
          />
          {editMode && (
            <div
              className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
              onClick={() => document.getElementById('profile-upload').click()}
            >
              <Upload className="w-8 h-8 text-white" />
              <input
                id="profile-upload"
                type="file"
                className="hidden"
                accept="image/*"
                onChange={(e) => onUpload(e.target.files[0])}
              />
            </div>
          )}
        </motion.div>

        {profile.verified && (
          <Badge
            className="absolute bottom-2 right-2 bg-gradient-to-r from-purple-600 to-pink-600"
          >
            <Star className="w-3 h-3 text-white" />
          </Badge>
        )}
      </div>

      {/* Name and Handle */}
      <div className="mt-4">
        <div className="flex items-center justify-center gap-2">
          <h1 className="text-2xl font-bold">{profile.full_name}</h1>
          {profile.verified && (
            <CheckCircle2 className="w-5 h-5 text-blue-500" />
          )}
        </div>
        <p className="text-gray-600">@{profile.username}</p>
      </div>

      {/* Location */}
      <div className="flex items-center justify-center gap-1 mt-2 text-gray-600">
        <MapPin className="w-4 h-4" />
        <span>{profile.location}</span>
      </div>

      {/* Platform Stats */}
      <div className="flex items-center justify-center gap-6 mt-4">
        {stats?.instagram?.connected && (
          <div className="flex items-center gap-2">
            <Instagram className="w-5 h-5 text-pink-600" />
            <span className="font-semibold">
              {(stats.instagram.followers / 1000).toFixed(1)}K
            </span>
          </div>
        )}
        {stats?.tiktok?.connected && (
          <div className="flex items-center gap-2">
            <TikTok className="w-5 h-5" />
            <span className="font-semibold">
              {(stats.tiktok.followers / 1000).toFixed(1)}K
            </span>
          </div>
        )}
        {stats?.youtube?.connected && (
          <div className="flex items-center gap-2">
            <Youtube className="w-5 h-5 text-red-600" />
            <span className="font-semibold">
              {(stats.youtube.subscribers / 1000).toFixed(1)}K
            </span>
          </div>
        )}
      </div>

      {/* Bio */}
      <p className="mt-4 max-w-xl mx-auto text-gray-700">
        {profile.bio}
      </p>
    </div>
  );
}