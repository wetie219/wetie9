import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Building2, Camera } from "lucide-react";
import { User } from "@/api/entities";

export default function UserTypeSelection({ onNextStep, onSelectType }) {
  const [selectedType, setSelectedType] = React.useState(null);

  const handleSelection = (type) => {
    setSelectedType(type);
    onSelectType(type);
  };

  const handleContinue = async () => {
    if (!selectedType) return;
    
    try {
      // Update user data
      await User.updateMyUserData({
        user_type: selectedType
      });
      
      // Move to next step
      onNextStep();
    } catch (error) {
      console.error("Error updating user type:", error);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-3xl font-bold text-center mb-8">Are You?</h1>

        <div className="space-y-4">
          <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }}>
            <Button
              type="button"
              variant="outline"
              className={`w-full h-20 flex items-center justify-center gap-3 border-2 text-xl ${
                selectedType === "brand"
                  ? "bg-gradient-to-r from-[#1F1147] to-[#C625FF] text-white border-transparent"
                  : "border-gray-300 hover:border-purple-400"
              }`}
              onClick={() => handleSelection("brand")}
            >
              <Building2 className="w-6 h-6" />
              Brand
            </Button>
          </motion.div>

          <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }}>
            <Button
              type="button"
              variant="outline"
              className={`w-full h-20 flex items-center justify-center gap-3 border-2 text-xl ${
                selectedType === "influencer"
                  ? "bg-gradient-to-r from-[#1F1147] to-[#C625FF] text-white border-transparent"
                  : "border-gray-300 hover:border-purple-400"
              }`}
              onClick={() => handleSelection("influencer")}
            >
              <Camera className="w-6 h-6" />
              Influencer
            </Button>
          </motion.div>
        </div>

        <div className="mt-12 flex justify-end">
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              onClick={handleContinue}
              disabled={!selectedType}
              className={`rounded-full w-14 h-14 ${
                selectedType
                  ? "bg-gradient-to-r from-[#1F1147] to-[#C625FF]"
                  : "bg-gray-300"
              }`}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-white"
              >
                <path d="M5 12h14" />
                <path d="m12 5 7 7-7 7" />
              </svg>
            </Button>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}