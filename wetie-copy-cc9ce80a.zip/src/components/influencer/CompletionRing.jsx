import React from 'react';
import { motion } from "framer-motion";
import { Sparkles, CheckCircle2 } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export default function CompletionRing({ percentage }) {
  const radius = 20;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <motion.div
            className="relative"
            whileHover={{ scale: 1.1 }}
            animate={{ 
              scale: [1, 1.05, 1],
              rotate: percentage === 100 ? [0, 5, -5, 0] : [0, 0, 0, 0]
            }}
            transition={{ 
              duration: percentage === 100 ? 0.5 : 0.3,
              repeat: percentage === 100 ? 0 : Infinity,
              repeatType: "reverse",
              repeatDelay: 5
            }}
          >
            <div className="relative">
              <svg width="46" height="46" className="transform -rotate-90">
                <circle
                  cx="23"
                  cy="23"
                  r={radius}
                  stroke="#e2e8f0"
                  strokeWidth="4"
                  fill="none"
                />
                <circle
                  cx="23"
                  cy="23"
                  r={radius}
                  stroke="url(#gradient)"
                  strokeWidth="4"
                  fill="none"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                />
                <defs>
                  <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#9333ea" />
                    <stop offset="100%" stopColor="#ec4899" />
                  </linearGradient>
                </defs>
              </svg>
              
              {percentage === 100 ? (
                <CheckCircle2 className="w-6 h-6 text-green-500 absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2" />
              ) : (
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <Sparkles className="w-5 h-5 text-purple-500" />
                </div>
              )}
            </div>
            
            {percentage === 100 && (
              <motion.div
                className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full"
                initial={{ scale: 0 }}
                animate={{ scale: [0, 1.2, 1] }}
                transition={{ delay: 0.2, duration: 0.5 }}
              />
            )}
          </motion.div>
        </TooltipTrigger>
        <TooltipContent side="left">
          <p>Profile {percentage}% complete</p>
          {percentage < 100 && (
            <p className="text-xs text-gray-400">Complete your profile to get discovered faster</p>
          )}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}