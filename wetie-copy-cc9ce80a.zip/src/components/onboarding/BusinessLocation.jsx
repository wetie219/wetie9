import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Plus, X } from "lucide-react";

export default function BusinessLocation({ formData, updateFormData }) {
  const [newLocation, setNewLocation] = useState("");

  const addLocation = () => {
    if (!newLocation.trim()) return;
    
    const currentLocations = formData.locations || [];
    if (!currentLocations.includes(newLocation)) {
      updateFormData({
        locations: [...currentLocations, newLocation.trim()]
      });
    }
    setNewLocation("");
  };

  const removeLocation = (location) => {
    const currentLocations = formData.locations || [];
    updateFormData({
      locations: currentLocations.filter(loc => loc !== location)
    });
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      addLocation();
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-center mb-2">Business Locations</h2>
      <p className="text-gray-600 text-center mb-8">
        Where do you want to find influencers?
      </p>

      <div className="space-y-6">
        <div className="space-y-2">
          <Label className="flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            Add Location
          </Label>
          <div className="flex gap-2">
            <Input
              placeholder="City, Country"
              value={newLocation}
              onChange={(e) => setNewLocation(e.target.value)}
              onKeyPress={handleKeyPress}
            />
            <Button
              type="button"
              variant="outline"
              onClick={addLocation}
              disabled={!newLocation.trim()}
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div>
          <Label>Added Locations</Label>
          <div className="flex flex-wrap gap-2 mt-2 min-h-[100px] p-4 bg-gray-50 rounded-lg">
            {(formData.locations || []).length === 0 ? (
              <p className="text-gray-400">No locations added yet</p>
            ) : (
              formData.locations.map(location => (
                <Badge
                  key={location}
                  className="bg-white text-gray-700 border flex items-center gap-1 pl-3"
                >
                  {location}
                  <button
                    onClick={() => removeLocation(location)}
                    className="ml-1 hover:bg-gray-100 rounded-full p-1"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))
            )}
          </div>
          <p className="text-sm text-gray-500 mt-2">
            Add multiple locations where you want to find influencers
          </p>
        </div>
      </div>
    </div>
  );
}