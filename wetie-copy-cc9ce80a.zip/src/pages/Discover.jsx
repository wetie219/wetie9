import React, { useState, useEffect } from "react";
import { Influencer } from "@/api/entities";
import { Match } from "@/api/entities";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Search,
  Heart,
  X,
  Filter,
  Instagram,
  Youtube,
  Music,
  Tag
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Discover() {
  const navigate = useNavigate();
  const [influencers, setInfluencers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [filterVisible, setFilterVisible] = useState(false);
  const [filters, setFilters] = useState({
    niches: [],
    minFollowers: 0,
    platforms: []
  });

  useEffect(() => {
    loadInfluencers();
  }, []);

  const loadInfluencers = async () => {
    try {
      const data = await Influencer.list();
      setInfluencers(data);
    } catch (error) {
      console.error("Error loading influencers:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleLike = async () => {
    if (currentIndex >= influencers.length) return;
    
    try {
      const influencer = influencers[currentIndex];
      // In a real app, we would create a match here
      // await Match.create({
      //   business_id: business.id,
      //   influencer_id: influencer.id,
      //   status: "pending",
      //   initiated_by: "business"
      // });
      setCurrentIndex(currentIndex + 1);
    } catch (error) {
      console.error("Error creating match:", error);
    }
  };

  const handleDislike = () => {
    setCurrentIndex(currentIndex + 1);
  };

  const handleViewDetails = (influencer) => {
    navigate(createPageUrl("InfluencerProfile") + `?id=${influencer.id}`);
  };

  const handleSearch = () => {
    setSearchTerm(searchInput);
  };

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => {
      if (filterType === "niches") {
        return {
          ...prev,
          niches: prev.niches.includes(value)
            ? prev.niches.filter(item => item !== value)
            : [...prev.niches, value]
        };
      }
      if (filterType === "platforms") {
        return {
          ...prev,
          platforms: prev.platforms.includes(value)
            ? prev.platforms.filter(item => item !== value)
            : [...prev.platforms, value]
        };
      }
      return { ...prev, [filterType]: value };
    });
  };

  const filteredInfluencers = influencers.filter(influencer => {
    // Search term filter
    if (searchTerm && !influencer.full_name.toLowerCase().includes(searchTerm.toLowerCase()) &&
        !influencer.bio.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }

    // Niche filter
    if (filters.niches.length > 0 && !influencer.niche.some(niche => filters.niches.includes(niche))) {
      return false;
    }

    // Platform filter
    if (filters.platforms.length > 0) {
      const hasPlatform = filters.platforms.some(platform => {
        return influencer.platforms[platform] && influencer.platforms[platform].handle;
      });
      if (!hasPlatform) return false;
    }

    // Followers filter
    if (filters.minFollowers > 0) {
      const totalFollowers = (influencer.platforms.instagram?.followers || 0) + 
                           (influencer.platforms.tiktok?.followers || 0) + 
                           (influencer.platforms.youtube?.subscribers || 0);
      if (totalFollowers < filters.minFollowers) return false;
    }

    return true;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (filteredInfluencers.length === 0) {
    return (
      <div className="p-4 pb-24">
        <div className="flex items-center mb-4">
          <h1 className="text-2xl font-bold flex-1">Discover</h1>
          <Button
            variant="outline"
            size="icon"
            onClick={() => setFilterVisible(!filterVisible)}
          >
            <Filter className="h-4 w-4" />
          </Button>
        </div>

        {/* Search Bar */}
        <div className="flex gap-2 mb-6">
          <Input
            placeholder="Search influencers..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            className="flex-1"
          />
          <Button
            variant="outline"
            onClick={handleSearch}
          >
            <Search className="h-4 w-4" />
          </Button>
        </div>

        {/* Filters */}
        {filterVisible && (
          <Card className="mb-6">
            <CardContent className="p-4">
              <h3 className="font-semibold mb-2">Filters</h3>
              
              <div className="mb-4">
                <h4 className="text-sm font-medium mb-2">Niches</h4>
                <div className="flex flex-wrap gap-2">
                  {["fashion", "beauty", "tech", "food", "fitness", "lifestyle", "gaming"].map(niche => (
                    <Badge
                      key={niche}
                      variant={filters.niches.includes(niche) ? "default" : "outline"}
                      className={`cursor-pointer ${filters.niches.includes(niche) ? "bg-purple-600" : ""}`}
                      onClick={() => handleFilterChange("niches", niche)}
                    >
                      <Tag className="w-3 h-3 mr-1" />
                      {niche}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <div className="mb-4">
                <h4 className="text-sm font-medium mb-2">Platforms</h4>
                <div className="flex flex-wrap gap-2">
                  <Badge
                    variant={filters.platforms.includes("instagram") ? "default" : "outline"}
                    className={`cursor-pointer ${filters.platforms.includes("instagram") ? "bg-pink-600" : ""}`}
                    onClick={() => handleFilterChange("platforms", "instagram")}
                  >
                    <Instagram className="w-3 h-3 mr-1" />
                    Instagram
                  </Badge>
                  <Badge
                    variant={filters.platforms.includes("tiktok") ? "default" : "outline"}
                    className={`cursor-pointer ${filters.platforms.includes("tiktok") ? "bg-black" : ""}`}
                    onClick={() => handleFilterChange("platforms", "tiktok")}
                  >
                    <Music className="w-3 h-3 mr-1" />
                    TikTok
                  </Badge>
                  <Badge
                    variant={filters.platforms.includes("youtube") ? "default" : "outline"}
                    className={`cursor-pointer ${filters.platforms.includes("youtube") ? "bg-red-600" : ""}`}
                    onClick={() => handleFilterChange("platforms", "youtube")}
                  >
                    <Youtube className="w-3 h-3 mr-1" />
                    YouTube
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="flex flex-col items-center justify-center mt-12 text-center">
          <div className="text-gray-500 mb-4">
            No influencers found matching your criteria
          </div>
          <Button 
            variant="outline" 
            onClick={() => {
              setSearchTerm("");
              setSearchInput("");
              setFilters({
                niches: [],
                minFollowers: 0,
                platforms: []
              });
            }}
          >
            Clear Filters
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 pb-24">
      <div className="flex items-center mb-4">
        <h1 className="text-2xl font-bold flex-1">Discover</h1>
        <Button
          variant="outline"
          size="icon"
          onClick={() => setFilterVisible(!filterVisible)}
        >
          <Filter className="h-4 w-4" />
        </Button>
      </div>

      {/* Search Bar */}
      <div className="flex gap-2 mb-6">
        <Input
          placeholder="Search influencers..."
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
          className="flex-1"
        />
        <Button
          variant="outline"
          onClick={handleSearch}
        >
          <Search className="h-4 w-4" />
        </Button>
      </div>

      {/* Filters */}
      {filterVisible && (
        <Card className="mb-6">
          <CardContent className="p-4">
            <h3 className="font-semibold mb-2">Filters</h3>
            
            <div className="mb-4">
              <h4 className="text-sm font-medium mb-2">Niches</h4>
              <div className="flex flex-wrap gap-2">
                {["fashion", "beauty", "tech", "food", "fitness", "lifestyle", "gaming"].map(niche => (
                  <Badge
                    key={niche}
                    variant={filters.niches.includes(niche) ? "default" : "outline"}
                    className={`cursor-pointer ${filters.niches.includes(niche) ? "bg-purple-600" : ""}`}
                    onClick={() => handleFilterChange("niches", niche)}
                  >
                    <Tag className="w-3 h-3 mr-1" />
                    {niche}
                  </Badge>
                ))}
              </div>
            </div>
            
            <div className="mb-4">
              <h4 className="text-sm font-medium mb-2">Platforms</h4>
              <div className="flex flex-wrap gap-2">
                <Badge
                  variant={filters.platforms.includes("instagram") ? "default" : "outline"}
                  className={`cursor-pointer ${filters.platforms.includes("instagram") ? "bg-pink-600" : ""}`}
                  onClick={() => handleFilterChange("platforms", "instagram")}
                >
                  <Instagram className="w-3 h-3 mr-1" />
                  Instagram
                </Badge>
                <Badge
                  variant={filters.platforms.includes("tiktok") ? "default" : "outline"}
                  className={`cursor-pointer ${filters.platforms.includes("tiktok") ? "bg-black" : ""}`}
                  onClick={() => handleFilterChange("platforms", "tiktok")}
                >
                  <Music className="w-3 h-3 mr-1" />
                  TikTok
                </Badge>
                <Badge
                  variant={filters.platforms.includes("youtube") ? "default" : "outline"}
                  className={`cursor-pointer ${filters.platforms.includes("youtube") ? "bg-red-600" : ""}`}
                  onClick={() => handleFilterChange("platforms", "youtube")}
                >
                  <Youtube className="w-3 h-3 mr-1" />
                  YouTube
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Card View */}
      {currentIndex < filteredInfluencers.length ? (
        <Card className="overflow-hidden">
          {/* Profile Image */}
          <div 
            className="h-96 bg-cover bg-center bg-gray-100"
            style={{
              backgroundImage: `url(${filteredInfluencers[currentIndex].profile_picture})`
            }}
          />

          {/* Profile Info */}
          <div className="p-4 space-y-4">
            <div>
              <h2 className="text-xl font-bold">{filteredInfluencers[currentIndex].full_name}</h2>
              <p className="text-gray-600">{filteredInfluencers[currentIndex].bio}</p>
            </div>

            {/* Stats */}
            <div className="flex gap-4">
              {filteredInfluencers[currentIndex].platforms.instagram && (
                <div className="flex items-center gap-2">
                  <Instagram className="w-4 h-4 text-pink-600" />
                  <span className="font-semibold">
                    {(filteredInfluencers[currentIndex].platforms.instagram.followers / 1000).toFixed(1)}K
                  </span>
                </div>
              )}
              {filteredInfluencers[currentIndex].platforms.youtube && (
                <div className="flex items-center gap-2">
                  <Youtube className="w-4 h-4 text-red-600" />
                  <span className="font-semibold">
                    {(filteredInfluencers[currentIndex].platforms.youtube.subscribers / 1000).toFixed(1)}K
                  </span>
                </div>
              )}
            </div>

            {/* Categories */}
            <div className="flex flex-wrap gap-2">
              {filteredInfluencers[currentIndex].niche.map((category, index) => (
                <Badge key={index} variant="secondary">
                  {category}
                </Badge>
              ))}
            </div>

            {/* Engagement Rate */}
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="text-sm text-gray-600">Average Engagement Rate</div>
              <div className="text-lg font-bold text-purple-600">
                {filteredInfluencers[currentIndex].platforms.instagram?.engagement_rate || 
                 filteredInfluencers[currentIndex].platforms.tiktok?.engagement_rate || 0}%
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <CardFooter className="p-4 flex justify-center gap-4">
            <Button
              size="lg"
              variant="outline"
              className="h-16 w-16 rounded-full"
              onClick={handleDislike}
            >
              <X className="w-8 h-8 text-gray-600" />
            </Button>
            <Button
              size="lg"
              className="h-16 w-16 rounded-full bg-purple-600 hover:bg-purple-700"
              onClick={handleLike}
            >
              <Heart className="w-8 h-8" />
            </Button>
          </CardFooter>
        </Card>
      ) : (
        <div className="flex flex-col items-center justify-center mt-12 text-center">
          <div className="text-gray-500 mb-4">
            You've viewed all influencers
          </div>
          <Button 
            variant="outline" 
            onClick={() => setCurrentIndex(0)}
          >
            View Again
          </Button>
        </div>
      )}
    </div>
  );
}