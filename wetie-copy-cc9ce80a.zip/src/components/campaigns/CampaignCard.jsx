import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { motion } from "framer-motion";
import {
  ChevronRight,
  AlertCircle,
  CheckCircle,
  Clock,
  Calendar,
  Zap
} from "lucide-react";

/**
 * Campaign card component
 * Displays campaign details in different styles based on status
 * 
 * @param {Object} campaign - Campaign data object
 * @param {string} variant - Display style variant (pending, active, completed)
 */
export default function CampaignCard({ campaign, variant = "pending" }) {
  // Handle missing campaign data gracefully
  if (!campaign || !campaign.influencer) {
    return null;
  }

  /**
   * Format date string to readable format
   */
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    }).format(date);
  };

  /**
   * Get status icon based on campaign state
   */
  const getStatusIcon = () => {
    if (variant === "pending") return <Clock className="w-4 h-4 text-orange-500" />;
    if (variant === "active") return <Zap className="w-4 h-4 text-blue-500" />;
    return <CheckCircle className="w-4 h-4 text-green-500" />;
  };

  /**
   * Get status label based on campaign state
   */
  const getStatusLabel = () => {
    if (variant === "pending") return "Pending";
    if (variant === "active") return "In Progress";
    return "Completed";
  };

  /**
   * Get badge color based on campaign state
   */
  const getStatusColor = () => {
    if (variant === "pending") return "bg-orange-100 text-orange-700";
    if (variant === "active") return "bg-blue-100 text-blue-700";
    return "bg-green-100 text-green-700";
  };

  return (
    <motion.div
      whileTap={{ scale: 0.98 }}
      className="touch-manipulation"
    >
      <Card className="overflow-hidden p-4 bg-white">
        <div className="flex items-start gap-3">
          {/* Influencer Avatar */}
          <Avatar className="h-12 w-12 rounded-xl">
            <AvatarImage 
              src={campaign.influencer.profile_picture} 
              alt={campaign.influencer.full_name} 
            />
            <AvatarFallback>
              {campaign.influencer.full_name.charAt(0)}
            </AvatarFallback>
          </Avatar>
          
          {/* Campaign Details */}
          <div className="flex-1 min-w-0">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold text-gray-900">
                  {campaign.influencer.full_name}
                </h3>
                <div className="flex items-center gap-2 mt-0.5">
                  {/* Status badge */}
                  <Badge className={`flex items-center gap-1 ${getStatusColor()}`}>
                    {getStatusIcon()}
                    {getStatusLabel()}
                  </Badge>
                  
                  {/* Match percentage badge if relevant */}
                  {campaign.matchPercentage && (
                    <Badge variant="outline" className="flex items-center gap-1">
                      <Zap className="w-3 h-3 text-purple-500" />
                      {campaign.matchPercentage}% Match
                    </Badge>
                  )}
                </div>
              </div>
              
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </div>
            
            {/* Date information */}
            <div className="flex items-center gap-1 mt-2 text-sm text-gray-500">
              <Calendar className="w-3.5 h-3.5" />
              <span>{formatDate(campaign.created_date)}</span>
            </div>
            
            {/* Progress bar for active campaigns */}
            {variant === "active" && (
              <div className="mt-3">
                <div className="flex justify-between items-center mb-1 text-xs">
                  <span className="text-gray-500">Progress</span>
                  <span className="font-medium">{campaign.progress || 0}%</span>
                </div>
                <Progress value={campaign.progress || 0} className="h-1.5" />
              </div>
            )}
          </div>
        </div>
      </Card>
    </motion.div>
  );
}