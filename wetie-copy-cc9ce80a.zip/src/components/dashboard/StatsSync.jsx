import React, { useState, useEffect } from 'react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { RefreshCw, AlertCircle, CheckCircle2 } from "lucide-react";
import { InfluencerStats } from "@/api/entities";
import { User } from "@/api/entities";
import { formatDistanceToNow } from 'date-fns';

/**
 * Stats Sync Status Component
 * Shows sync status and handles manual refresh
 */
export default function StatsSync({ onRefresh }) {
  const [syncStatus, setSyncStatus] = useState({
    lastUpdate: null,
    isUpdating: false,
    error: null,
    instagram: { connected: false, expired: false },
    tiktok: { connected: false, expired: false }
  });

  useEffect(() => {
    checkSyncStatus();
  }, []);

  /**
   * Check the sync status of social media accounts
   */
  const checkSyncStatus = async () => {
    try {
      const user = await User.me();
      const stats = await InfluencerStats.filter({ influencer_id: user.id });
      
      if (stats.length > 0) {
        const currentStats = stats[0];
        
        setSyncStatus({
          lastUpdate: new Date(currentStats.last_updated),
          instagram: {
            connected: currentStats.instagram?.connected || false,
            expired: isTokenExpired(currentStats.instagram?.token_expires)
          },
          tiktok: {
            connected: currentStats.tiktok?.connected || false,
            expired: isTokenExpired(currentStats.tiktok?.token_expires)
          }
        });
      }
    } catch (error) {
      console.error('Error checking sync status:', error);
      setSyncStatus(prev => ({ ...prev, error: 'Failed to check sync status' }));
    }
  };

  /**
   * Check if a token has expired
   */
  const isTokenExpired = (expiryDate) => {
    if (!expiryDate) return true;
    return new Date(expiryDate) < new Date();
  };

  /**
   * Handle manual refresh of stats
   */
  const handleRefresh = async () => {
    setSyncStatus(prev => ({ ...prev, isUpdating: true, error: null }));
    
    try {
      await onRefresh();
      await checkSyncStatus();
    } catch (error) {
      console.error('Error refreshing stats:', error);
      setSyncStatus(prev => ({ 
        ...prev, 
        error: 'Failed to refresh stats'
      }));
    } finally {
      setSyncStatus(prev => ({ ...prev, isUpdating: false }));
    }
  };

  return (
    <div className="space-y-4">
      {/* Connection Status */}
      <div className="flex items-center justify-between bg-white p-4 rounded-lg shadow-sm">
        <div className="flex items-center gap-4">
          {syncStatus.lastUpdate && (
            <Badge variant="outline" className="text-sm">
              Last updated: {formatDistanceToNow(syncStatus.lastUpdate)} ago
            </Badge>
          )}
          
          {(syncStatus.instagram.connected || syncStatus.tiktok.connected) && (
            <Badge className="bg-green-100 text-green-800">
              <CheckCircle2 className="w-4 h-4 mr-1" />
              Connected
            </Badge>
          )}
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleRefresh}
          disabled={syncStatus.isUpdating}
        >
          <RefreshCw 
            className={`w-4 h-4 mr-2 ${syncStatus.isUpdating ? 'animate-spin' : ''}`}
          />
          {syncStatus.isUpdating ? 'Refreshing...' : 'Refresh Stats'}
        </Button>
      </div>

      {/* Connection Alerts */}
      {(syncStatus.instagram.expired || syncStatus.tiktok.expired) && (
        <Alert variant="warning">
          <AlertCircle className="w-4 h-4" />
          <AlertDescription>
            Some of your social connections need to be renewed. 
            <Button 
              variant="link" 
              className="ml-2 text-amber-800"
              onClick={() => {/* Handle reconnection */}}
            >
              Reconnect now
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {syncStatus.error && (
        <Alert variant="destructive">
          <AlertCircle className="w-4 h-4" />
          <AlertDescription>{syncStatus.error}</AlertDescription>
        </Alert>
      )}
    </div>
  );
}