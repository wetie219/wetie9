import React, { useState } from "react";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Upload, Camera, ImageIcon } from "lucide-react";
import { motion } from "framer-motion";
import { UploadFile } from "@/api/integrations";

export default function ProfileUpload({ formData, updateFormData }) {
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) return;
    
    try {
      setUploading(true);
      
      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 300);
      
      const result = await UploadFile({ file: selectedFile });
      clearInterval(progressInterval);
      setUploadProgress(100);
      
      updateFormData({ profile_photo: result.file_url });
      
      // Reset after successful upload
      setTimeout(() => {
        setUploadProgress(0);
        setUploading(false);
      }, 500);
      
    } catch (error) {
      console.error("Error uploading file:", error);
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const isUserType = formData.user_type === "influencer" ? "profile picture" : "logo";

  return (
    <div>
      <h2 className="text-2xl font-bold text-center mb-2">
        {formData.user_type === "influencer" ? "Upload Your Profile Picture" : "Upload Your Brand Logo"}
      </h2>
      <p className="text-gray-600 text-center mb-8">
        This will be displayed on your profile
      </p>

      <div className="flex flex-col items-center justify-center">
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="mb-6"
        >
          <div 
            className="w-32 h-32 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden cursor-pointer relative"
            onClick={() => document.getElementById("profile-upload").click()}
          >
            {formData.profile_photo ? (
              <img 
                src={formData.profile_photo} 
                alt="Profile" 
                className="w-full h-full object-cover"
              />
            ) : selectedFile ? (
              <div className="w-full h-full flex items-center justify-center bg-purple-100">
                <ImageIcon className="w-12 h-12 text-purple-600" />
              </div>
            ) : (
              <Camera className="w-12 h-12 text-gray-400" />
            )}
            
            {/* Upload progress indicator */}
            {uploadProgress > 0 && (
              <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                <div className="w-16 h-16 rounded-full border-4 border-white/30 border-t-white animate-spin"></div>
                <div className="absolute text-white font-bold">{uploadProgress}%</div>
              </div>
            )}
          </div>
        </motion.div>

        <input
          id="profile-upload"
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileChange}
        />

        {selectedFile && !formData.profile_photo && (
          <div className="text-center mb-4">
            <p className="text-sm text-gray-700 mb-2">Selected: {selectedFile.name}</p>
            <Button 
              onClick={handleUpload}
              className="bg-gradient-to-r from-[#1F1147] to-[#C625FF] text-white"
              disabled={uploading}
            >
              <Upload className="w-4 h-4 mr-2" />
              {uploading ? "Uploading..." : "Upload"}
            </Button>
          </div>
        )}

        {!selectedFile && !formData.profile_photo && (
          <Button
            variant="outline"
            onClick={() => document.getElementById("profile-upload").click()}
            className="border-dashed border-2"
          >
            <Upload className="w-4 h-4 mr-2" />
            Select {isUserType}
          </Button>
        )}
      </div>
    </div>
  );
}