import React, { useState, useEffect } from "react";
import { Match } from "@/api/entities";
import { Business } from "@/api/entities";
import { User } from "@/api/entities";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Search,
  Sparkles,
  Filter,
  UserCheck,
  MessageCircle,
  X
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import MatchRequestCard from "../components/matches/MatchRequestCard";

export default function Matches() {
  const navigate = useNavigate();
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [processingAction, setProcessingAction] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("recent");

  useEffect(() => {
    checkUserType();
    loadMatches();
  }, []);

  const checkUserType = async () => {
    try {
      const user = await User.me();
      // Redirect if not an influencer
      if (user.user_type !== "influencer") {
        navigate(createPageUrl("Dashboard"));
      }
    } catch (error) {
      console.error("Error checking user type:", error);
      navigate(createPageUrl("Landing"));
    }
  };

  const loadMatches = async () => {
    try {
      const user = await User.me();
      
      // Get pending matches for this influencer
      const matchData = await Match.filter({
        influencer_id: user.id,
        status: "pending_influencer_approval"
      });

      // Load business details for each match
      const matchesWithBusinesses = await Promise.all(
        matchData.map(async (match) => {
          try {
            const business = await Business.get(match.business_id);
            return {
              ...match,
              business
            };
          } catch (error) {
            console.error(`Error loading business for match ${match.id}:`, error);
            return null;
          }
        })
      );

      // Filter out any null matches (where business couldn't be loaded)
      const validMatches = matchesWithBusinesses.filter(match => match !== null);

      // Sort matches based on criteria
      const sortedMatches = sortMatches(validMatches, sortBy);
      setMatches(sortedMatches);
    } catch (error) {
      console.error("Error loading matches:", error);
    } finally {
      setLoading(false);
    }
  };

  const sortMatches = (matchesToSort, criteria) => {
    switch (criteria) {
      case "match_score":
        return [...matchesToSort].sort((a, b) => 
          (b.match_percentage || 0) - (a.match_percentage || 0)
        );
      case "recent":
      default:
        return [...matchesToSort].sort((a, b) => 
          new Date(b.created_date) - new Date(a.created_date)
        );
    }
  };

  const handleAcceptMatch = async (matchId) => {
    setProcessingAction(matchId);
    try {
      // First, update match status
      await Match.update(matchId, {
        influencer_approved: true,
        status: "matched",
        match_date: new Date().toISOString()
      });
      
      // Remove from list
      setMatches(prev => prev.filter(m => m.id !== matchId));
      
      // Navigate to messages with this business
      navigate(createPageUrl("Messages") + `?match=${matchId}`);
    } catch (error) {
      console.error("Error accepting match:", error);
    } finally {
      setProcessingAction(null);
    }
  };

  const handleDeclineMatch = async (matchId) => {
    setProcessingAction(matchId);
    try {
      await Match.update(matchId, {
        status: "declined"
      });
      
      // Remove from list with animation
      setMatches(prev => prev.filter(m => m.id !== matchId));
    } catch (error) {
      console.error("Error declining match:", error);
    } finally {
      setProcessingAction(null);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  const filteredMatches = matches.filter(match => 
    match.business?.company_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    match.business?.industry?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#FAFAFA] pb-24">
      {/* Header */}
      <div className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-xl font-bold text-gray-900">Match Requests</h1>
            <Select 
              value={sortBy}
              onValueChange={setSortBy}
            >
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Sort by..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">Most Recent</SelectItem>
                <SelectItem value="match_score">Best Match</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search matches..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Match List */}
      <div className="max-w-xl mx-auto p-4">
        <AnimatePresence mode="wait">
          {filteredMatches.length > 0 ? (
            <div className="space-y-4">
              {filteredMatches.map((match) => (
                <MatchRequestCard
                  key={match.id}
                  match={match}
                  processing={processingAction === match.id}
                  onAccept={() => handleAcceptMatch(match.id)}
                  onDecline={() => handleDeclineMatch(match.id)}
                />
              ))}
            </div>
          ) : (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex flex-col items-center justify-center mt-12 text-center"
            >
              <Sparkles className="w-12 h-12 text-purple-600 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                No Match Requests Yet
              </h3>
              <p className="text-gray-600 max-w-sm mb-6">
                When brands are interested in collaborating with you, their requests will appear here.
              </p>
              <Button
                variant="outline"
                className="text-purple-600 border-purple-200"
                onClick={() => navigate(createPageUrl("Dashboard"))}
              >
                Return to Dashboard
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}