import React from "react";
import { Card } from "@/components/ui/card";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

const colors = {
  rose: "from-rose-500/10 to-rose-50/50",
  blue: "from-blue-500/10 to-blue-50/50",
  emerald: "from-emerald-500/10 to-emerald-50/50",
  violet: "from-violet-500/10 to-violet-50/50"
};

const textColors = {
  rose: "text-rose-700",
  blue: "text-blue-700",
  emerald: "text-emerald-700",
  violet: "text-violet-700"
};

export default function QuickStatsCard({ title, value, icon: Icon, trend, trendDir = "up", color = "blue", type }) {
  const navigate = useNavigate();

  const handleClick = () => {
    // Add haptic feedback if available
    if (window.navigator && window.navigator.vibrate) {
      window.navigator.vibrate(50);
    }

    // Navigate to Campaigns page with appropriate filter
    let url = createPageUrl("Campaigns");
    if (type) {
      url += `?status=${type}`;
    }
    navigate(url);
  };

  return (
    <motion.div
      whileTap={{ scale: 0.95 }}
      onClick={handleClick}
      className="touch-manipulation" // Optimize touch behavior
    >
      <Card className="relative overflow-hidden bg-white active:bg-gray-50 transition-colors duration-200">
        <div className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${colors[color]} flex items-center justify-center`}>
              <Icon className={`w-5 h-5 ${textColors[color]}`} />
            </div>
            {trend && (
              <div className={`flex items-center text-xs font-medium ${
                trendDir === "up" ? "text-emerald-600" : "text-rose-600"
              }`}>
                {trendDir === "up" ? (
                  <ArrowUpRight className="w-3 h-3 mr-0.5" />
                ) : (
                  <ArrowDownRight className="w-3 h-3 mr-0.5" />
                )}
                {trend}
              </div>
            )}
          </div>
          
          <div className="text-xl font-bold text-gray-900 mb-1">{value}</div>
          <h3 className="text-sm text-gray-500">{title}</h3>
        </div>

        {/* Mobile tap feedback indicator */}
        <div className="absolute inset-0 bg-gray-900/5 opacity-0 active:opacity-100 transition-opacity duration-200" />
      </Card>
    </motion.div>
  );
}