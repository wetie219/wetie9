import React from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import {
  CheckCircle,
  DollarSign,
  Rocket
} from "lucide-react";

/**
 * Animated dot component with pulse effect
 * Shows online status and unread message indicator
 */
const StatusDot = ({ status, hasUnread }) => (
  <motion.span 
    className={`absolute bottom-0 right-0 w-3 h-3 border-2 border-white rounded-full ${
      status === 'online' ? 'bg-emerald-500' : 
      status === 'busy' ? 'bg-red-500' : 
      'bg-gray-400'
    }`}
    animate={hasUnread ? {
      scale: [1, 1.2, 1],
      opacity: [1, 0.8, 1]
    } : {}}
    transition={{
      duration: 2,
      repeat: Infinity,
      ease: "easeInOut"
    }}
  />
);

/**
 * Message card component for the messages list
 * Shows message preview with campaign status indicators
 */
export default function MessageCard({ conversation }) {
  const navigate = useNavigate();

  /**
   * Format timestamp to relative time
   * @param {Date} date - Date to format
   * @returns {string} - Formatted time (e.g. "Just now", "5m ago", "2h ago", "3d ago")
   */
  const formatTimeAgo = (date) => {
    const now = new Date();
    const diff = (now - date) / 1000; // in seconds

    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
  };

  const handleCardClick = () => {
    navigate(createPageUrl("Chat") + `?match_id=${conversation.id}`);
  };

  // Campaign status indicators
  const getCampaignStatus = () => {
    if (conversation.status === "campaign_negotiation") {
      return {
        icon: <Rocket className="w-4 h-4 text-amber-500" />,
        label: "Campaign Proposed",
        color: "bg-amber-100 text-amber-800"
      };
    } else if (conversation.status === "campaign_active") {
      return {
        icon: <DollarSign className="w-4 h-4 text-blue-500" />,
        label: "Active Campaign",
        color: "bg-blue-100 text-blue-800"
      };
    } else if (conversation.status === "campaign_completed") {
      return {
        icon: <CheckCircle className="w-4 h-4 text-green-500" />,
        label: "Campaign Completed",
        color: "bg-green-100 text-green-800"
      };
    }
    
    return null;
  };

  const campaignStatus = getCampaignStatus();

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className="cursor-pointer"
      onClick={handleCardClick}
    >
      <Card className="overflow-hidden backdrop-blur-sm hover:bg-[#F3ECFC] transition-all duration-300">
        <div className="p-4 flex items-center gap-4">
          {/* Profile Picture with Animated Status */}
          <div className="relative">
            <motion.div 
              className={`w-12 h-12 rounded-full overflow-hidden ${
                conversation.unread ? 'ring-2 ring-[#E010CD]' : 'ring-2 ring-purple-100'
              }`}
              animate={conversation.unread ? {
                boxShadow: ['0 0 0 0px rgba(224, 16, 205, 0.2)', '0 0 0 4px rgba(224, 16, 205, 0.2)'],
              } : {}}
              transition={{ duration: 1, repeat: Infinity }}
            >
              <img 
                src={conversation.profile.profile_picture || conversation.profile.logo_url} 
                alt={conversation.profile.full_name || conversation.profile.company_name}
                className="w-full h-full object-cover"
              />
            </motion.div>
            <StatusDot status={conversation.online ? 'online' : 'offline'} hasUnread={conversation.unread} />
          </div>

          {/* Message Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-[16px] text-[#1A1A1A]">
                {conversation.profile.full_name || conversation.profile.company_name}
              </h3>
              <span className="text-sm text-[#707070]">
                {formatTimeAgo(conversation.lastActive)}
              </span>
            </div>
            
            {campaignStatus ? (
              <div className="flex items-center mt-1">
                <Badge className={`flex items-center gap-1 ${campaignStatus.color}`}>
                  {campaignStatus.icon}
                  {campaignStatus.label}
                </Badge>
              </div>
            ) : (
              <p className="text-[14px] text-[#707070] truncate mt-1">
                {conversation.lastMessage || "Start a conversation..."}
              </p>
            )}
          </div>

          {/* Unread indicator */}
          {conversation.unread && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="flex flex-col items-center"
            >
              <Badge className="bg-[#E010CD] shadow-lg shadow-[#E010CD]/20">
                New
              </Badge>
            </motion.div>
          )}
        </div>
      </Card>
    </motion.div>
  );
}