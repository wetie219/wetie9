import React, { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Globe } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

/**
 * Language options available in the app
 * Each language includes its name in native script and direction (ltr or rtl)
 */
const languages = {
  en: { name: 'English', dir: 'ltr' },
  ar: { name: 'العربية', dir: 'rtl' },
  he: { name: 'עברית', dir: 'rtl' }
};

/**
 * Language selector component
 * Allows users to switch between different language options
 * 
 * @param {string} mode - Display mode: "icon" for minimal display, "full" for text and icon
 */
export default function LanguageSelector({ mode = "icon" }) {
  // State to track the currently selected language
  const [currentLang, setCurrentLang] = React.useState(() => {
    // Try to get previously saved language from localStorage
    return localStorage.getItem('language') || 'en';
  });

  // Set initial language direction on component mount
  useEffect(() => {
    document.documentElement.dir = languages[currentLang].dir;
    document.documentElement.lang = currentLang;
  }, []);

  /**
   * Handle language change
   * Updates the UI direction and saves preference to localStorage
   * 
   * @param {string} lang - Language code to switch to
   */
  const handleLanguageChange = (lang) => {
    setCurrentLang(lang);
    // Save to localStorage for persistence
    localStorage.setItem('language', lang);
    // Update document direction for RTL/LTR support
    document.documentElement.dir = languages[lang].dir;
    document.documentElement.lang = lang;
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="rounded-full">
          <Globe className="h-5 w-5 text-gray-600" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {Object.entries(languages).map(([code, lang]) => (
          <DropdownMenuItem
            key={code}
            onClick={() => handleLanguageChange(code)}
            className={`${currentLang === code ? "bg-purple-50" : ""}`}
          >
            <span>{lang.name}</span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}