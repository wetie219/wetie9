import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Match } from "@/api/entities";
import { Influencer } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus, Search, Brain } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import CampaignCard from "../components/campaigns/CampaignCard";
import NewCampaignModal from "../components/campaigns/NewCampaignModal";
import CampaignTabs from "../components/campaigns/CampaignTabs";
import { Badge } from "@/components/ui/badge";

/**
 * Campaigns page component
 * Shows all campaigns organized by status (pending, active, completed)
 */
export default function Campaigns() {
  const [campaigns, setCampaigns] = useState({
    pending: [],
    active: [],
    completed: []
  });
  const [loading, setLoading] = useState(true);
  const [showNewCampaignModal, setShowNewCampaignModal] = useState(false);
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("pending");
  const [sortBy, setSortBy] = useState("newest");
  const [showFilterSheet, setShowFilterSheet] = useState(false);
  const [filters, setFilters] = useState({
    platforms: [],
    minMatchScore: 0
  });

  useEffect(() => {
    loadData();
  }, []);

  // Add URL parameter handling
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const statusParam = urlParams.get('status');
    if (statusParam) {
      setActiveTab(statusParam);
    }
  }, []);

  /**
   * Load campaign data from matches
   */
  const loadData = async () => {
    try {
      // Get current user
      const currentUser = await User.me();
      setUser(currentUser);

      // Load matches (which represent campaigns)
      const matches = await Match.list();
      const influencers = await Influencer.list();

      // Create a lookup for influencers
      const influencerMap = {};
      influencers.forEach(inf => {
        influencerMap[inf.id] = inf;
      });

      // Organize campaigns by status
      const organized = { pending: [], active: [], completed: [] };
      
      // Process matches into campaigns
      matches.forEach(match => {
        const influencer = influencerMap[match.influencer_id];
        if (!influencer) return;
        
        // Determine campaign status based on match status
        let campaignTab = "pending";
        if (match.status === "matched" || match.status === "campaign_negotiation" || match.status === "campaign_active") {
          campaignTab = "active";
        } else if (match.status === "campaign_completed") {
          campaignTab = "completed";
        } else if (match.status === "declined" || match.status === "campaign_cancelled") {
          // Skip declined/cancelled matches
          return;
        }

        // Create campaign object
        const campaign = {
          id: match.id,
          influencer,
          status: match.status,
          created_date: match.created_date,
          campaign_details: match.campaign_details || {},
          progress: calculateProgress(match),
          matchPercentage: calculateMatchPercentage(influencer)
        };

        organized[campaignTab].push(campaign);
      });

      setCampaigns(organized);
    } catch (error) {
      console.error("Error loading campaigns:", error);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Calculate campaign progress percentage
   * @param {Object} match - Match data
   * @returns {number} - Progress percentage
   */
  const calculateProgress = (match) => {
    if (!match.campaign_details) return 0;
    // Simple progress calculation - can be made more sophisticated
    if (match.status === "campaign_completed") return 100;
    if (match.status === "campaign_active") return 66;
    if (match.status === "campaign_negotiation") return 33;
    return 10;
  };

  /**
   * Calculate match percentage between business and influencer
   * @param {Object} influencer - Influencer data
   * @returns {number} - Match percentage
   */
  const calculateMatchPercentage = (influencer) => {
    // This is a placeholder - in a real app, you would calculate this based on 
    // compatibility between the brand and influencer
    return Math.floor(Math.random() * 41) + 60; // Random value between 60-100
  };

  /**
   * Sort campaigns based on selected sort method
   * @param {Array} campaignsToSort - Array of campaigns to sort
   * @returns {Array} - Sorted campaigns
   */
  const sortCampaigns = (campaignsToSort) => {
    if (sortBy === "newest") {
      return [...campaignsToSort].sort((a, b) => 
        new Date(b.created_date) - new Date(a.created_date)
      );
    } else if (sortBy === "matchScore") {
      return [...campaignsToSort].sort((a, b) => 
        b.matchPercentage - a.matchPercentage
      );
    }
    return campaignsToSort;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  const currentCampaigns = sortCampaigns(campaigns[activeTab] || []);
  const campaignCounts = {
    pending: campaigns.pending.length,
    active: campaigns.active.length,
    completed: campaigns.completed.length
  };
  
  // Suggested collaborations section - only shown for businesses with successful campaigns
  const suggestedCollaborators = campaigns.completed
    .filter(campaign => campaign.matchPercentage > 80)
    .slice(0, 2)
    .map(campaign => campaign.influencer);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 pb-24">
      {/* Header with sticky tabs */}
      <div className="sticky top-0 z-10 bg-white/90 backdrop-blur-md border-b shadow-sm">
        <div className="p-4 max-w-xl mx-auto">
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-2xl font-bold text-gray-900">Campaigns</h1>
            <Button 
              size="icon"
              variant="ghost"
              className="text-gray-600"
              onClick={() => setShowFilterSheet(!showFilterSheet)}
            >
              <Search className="w-5 h-5" />
            </Button>
          </div>

          {/* Campaign Tabs */}
          <CampaignTabs
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            counts={campaignCounts}
          />
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-xl mx-auto p-4 space-y-6">
        {/* Sort and Filter Options */}
        <div className="flex justify-between items-center text-sm">
          <div>
            {showFilterSheet && (
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="bg-white/70 cursor-pointer">
                  Instagram
                </Badge>
                <Badge variant="outline" className="bg-white/70 cursor-pointer">
                  Match Score &gt; 70%
                </Badge>
              </div>
            )}
          </div>
          <select 
            className="bg-transparent border-none text-gray-600 focus:outline-none cursor-pointer"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
          >
            <option value="newest">Newest First</option>
            <option value="matchScore">Best Match First</option>
          </select>
        </div>

        {/* AI Suggestion Section (only when having completed campaigns) */}
        {suggestedCollaborators.length > 0 && activeTab === 'pending' && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/70 backdrop-blur-sm rounded-xl p-4 border border-purple-100"
          >
            <div className="flex items-center gap-2 mb-3">
              <Brain className="w-5 h-5 text-purple-600" />
              <h3 className="font-medium text-gray-900">Suggested Collaborations</h3>
            </div>
            <p className="text-sm text-gray-600 mb-3">
              Based on your successful campaigns, consider working with:
            </p>
            <div className="flex gap-2">
              {suggestedCollaborators.map(influencer => (
                <div key={influencer.id} className="flex items-center gap-2 bg-purple-50 rounded-lg p-2">
                  <div className="w-8 h-8 rounded-full overflow-hidden">
                    <img 
                      src={influencer.profile_picture} 
                      alt={influencer.full_name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <span className="text-sm font-medium">{influencer.full_name}</span>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Campaign List */}
        <AnimatePresence mode="wait">
          {currentCampaigns.length > 0 ? (
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="space-y-4"
            >
              {currentCampaigns.map((campaign) => (
                <CampaignCard
                  key={campaign.id}
                  campaign={campaign}
                  variant={activeTab}
                />
              ))}
            </motion.div>
          ) : (
            <motion.div
              key={`empty-${activeTab}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="py-10 text-center"
            >
              <p className="text-gray-500">No {activeTab} campaigns at the moment</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Floating Action Button */}
      <Button
        className="fixed bottom-24 right-4 h-14 w-14 rounded-full bg-gradient-to-r from-[#2F2C7F] to-[#E010CD] shadow-lg"
        onClick={() => setShowNewCampaignModal(true)}
      >
        <Plus className="h-6 w-6" />
      </Button>

      {/* New Campaign Modal */}
      <NewCampaignModal
        open={showNewCampaignModal}
        onClose={() => setShowNewCampaignModal(false)}
        onSubmit={async (data) => {
          // Handle new campaign creation
          setShowNewCampaignModal(false);
          await loadData();
        }}
      />
    </div>
  );
}