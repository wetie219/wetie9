import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Instagram, Youtube, Music as TikTok, Link2 } from "lucide-react";
import { motion } from "framer-motion";

export default function ConnectedPlatforms({ stats }) {
  const platforms = [
    {
      id: 'instagram',
      icon: Instagram,
      name: 'Instagram',
      connected: stats?.instagram?.connected,
      color: 'text-pink-600',
      bgColor: 'bg-pink-50'
    },
    {
      id: 'tiktok',
      icon: TikTok,
      name: 'TikTok',
      connected: stats?.tiktok?.connected,
      color: 'text-black',
      bgColor: 'bg-gray-50'
    },
    {
      id: 'youtube',
      icon: Youtube,
      name: 'YouTube',
      connected: stats?.youtube?.connected,
      color: 'text-red-600',
      bgColor: 'bg-red-50'
    }
  ];

  return (
    <div className="flex flex-wrap gap-3 justify-center">
      {platforms.map((platform) => (
        <motion.div
          key={platform.id}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          {platform.connected ? (
            <Badge
              className={`px-3 py-1.5 ${platform.bgColor} border-none`}
            >
              <platform.icon className={`w-4 h-4 mr-1.5 ${platform.color}`} />
              <span className={platform.color}>Connected</span>
            </Badge>
          ) : (
            <Button
              variant="outline"
              size="sm"
              className="gap-2"
            >
              <platform.icon className="w-4 h-4" />
              Connect {platform.name}
            </Button>
          )}
        </motion.div>
      ))}
    </div>
  );
}