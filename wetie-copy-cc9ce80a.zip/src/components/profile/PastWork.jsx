import React from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Plus, Star, Eye } from "lucide-react";
import { motion } from "framer-motion";

export default function PastWork({ collaborations = [], editMode }) {
  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold">Past Collaborations</h2>
        {editMode && (
          <Button variant="outline" size="sm">
            <Plus className="w-4 h-4 mr-2" />
            Add Work
          </Button>
        )}
      </div>

      <div className="grid gap-4">
        {collaborations.map((collab, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-gray-50 rounded-xl p-4"
          >
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-medium mb-1">{collab.brand_name}</h3>
                <p className="text-sm text-gray-600 mb-2">
                  {collab.campaign_type} • {collab.date}
                </p>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">
                    <Eye className="w-3 h-3 mr-1" />
                    {(collab.reach / 1000).toFixed(1)}K Reach
                  </Badge>
                  {collab.rating && (
                    <Badge className="bg-yellow-100 text-yellow-800">
                      <Star className="w-3 h-3 mr-1" />
                      {collab.rating.toFixed(1)}
                    </Badge>
                  )}
                </div>
              </div>
              {collab.testimonial && (
                <div className="text-sm italic text-gray-600 max-w a">
                  "{collab.testimonial}"
                </div>
              )}
            </div>
          </motion.div>
        ))}

        {collaborations.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <p>No past collaborations yet</p>
            {editMode && (
              <p className="text-sm mt-2">
                Add your previous brand collaborations to showcase your experience
              </p>
            )}
          </div>
        )}
      </div>
    </Card>
  );
}