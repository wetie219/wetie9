import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Camera, Lock, Plus, Trash } from "lucide-react";
import { motion } from 'framer-motion';
import { Progress } from "@/components/ui/progress";

export default function PortfolioSection({ 
  portfolioItems = [], 
  editMode, 
  onUpload, 
  uploadingImage,
  uploadProgress,
  isPrivate
}) {
  if (isPrivate) {
    return (
      <Card className="relative overflow-hidden">
        <CardContent className="p-6 flex items-center justify-center min-h-[200px] text-center">
          <div className="space-y-2">
            <Lock className="w-12 h-12 text-gray-300 mx-auto" />
            <h3 className="text-xl font-medium text-gray-500">Portfolio is Private</h3>
            <p className="text-gray-400 text-sm">
              The creator has set their portfolio to private
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div>
      {portfolioItems.length === 0 && !editMode ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Camera className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <h3 className="text-xl font-medium text-gray-500">No Portfolio Items</h3>
            <p className="text-gray-400 text-sm max-w-md mx-auto mt-2">
              The creator hasn't added any past work examples or portfolio items yet
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {portfolioItems.map((item, index) => (
            <motion.div
              key={index}
              whileHover={{ y: -5 }}
              className="relative rounded-lg overflow-hidden aspect-square"
            >
              <img 
                src={item.image_url} 
                alt={item.title || `Portfolio item ${index + 1}`}
                className="w-full h-full object-cover"
              />
              
              {item.title && (
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-2">
                  <div className="text-white text-sm font-medium">{item.title}</div>
                </div>
              )}
              
              {editMode && (
                <button
                  className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 opacity-0 hover:opacity-100 transition-opacity"
                  onClick={() => {/* Delete functionality */}}
                >
                  <Trash className="w-4 h-4" />
                </button>
              )}
            </motion.div>
          ))}
          
          {/* Add new portfolio item button */}
          {editMode && (
            <motion.div
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="relative rounded-lg overflow-hidden aspect-square border-2 border-dashed border-gray-300 flex items-center justify-center bg-gray-50"
            >
              {uploadingImage ? (
                <div className="text-center">
                  <Progress value={uploadProgress} className="w-16 h-2 mx-auto mb-2" />
                  <div className="text-xs text-gray-500">{uploadProgress}%</div>
                </div>
              ) : (
                <div
                  className="flex flex-col items-center cursor-pointer p-4 text-center"
                  onClick={() => document.getElementById('portfolio-upload').click()}
                >
                  <Plus className="w-8 h-8 text-gray-400 mb-2" />
                  <span className="text-sm text-gray-500">Add Portfolio Item</span>
                  <input
                    type="file"
                    id="portfolio-upload"
                    className="hidden"
                    accept="image/*"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        onUpload(e.target.files[0]);
                      }
                    }}
                  />
                </div>
              )}
            </motion.div>
          )}
        </div>
      )}
    </div>
  );
}