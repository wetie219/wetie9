
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Home, MessageCircle, UserCircle, Megaphone, Sparkles } from "lucide-react";
import LanguageSelector from "./components/common/LanguageSelector";

/**
 * Main Layout component
 * Provides consistent layout structure for all pages including navigation
 * 
 * @param {ReactNode} children - Content to be rendered inside the layout
 * @param {string} currentPageName - Name of the current page
 */
export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const currentPath = location.pathname;

  /**
   * Check if a navigation item should be highlighted as active
   * @param {string} pageName - Name of the page to check
   * @returns {boolean} - Whether the page is active
   */
  const isActive = (pageName) => {
    const pageUrl = createPageUrl(pageName);
    return currentPath === pageUrl;
  };

  return (
    <div className="min-h-[100dvh] bg-white flex flex-col">
      {/* Safe Area Top (for iOS) */}
      <div className="h-safe-top bg-white" />

      {/* Language Selector - visible at the top right corner */}
      <div className="fixed top-2 right-2 z-50">
        <LanguageSelector mode="icon" />
      </div>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto pb-[calc(env(safe-area-inset-bottom)+64px)]">
        {children}
      </main>

      {/* Bottom Navigation Bar with Safe Area */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t py-2 px-4 flex items-center justify-around pb-safe">
        {/* Home navigation */}
        <Link
          to={createPageUrl("Dashboard")}
          className="flex flex-col items-center gap-1 w-16 touch-manipulation"
        >
          <Home 
            className={`w-6 h-6 ${isActive("Dashboard") || isActive("InfluencerDashboard") ? "text-purple-600" : "text-gray-600"}`} 
          />
          <span className={`text-xs ${isActive("Dashboard") || isActive("InfluencerDashboard") ? "text-purple-600" : "text-gray-600"}`}>
            Home
          </span>
        </Link>
        
        {/* Match Requests navigation */}
        <Link
          to={createPageUrl("MatchRequests")}
          className="flex flex-col items-center gap-1 w-16 touch-manipulation"
        >
          <Sparkles 
            className={`w-6 h-6 ${isActive("MatchRequests") ? "text-purple-600" : "text-gray-600"}`}
          />
          <span className={`text-xs ${isActive("MatchRequests") ? "text-purple-600" : "text-gray-600"}`}>
            Matches
          </span>
        </Link>
        
        {/* Campaigns navigation */}
        <Link
          to={createPageUrl("Campaigns")}
          className="flex flex-col items-center gap-1 w-16 touch-manipulation"
        >
          <Megaphone 
            className={`w-6 h-6 ${isActive("Campaigns") ? "text-purple-600" : "text-gray-600"}`}
          />
          <span className={`text-xs ${isActive("Campaigns") ? "text-purple-600" : "text-gray-600"}`}>
            Campaigns
          </span>
        </Link>
        
        {/* Messages navigation */}
        <Link
          to={createPageUrl("Messages")}
          className="flex flex-col items-center gap-1 w-16 touch-manipulation"
        >
          <MessageCircle 
            className={`w-6 h-6 ${isActive("Messages") ? "text-purple-600" : "text-gray-600"}`}
          />
          <span className={`text-xs ${isActive("Messages") ? "text-purple-600" : "text-gray-600"}`}>
            Messages
          </span>
        </Link>
        
        {/* Profile navigation */}
        <Link
          to={createPageUrl("Profile")}
          className="flex flex-col items-center gap-1 w-16 touch-manipulation"
        >
          <UserCircle 
            className={`w-6 h-6 ${isActive("Profile") ? "text-purple-600" : "text-gray-600"}`}
          />
          <span className={`text-xs ${isActive("Profile") ? "text-purple-600" : "text-gray-600"}`}>
            Profile
          </span>
        </Link>
      </nav>
    </div>
  );
}
