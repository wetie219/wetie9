import React from 'react';
import { motion } from 'framer-motion';
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Star,
  MapPin,
  Instagram,
  Youtube,
  Music as TikTok,
  Upload,
  CheckCircle2,
  Link2,
  ExternalLink
} from "lucide-react";

export default function InfluencerHeader({ 
  profile, 
  editMode, 
  onProfilePictureUpload, 
  uploadProgress,
  uploadingImage
}) {
  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      onProfilePictureUpload(e.target.files[0]);
    }
  };

  return (
    <div className="flex flex-col items-center">
      {/* Profile Picture */}
      <div className="relative w-32 h-32 mb-4">
        <motion.div
          whileHover={editMode ? { scale: 1.05 } : {}}
          className="w-full h-full rounded-full overflow-hidden ring-4 ring-white shadow-xl"
        >
          <img
            src={profile.profile_picture || "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&auto=format&fit=crop&q=80"}
            alt={profile.full_name || "Profile Picture"}
            className="w-full h-full object-cover"
          />
          
          {editMode && (
            <div 
              className="absolute inset-0 bg-black/50 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer"
              onClick={() => document.getElementById('profile-image-upload').click()}
            >
              <Upload className="w-8 h-8 text-white" />
              <input 
                type="file"
                id="profile-image-upload"
                className="hidden"
                accept="image/*"
                onChange={handleFileChange}
              />
            </div>
          )}
        </motion.div>
        
        {/* Upload Progress Indicator */}
        {uploadingImage && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="absolute inset-0 bg-black/30 rounded-full"></div>
            <div className="z-10 text-white font-bold text-sm">{uploadProgress}%</div>
          </div>
        )}
        
        {/* Verified Badge */}
        {profile.verified && (
          <Badge 
            className="absolute -bottom-1 -right-1 bg-gradient-to-r from-purple-600 to-pink-600 p-1"
          >
            <Star className="w-3 h-3 text-white" />
          </Badge>
        )}
      </div>
      
      {/* Name and Handle */}
      <div className="text-center">
        <div className="flex items-center justify-center gap-2 mb-1">
          <h1 className="text-2xl font-bold">{profile.full_name || "Your Name"}</h1>
          {profile.verified && (
            <CheckCircle2 className="w-5 h-5 text-blue-500" />
          )}
        </div>
        
        <div className="text-gray-600 mb-2">
          @{profile.username || "username"}
        </div>
        
        {/* Tagline */}
        {profile.tagline && (
          <div className="text-sm text-gray-700 font-medium mb-2 max-w-md">
            {profile.tagline}
          </div>
        )}
        
        {/* Location */}
        {profile.location && (
          <div className="flex items-center justify-center text-gray-600 text-sm mb-2">
            <MapPin className="w-4 h-4 mr-1" />
            {profile.location}
          </div>
        )}
        
        {/* Social Platform Handles */}
        <div className="flex items-center justify-center gap-4 mt-3">
          {profile.platforms.instagram.handle && (
            <div className="flex items-center text-pink-600">
              <Instagram className="w-4 h-4 mr-1" />
              <span className="text-sm font-medium">{profile.platforms.instagram.handle}</span>
            </div>
          )}
          
          {profile.platforms.tiktok.handle && (
            <div className="flex items-center">
              <TikTok className="w-4 h-4 mr-1" />
              <span className="text-sm font-medium">{profile.platforms.tiktok.handle}</span>
            </div>
          )}
          
          {profile.platforms.youtube.handle && (
            <div className="flex items-center text-red-600">
              <Youtube className="w-4 h-4 mr-1" />
              <span className="text-sm font-medium">{profile.platforms.youtube.handle}</span>
            </div>
          )}
        </div>
        
        {/* Portfolio Link */}
        {profile.portfolio_url && (
          <a 
            href={profile.portfolio_url}
            target="_blank"
            rel="noopener noreferrer" 
            className="inline-flex items-center text-purple-600 hover:text-purple-700 text-sm mt-2"
          >
            <Link2 className="w-3 h-3 mr-1" />
            Portfolio / Media Kit
            <ExternalLink className="w-3 h-3 ml-1" />
          </a>
        )}
      </div>
    </div>
  );
}