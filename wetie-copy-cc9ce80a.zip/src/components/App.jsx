import React, { useEffect } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { LanguageProvider } from "./utils/i18n";
import Layout from "./layout";

// Import pages here
import Dashboard from "./pages/Dashboard";
import InfluencerDashboard from "./pages/InfluencerDashboard";
import Campaigns from "./pages/Campaigns";
import Messages from "./pages/Messages";
import Profile from "./pages/Profile";
import MatchRequests from "./pages/MatchRequests";
// ...other page imports

export default function App() {
  return (
    <LanguageProvider>
      <Router>
        <Routes>
          <Route path="/" element={
            <Layout currentPageName="Dashboard">
              <Dashboard />
            </Layout>
          } />
          <Route path="/dashboard" element={
            <Layout currentPageName="Dashboard">
              <Dashboard />
            </Layout>
          } />
          <Route path="/influencer-dashboard" element={
            <Layout currentPageName="InfluencerDashboard">
              <InfluencerDashboard />
            </Layout>
          } />
          <Route path="/campaigns" element={
            <Layout currentPageName="Campaigns">
              <Campaigns />
            </Layout>
          } />
          <Route path="/match-requests" element={
            <Layout currentPageName="MatchRequests">
              <MatchRequests />
            </Layout>
          } />
          <Route path="/messages" element={
            <Layout currentPageName="Messages">
              <Messages />
            </Layout>
          } />
          <Route path="/profile" element={
            <Layout currentPageName="Profile">
              <Profile />
            </Layout>
          } />
          {/* Add other routes as needed */}
        </Routes>
      </Router>
    </LanguageProvider>
  );
}