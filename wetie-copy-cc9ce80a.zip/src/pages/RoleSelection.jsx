import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Building2, Camera, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";

export default function RoleSelection() {
  const [selectedRole, setSelectedRole] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const checkUser = async () => {
      try {
        const userData = await User.me();
        setUser(userData);
        
        // If user already has a type and completed onboarding, redirect them
        if (userData.user_type && userData.onboarding_completed) {
          if (userData.user_type === "influencer") {
            navigate(createPageUrl("InfluencerDashboard"));
          } else {
            navigate(createPageUrl("Dashboard"));
          }
        }
        
        // If user has a type but not completed onboarding, go to onboarding
        if (userData.user_type && !userData.onboarding_completed) {
          navigate(createPageUrl("Onboarding"));
        }
      } catch (error) {
        console.log("User not logged in");
        navigate(createPageUrl("Landing"));
      } finally {
        setLoading(false);
      }
    };
    
    checkUser();
  }, [navigate]);

  const handleContinue = async () => {
    if (!selectedRole) return;

    try {
      // Update user type in the database
      await User.updateMyUserData({
        user_type: selectedRole,
        onboarding_step: 0
      });
      
      // Navigate to onboarding
      navigate(createPageUrl("Onboarding"));
    } catch (error) {
      console.error("Error updating user role:", error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-purple-500 rounded-full border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <div className="relative flex flex-col items-center justify-center flex-1 p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <h1 className="text-4xl font-bold text-center mb-12">ARE YOU?</h1>

          <div className="space-y-4 mb-12">
            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button
                variant="outline"
                className={`w-full h-24 flex items-center justify-center gap-3 text-xl border-2 ${
                  selectedRole === "brand"
                    ? "bg-gradient-to-r from-[#1F1147] to-[#C625FF] text-white border-transparent"
                    : "border-gray-300 hover:border-purple-400 text-gray-800"
                }`}
                onClick={() => setSelectedRole("brand")}
              >
                <Building2 className="w-7 h-7" />
                BRAND
              </Button>
            </motion.div>

            <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button
                variant="outline"
                className={`w-full h-24 flex items-center justify-center gap-3 text-xl border-2 ${
                  selectedRole === "influencer"
                    ? "bg-gradient-to-r from-[#1F1147] to-[#C625FF] text-white border-transparent"
                    : "border-gray-300 hover:border-purple-400 text-gray-800"
                }`}
                onClick={() => setSelectedRole("influencer")}
              >
                <Camera className="w-7 h-7" />
                INFLUENCER
              </Button>
            </motion.div>
          </div>

          <div className="flex justify-end">
            <motion.div 
              whileHover={{ scale: 1.05 }} 
              whileTap={{ scale: 0.95 }}
            >
              <Button
                onClick={handleContinue}
                disabled={!selectedRole}
                className={`rounded-full w-14 h-14 ${
                  selectedRole
                    ? "bg-gradient-to-r from-[#1F1147] to-[#C625FF]"
                    : "bg-gray-300"
                }`}
              >
                <ArrowRight className="w-6 h-6 text-white" />
              </Button>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}