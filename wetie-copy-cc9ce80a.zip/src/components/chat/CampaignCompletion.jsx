import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  CheckCircle, 
  Calendar, 
  DollarSign,
  Briefcase,
  Star,
  ArrowRight
} from "lucide-react";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";

/**
 * Campaign Completion component
 * Shown when a campaign has been successfully completed
 */
export default function CampaignCompletion({ onClose, campaignData, partnerName }) {
  const navigate = useNavigate();
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="bg-white rounded-xl w-full max-w-md overflow-hidden"
      >
        <div className="p-6">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <motion.div
                animate={{ 
                  scale: [1, 1.2, 1],
                  rotate: [0, 10, -10, 0]
                }}
                transition={{ 
                  duration: 1,
                  repeat: Infinity,
                  repeatDelay: 3
                }}
              >
                <CheckCircle className="h-8 w-8 text-green-600" />
              </motion.div>
            </div>
          </div>
          
          <h2 className="text-xl font-bold text-center">
            Campaign Completed!
          </h2>
          
          <p className="text-center text-gray-600 mb-6">
            Congratulations on successfully completing this campaign!
          </p>
          
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="flex items-center mb-4">
              <Briefcase className="text-gray-600 w-5 h-5 mr-2" />
              <span className="font-medium">{campaignData?.title || "Campaign"}</span>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Partnership with:</span>
                <span className="font-medium">{partnerName}</span>
              </div>
              
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Earned:</span>
                <span className="font-bold text-lg flex items-center text-green-600">
                  <DollarSign className="w-4 h-4" />
                  {campaignData?.budget || "0"}
                </span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">Completed on:</span>
                <span className="flex items-center">
                  <Calendar className="w-4 h-4 mr-1 text-gray-500" />
                  {new Date().toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
          
          <div className="bg-yellow-50 border border-yellow-100 rounded-lg p-3 mb-6">
            <div className="flex items-start">
              <Star className="text-yellow-600 w-5 h-5 mt-0.5 mr-2 flex-shrink-0" />
              <p className="text-sm text-yellow-800">
                Great work! Your payment has been released. Would you like to rate your experience working with {partnerName}?
              </p>
            </div>
          </div>
          
          <div className="flex gap-3">
            <Button
              variant="outline"
              className="flex-1"
              onClick={onClose}
            >
              Close
            </Button>
            
            <Button
              className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white"
              onClick={() => {
                onClose();
                navigate(createPageUrl("Campaigns"));
              }}
            >
              View Campaigns
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}