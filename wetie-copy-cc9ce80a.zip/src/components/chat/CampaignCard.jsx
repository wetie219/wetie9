import React from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Calendar, 
  DollarSign, 
  Instagram,
  TrendingUp,
  Clock,
  Pin
} from "lucide-react";

export default function CampaignCard({ campaign, isPinned }) {
  return (
    <Card className={`p-4 ${isPinned ? 'border-purple-200 bg-purple-50' : 'bg-white/50'}`}>
      {isPinned && (
        <div className="flex items-center gap-2 mb-2 text-purple-600">
          <Pin className="w-4 h-4" />
          <span className="text-sm font-medium">Pinned Campaign Details</span>
        </div>
      )}
      
      <div className="flex items-center gap-3 mb-3">
        <h3 className="font-semibold flex-1">{campaign.title}</h3>
        <Badge className="bg-green-100 text-green-800">
          {campaign.status === 'campaign_active' ? 'Active' : 'Pending'}
        </Badge>
      </div>

      <div className="grid grid-cols-2 gap-3 text-sm">
        <div className="flex items-center gap-2 text-gray-600">
          <DollarSign className="w-4 h-4" />
          <span>${campaign.budget}</span>
        </div>

        <div className="flex items-center gap-2 text-gray-600">
          <Calendar className="w-4 h-4" />
          <span>{new Date(campaign.deadline).toLocaleDateString()}</span>
        </div>

        <div className="flex items-center gap-2 text-gray-600">
          <Instagram className="w-4 h-4" />
          <span>{campaign.content_type}</span>
        </div>

        <div className="flex items-center gap-2 text-gray-600">
          <TrendingUp className="w-4 h-4" />
          <span>{campaign.quantity} posts</span>
        </div>
      </div>

      {campaign.deadline && (
        <div className="mt-3 pt-3 border-t">
          <div className="flex items-center gap-2 text-amber-600">
            <Clock className="w-4 h-4" />
            <span className="text-sm">
              {new Date(campaign.deadline) > new Date() 
                ? `${Math.ceil((new Date(campaign.deadline) - new Date()) / (1000 * 60 * 60 * 24))} days left`
                : 'Deadline passed'}
            </span>
          </div>
        </div>
      )}
    </Card>
  );
}