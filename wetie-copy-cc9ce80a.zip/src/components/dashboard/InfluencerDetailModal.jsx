import React, { useState } from 'react';
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  MapPin, 
  Cake, 
  Instagram, 
  Users, 
  Heart,
  Zap,
  Globe,
  ExternalLink,
  ChevronRight
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import MatchScore from './MatchScore';
import GenderChart from './GenderChart';
import AudienceStats from './AudienceStats';

export default function InfluencerDetailModal({ influencer, isOpen, onClose, onLike }) {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Overview' },
    { id: 'audience', label: 'Audience' }
  ];

  if (!influencer) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md p-0 h-[90vh] overflow-hidden bg-[#F8F8FF]">
        {/* Sticky Header with Tabs */}
        <div className="sticky top-0 z-10 bg-white border-b">
          <div className="flex justify-between items-center p-4">
            <div className="text-2xl font-bold bg-gradient-to-r from-[#2F2C7F] to-[#E010CD] bg-clip-text text-transparent">
              WETIE
            </div>
            <MatchScore percentage={influencer.matchPercentage} />
          </div>
          
          <div className="flex px-2">
            {tabs.map(tab => (
              <button
                key={tab.id}
                className={`flex-1 px-4 py-3 text-sm font-medium transition-colors relative
                  ${activeTab === tab.id ? 'text-[#2F2C7F]' : 'text-gray-500'}`}
                onClick={() => setActiveTab(tab.id)}
              >
                {tab.label}
                {activeTab === tab.id && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#2F2C7F]"
                  />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto h-full pb-20">
          <AnimatePresence mode="wait">
            {activeTab === 'overview' ? (
              <motion.div
                key="overview"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="p-4 space-y-6"
              >
                {/* Profile Images */}
                <div className="grid grid-cols-2 gap-3">
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="aspect-[4/5] rounded-2xl overflow-hidden shadow-lg"
                  >
                    <img
                      src={influencer.profile_picture}
                      alt={influencer.full_name}
                      className="w-full h-full object-cover"
                    />
                  </motion.div>
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="aspect-[4/5] rounded-2xl overflow-hidden shadow-lg"
                  >
                    <img
                      src={influencer.profile_picture_secondary || influencer.profile_picture}
                      alt={influencer.full_name}
                      className="w-full h-full object-cover"
                    />
                  </motion.div>
                </div>

                {/* Basic Info */}
                <div>
                  <h1 className="text-2xl font-bold mb-2">{influencer.full_name}</h1>
                  <div className="flex items-center gap-4 text-gray-600">
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      <span>{influencer.location || "Doha"}</span>
                    </div>
                    {influencer.age && (
                      <div className="flex items-center gap-1">
                        <Cake className="w-4 h-4" />
                        <span>{influencer.age} years</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Bio */}
                <p className="text-gray-700 font-['Inter'] leading-relaxed">
                  {influencer.bio}
                </p>

                {/* Instagram Stats */}
                <div className="bg-white rounded-2xl shadow-sm p-4 space-y-4">
                  <h3 className="text-center text-lg font-semibold">Account Reach</h3>
                  <div className="flex items-center justify-between bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-xl">
                    <div className="flex items-center gap-2">
                      <Instagram className="w-5 h-5 text-[#E010CD]" />
                      <span className="font-medium">{influencer.platforms?.instagram?.handle}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-gray-600" />
                      <span className="font-bold">
                        {(influencer.platforms?.instagram?.followers / 1000).toFixed(1)}K
                      </span>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-3 rounded-xl">
                      <div className="text-sm text-gray-600">Engagement</div>
                      <div className="font-bold text-[#2F2C7F] flex items-center gap-1">
                        <Zap className="w-4 h-4" />
                        {influencer.platforms?.instagram?.engagement_rate}%
                      </div>
                    </div>
                    <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-3 rounded-xl">
                      <div className="text-sm text-gray-600">Avg. Likes</div>
                      <div className="font-bold text-[#2F2C7F]">
                        {(influencer.platforms?.instagram?.average_likes / 1000).toFixed(1)}K
                      </div>
                    </div>
                  </div>
                </div>

                {/* Content Categories */}
                <div className="bg-white rounded-2xl shadow-sm p-4">
                  <h3 className="text-lg font-semibold mb-3">Content Categories</h3>
                  <div className="flex flex-wrap gap-2">
                    {influencer.niche?.map((category, index) => (
                      <Badge 
                        key={index}
                        variant="secondary" 
                        className="px-3 py-1 bg-gradient-to-r from-[#2F2C7F] to-[#E010CD] text-white"
                      >
                        {category}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t">
                  <Button 
                    onClick={onLike}
                    className="w-full bg-gradient-to-r from-[#2F2C7F] to-[#E010CD] text-white"
                  >
                    <Heart className="w-4 h-4 mr-2" />
                    Send Match Request
                  </Button>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="audience"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="p-4 space-y-6"
              >
                {/* Gender Distribution */}
                <div className="bg-white rounded-2xl shadow-sm p-4">
                  <h3 className="text-lg font-semibold mb-4">Audience Gender</h3>
                  <GenderChart 
                    data={{
                      female: influencer.audience?.gender?.female || 23,
                      male: influencer.audience?.gender?.male || 77
                    }}
                  />
                </div>

                {/* Audience Stats */}
                <AudienceStats influencer={influencer} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </DialogContent>
    </Dialog>
  );
}