import React, { useState, useEffect } from "react";
import { Influencer } from "@/api/entities";
import { Business } from "@/api/entities";
import { Match } from "@/api/entities";
import { User } from "@/api/entities";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  SearchIcon, 
  BellIcon, 
  Info, 
  X, 
  Heart, 
  HomeIcon, 
  Search, 
  MessageCircle, 
  UserCircle,
  Megaphone,
  LogOut
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import MatchPercentageCircle from "../components/dashboard/MatchPercentageCircle";
import InfluencerDetailModal from "../components/dashboard/InfluencerDetailModal";

/**
 * Dashboard Page Component for Business Users
 * Shows influencer matches with swipe interface for businesses to discover and connect with influencers
 */
export default function Dashboard() {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [business, setBusiness] = useState(null);
  const [influencers, setInfluencers] = useState([]);
  const [filteredInfluencers, setFilteredInfluencers] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [selectedInfluencer, setSelectedInfluencer] = useState(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  
  // State for drag interactions
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [dragDirection, setDragDirection] = useState(null);

  useEffect(() => {
    checkUserOnboarding();
    loadData();
  }, []);

  /**
   * Check user onboarding status and redirect if necessary
   */
  const checkUserOnboarding = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
      
      // Check if user has completed onboarding
      if (!user.onboarding_completed) {
        navigate(createPageUrl("Onboarding"));
        return;
      }
      
      // Check user type for proper routing
      if (user.user_type === "influencer") {
        navigate(createPageUrl("InfluencerDashboard"));
        return;
      }
    } catch (error) {
      console.error("Error checking user status:", error);
      // Redirect to landing page if not authenticated
      navigate(createPageUrl("Landing"));
    }
  };

  /**
   * Load business data and influencer matches
   */
  const loadData = async () => {
    try {
      // Load business data from user
      const user = await User.me();
      const businesses = await Business.filter({ user_id: user.id });
      const businessData = businesses.length > 0 ? businesses[0] : null;
      setBusiness(businessData);

      // Load influencers
      let influencerData = await Influencer.list();
      
      // If no influencers found, use sample data (just for development)
      if (influencerData.length === 0) {
        console.log("No influencers found, adding sample data would be useful here");
      }
      
      setInfluencers(influencerData);

      // Calculate match percentages for each influencer
      const processed = influencerData.map(influencer => {
        let matchPercentage = 50; // Base match percentage

        if (businessData) {
          const businessTags = [
            businessData.industry,
            ...(businessData.campaign_goals || []),
            ...(businessData.preferred_platforms || [])
          ].filter(Boolean);

          const influencerTags = [
            ...(influencer.niche || []),
            ...Object.keys(influencer.platforms || {})
          ].filter(Boolean);

          if (businessTags.length > 0 && influencerTags.length > 0) {
            const matches = businessTags.filter(tag => 
              influencerTags.some(infTag => 
                typeof infTag === 'string' && typeof tag === 'string' && 
                infTag.toLowerCase().includes(tag.toLowerCase())
              )
            );
            matchPercentage = Math.round((matches.length / businessTags.length) * 100);
          }
        }

        return {
          ...influencer,
          matchPercentage: Math.max(50, Math.min(100, matchPercentage)) // Ensure percentage is between 50-100
        };
      });

      // Sort by match percentage but show all
      const sorted = processed.sort((a, b) => b.matchPercentage - a.matchPercentage);
      setFilteredInfluencers(sorted);
      
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Handle swipe action (left or right)
   * 
   * @param {string} direction - 'left' for reject, 'right' for like
   */
  const handleSwipe = (direction) => {
    if (currentIndex >= filteredInfluencers.length) return;
    
    const currentInfluencer = filteredInfluencers[currentIndex];
    
    if (direction === "right") {
      // Like - create match
      if (business) {
        createMatch(currentInfluencer.id);
      }
    }
    
    // Move to next card regardless of swipe direction
    setCurrentIndex(currentIndex + 1);
    setDragOffset({ x: 0, y: 0 });
    setDragDirection(null);
  };

  /**
   * Create a match between business and influencer
   * 
   * @param {string} influencerId - ID of the influencer to match with
   */
  const createMatch = async (influencerId) => {
    try {
      if (!business) return;
      
      await Match.create({
        business_id: business.id,
        influencer_id: influencerId,
        status: "pending_influencer_approval", // Update to correct status
        initiated_by: "business",
        business_approved: true // Business approved by swiping right
      });
    } catch (error) {
      console.error("Error creating match:", error);
    }
  };

  /**
   * Handle start of drag interaction
   */
  const handleDragStart = (e, info) => {
    setDragStart({ x: info.point.x, y: info.point.y });
  };

  /**
   * Handle drag interaction
   */
  const handleDrag = (e, info) => {
    const offset = { 
      x: info.point.x - dragStart.x, 
      y: info.point.y - dragStart.y 
    };
    setDragOffset(offset);
    
    // Determine swipe direction based on horizontal movement
    if (offset.x > 50) {
      setDragDirection("right");
    } else if (offset.x < -50) {
      setDragDirection("left");
    } else {
      setDragDirection(null);
    }
  };

  /**
   * Handle end of drag interaction
   */
  const handleDragEnd = (e, info) => {
    if (dragDirection) {
      handleSwipe(dragDirection);
    } else {
      setDragOffset({ x: 0, y: 0 });
    }
  };

  /**
   * Open detail modal for an influencer
   * 
   * @param {Object} influencer - Influencer data to view
   */
  const viewInfluencerDetails = (influencer) => {
    setSelectedInfluencer(influencer);
    setDetailModalOpen(true);
  };

  /**
   * Handle user logout
   */
  const handleLogout = async () => {
    try {
      await User.logout();
      // Redirect to Landing page which has sign in and sign up options
      navigate(createPageUrl("Landing"));
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <div className="p-4 flex justify-between items-center">
        <div className="text-2xl font-bold bg-gradient-to-r from-blue-900 to-orange-500 bg-clip-text text-transparent">
          WETIE
        </div>
        <div className="flex gap-4">
          <button onClick={() => navigate(createPageUrl("Discover"))} className="text-gray-600">
            <SearchIcon className="w-6 h-6" />
          </button>
          <button className="text-gray-600">
            <BellIcon className="w-6 h-6" />
          </button>
          <button onClick={handleLogout} className="text-gray-600">
            <LogOut className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Swipe Area */}
      <div className="px-4 pb-4 relative">
        <AnimatePresence>
          {filteredInfluencers.length > 0 && currentIndex < filteredInfluencers.length ? (
            <motion.div
              key={filteredInfluencers[currentIndex].id}
              className="relative"
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ 
                scale: 1, 
                opacity: 1,
                x: dragOffset.x,
                rotate: dragOffset.x * 0.05
              }}
              exit={{ 
                x: dragDirection === "right" ? 500 : dragDirection === "left" ? -500 : 0,
                opacity: 0,
                transition: { duration: 0.3 }
              }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
              drag="x"
              dragConstraints={{ left: 0, right: 0 }}
              onDragStart={handleDragStart}
              onDrag={handleDrag}
              onDragEnd={handleDragEnd}
            >
              <Card className="rounded-3xl overflow-hidden max-w-sm mx-auto shadow-lg relative">
                {/* Match Percentage */}
                <div className="absolute top-4 right-4 z-10">
                  <MatchPercentageCircle 
                    percentage={filteredInfluencers[currentIndex].matchPercentage} 
                  />
                </div>
                
                {/* Image with fallback */}
                <div 
                  className="w-full h-[450px] bg-cover bg-center"
                  style={{
                    backgroundImage: `url(${filteredInfluencers[currentIndex].profile_picture || 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60'})`
                  }}
                />
                
                {/* Profile Info Overlay */}
                <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/80 to-transparent p-4 text-white">
                  <h2 className="text-3xl font-bold">
                    {filteredInfluencers[currentIndex].full_name}
                  </h2>
                  
                  <p className="text-white/90 text-lg mb-2">
                    {filteredInfluencers[currentIndex].location || "Doha"}
                  </p>
                  
                  {/* Bio */}
                  <p className="text-white/80 text-sm mb-2 line-clamp-2">
                    {filteredInfluencers[currentIndex].bio || "No bio available"}
                  </p>
                  
                  {/* Matching Tags */}
                  <div className="flex flex-wrap gap-2 mt-2">
                    {filteredInfluencers[currentIndex].niche && 
                      filteredInfluencers[currentIndex].niche.map((tag, index) => (
                        <Badge 
                          key={index} 
                          className="bg-white/20 text-white hover:bg-white/30 cursor-default px-4 py-1 text-sm"
                        >
                          {tag}
                        </Badge>
                      ))
                    }
                  </div>
                </div>
              </Card>
              
              {/* Swipe Feedback Indicators */}
              {dragDirection === "left" && (
                <div className="absolute top-10 left-10 bg-red-500 text-white p-2 rounded-full transform rotate-12">
                  <X className="w-10 h-10" />
                </div>
              )}
              {dragDirection === "right" && (
                <div className="absolute top-10 right-10 bg-green-500 text-white p-2 rounded-full transform -rotate-12">
                  <Heart className="w-10 h-10" />
                </div>
              )}
            </motion.div>
          ) : (
            <div className="flex flex-col items-center justify-center h-[500px] text-center">
              <div className="text-2xl font-semibold text-gray-700 mb-4">
                No more influencers to show
              </div>
              <p className="text-gray-500 mb-6 max-w-xs">
                You've seen all available influencers
              </p>
              {filteredInfluencers.length > 0 && (
                <Button 
                  variant="outline" 
                  onClick={() => setCurrentIndex(0)}
                  className="px-6"
                >
                  Start Over
                </Button>
              )}
            </div>
          )}
        </AnimatePresence>
      </div>

      {/* Action Buttons - only show when there are influencers to display */}
      {filteredInfluencers.length > 0 && currentIndex < filteredInfluencers.length && (
        <div className="flex justify-center gap-8 mt-4">
          <Button
            size="lg"
            variant="outline"
            className="h-16 w-16 rounded-full border-2 border-gray-300 hover:border-red-500 hover:bg-red-50"
            onClick={() => handleSwipe("left")}
          >
            <X className="w-8 h-8 text-gray-800" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="h-16 w-16 rounded-full border-2 border-gray-300 hover:border-blue-500 hover:bg-blue-50"
            onClick={() => viewInfluencerDetails(filteredInfluencers[currentIndex])}
          >
            <Info className="w-8 h-8 text-gray-800" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="h-16 w-16 rounded-full border-2 border-gray-300 hover:border-green-500 hover:bg-green-50"
            onClick={() => handleSwipe("right")}
          >
            <Heart className="w-8 h-8 text-gray-800" />
          </Button>
        </div>
      )}

      {/* Influencer Details Modal */}
      <InfluencerDetailModal 
        influencer={selectedInfluencer}
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        onLike={() => {
          if (selectedInfluencer) {
            createMatch(selectedInfluencer.id);
            setDetailModalOpen(false);
            // If this is the current card, move to next
            if (selectedInfluencer.id === filteredInfluencers[currentIndex]?.id) {
              setCurrentIndex(currentIndex + 1);
            }
          }
        }}
      />
    </div>
  );
}