import React from 'react';
import { Card } from "@/components/ui/card";
import { motion } from 'framer-motion';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';

export default function StatisticsCard({
  icon: Icon,
  label,
  value,
  format,
  trend,
  trendUp,
  iconColor,
  bgClass
}) {
  const formatValue = (val) => {
    if (format === 'number') {
      if (val >= 1000000) {
        return `${(val / 1000000).toFixed(1)}M`;
      }
      if (val >= 1000) {
        return `${(val / 1000).toFixed(1)}K`;
      }
      return val.toLocaleString();
    }
    if (format === 'percent') {
      return `${val}%`;
    }
    return val;
  };

  return (
    <motion.div
      whileHover={{ y: -2, boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.05)' }}
      transition={{ duration: 0.2 }}
    >
      <Card className="overflow-hidden h-full">
        <div className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className={`w-10 h-10 rounded-lg ${bgClass} flex items-center justify-center`}>
              <Icon className={`w-5 h-5 ${iconColor}`} />
            </div>
            
            {trend && (
              <div className={`flex items-center text-xs font-medium ${
                trendUp ? 'text-green-600' : 'text-red-600'
              }`}>
                {trendUp ? (
                  <ArrowUpRight className="w-3 h-3 mr-0.5" />
                ) : (
                  <ArrowDownRight className="w-3 h-3 mr-0.5" />
                )}
                {trend}
              </div>
            )}
          </div>
          
          <div className="text-xl font-bold text-gray-900 mb-1">
            {formatValue(value)}
          </div>
          
          <div className="text-sm text-gray-500">
            {label}
          </div>
        </div>
      </Card>
    </motion.div>
  );
}