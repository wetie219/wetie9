import React from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { 
  Camera, 
  Smartphone, 
  ShoppingBag, 
  BookOpen, 
  Plane, 
  Heart, 
  Music, 
  Coffee 
} from "lucide-react";

export default function ContentCategories({ selectedCategories, onCategoryChange, editMode }) {
  const categories = [
    { id: 'fashion', icon: Camera, label: 'Fashion' },
    { id: 'tech', icon: Smartphone, label: 'Tech' },
    { id: 'beauty', icon: Heart, label: 'Beauty' },
    { id: 'education', icon: BookOpen, label: 'Education' },
    { id: 'travel', icon: Plane, label: 'Travel' },
    { id: 'lifestyle', icon: Coffee, label: 'Lifestyle' },
    { id: 'shopping', icon: ShoppingBag, label: 'Shopping' },
    { id: 'music', icon: Music, label: 'Music' }
  ];

  const handleToggle = (categoryId) => {
    if (!editMode) return;
    
    if (selectedCategories.includes(categoryId)) {
      onCategoryChange(selectedCategories.filter(id => id !== categoryId));
    } else if (selectedCategories.length < 3) {
      onCategoryChange([...selectedCategories, categoryId]);
    }
  };

  return (
    <Card className="p-6">
      <h2 className="text-lg font-semibold mb-2">Content Categories</h2>
      <p className="text-sm text-gray-600 mb-6">
        Select up to 3 categories that best describe your content
      </p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {categories.map((category) => {
          const isSelected = selectedCategories.includes(category.id);
          
          return (
            <motion.div
              key={category.id}
              whileHover={editMode ? { scale: 1.02 } : {}}
              whileTap={editMode ? { scale: 0.98 } : {}}
              onClick={() => handleToggle(category.id)}
              className={`
                rounded-xl p-4 cursor-pointer transition-all
                ${isSelected 
                  ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md' 
                  : 'bg-gray-50 text-gray-700 hover:bg-gray-100'}
                ${!editMode && !isSelected ? 'opacity-50' : ''}
              `}
            >
              <div className="flex items-center gap-2">
                <category.icon className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-gray-500'}`} />
                <span className="font-medium">{category.label}</span>
              </div>
            </motion.div>
          );
        })}
      </div>
    </Card>
  );
}