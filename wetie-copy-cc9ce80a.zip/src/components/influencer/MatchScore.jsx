import React from 'react';

export default function MatchScore({ percentage }) {
  const radius = 30;
  const circumference = 2 * Math.PI * radius;
  const progress = (percentage / 100) * circumference;
  const dashoffset = circumference - progress;

  return (
    <div className="relative h-20 w-20 flex items-center justify-center">
      <svg className="absolute -rotate-90 transform" width="80" height="80">
        {/* Background circle */}
        <circle
          cx="40"
          cy="40"
          r={radius}
          stroke="#E5E7EB"
          strokeWidth="6"
          fill="white"
        />
        
        {/* Progress circle with gradient */}
        <circle
          cx="40"
          cy="40"
          r={radius}
          stroke="url(#gradient)"
          strokeWidth="6"
          fill="transparent"
          strokeDasharray={circumference}
          strokeDashoffset={dashoffset}
          strokeLinecap="round"
        />
        
        {/* Gradient definition */}
        <defs>
          <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#2F2C7F" />
            <stop offset="100%" stopColor="#E010CD" />
          </linearGradient>
        </defs>
      </svg>
      
      {/* Percentage text */}
      <div className="text-lg font-bold">
        {percentage}%
      </div>
    </div>
  );
}