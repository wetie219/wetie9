import React from 'react';

/**
 * Circular match percentage indicator
 * Shows compatibility percentage between influencer and business
 * Color-coded segments indicate match quality (red, yellow, green)
 * 
 * @param {number} percentage - Match percentage (0-100)
 */
export default function MatchPercentageCircle({ percentage }) {
  const radius = 25;
  const circumference = 2 * Math.PI * radius;
  const progress = (percentage / 100) * circumference;
  const dashoffset = circumference - progress;
  
  // Determine color based on percentage
  const getColor = (percent) => {
    if (percent >= 80) return "#10B981"; // Green for high match
    if (percent >= 60) return "#F59E0B"; // Amber for medium match
    return "#EF4444"; // Red for low match
  };

  return (
    <div className="relative h-16 w-16 flex items-center justify-center">
      {/* Background circle */}
      <svg className="absolute" width="64" height="64">
        <circle
          cx="32"
          cy="32"
          r={radius}
          stroke="#E5E7EB"
          strokeWidth="5"
          fill="#FFFFFF"
          strokeLinecap="round"
        />
      </svg>
      
      {/* Progress circle - red segment (first third) */}
      <svg className="absolute -rotate-90 transform" width="64" height="64">
        <circle
          cx="32"
          cy="32"
          r={radius}
          stroke="#EF4444"
          strokeWidth="5"
          fill="transparent"
          strokeDasharray={circumference}
          strokeDashoffset={circumference - (percentage >= 33 ? circumference / 3 : progress)}
          strokeLinecap="round"
        />
      </svg>
      
      {/* Progress circle - yellow segment (second third) */}
      {percentage >= 33 && (
        <svg className="absolute -rotate-90 transform" width="64" height="64">
          <circle
            cx="32"
            cy="32"
            r={radius}
            stroke="#F59E0B"
            strokeWidth="5"
            fill="transparent"
            strokeDasharray={circumference}
            strokeDashoffset={circumference - (percentage >= 66 ? circumference * 2/3 : progress)}
            strokeLinecap="round"
            style={{ strokeDashoffset: circumference - Math.min(circumference * 2/3, Math.max(circumference / 3, progress)) }}
          />
        </svg>
      )}
      
      {/* Progress circle - green segment (final third) */}
      {percentage >= 66 && (
        <svg className="absolute -rotate-90 transform" width="64" height="64">
          <circle
            cx="32"
            cy="32"
            r={radius}
            stroke="#10B981"
            strokeWidth="5"
            fill="transparent"
            strokeDasharray={circumference}
            strokeDashoffset={circumference - progress}
            strokeLinecap="round"
            style={{ strokeDashoffset: circumference - Math.min(circumference, Math.max(circumference * 2/3, progress)) }}
          />
        </svg>
      )}
      
      {/* Percentage text */}
      <div className="bg-white rounded-full h-12 w-12 flex items-center justify-center font-bold text-lg z-10">
        {percentage}%
      </div>
    </div>
  );
}