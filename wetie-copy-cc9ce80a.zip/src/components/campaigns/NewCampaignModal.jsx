import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function NewCampaignModal({ open, onClose, onSubmit }) {
  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission
    onSubmit({
      // Form data
    });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] bg-gradient-to-br from-gray-50 to-gray-100">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold bg-gradient-to-r from-[#2F2C7F] to-[#E010CD] bg-clip-text text-transparent">
            Create New Campaign
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-sm font-medium">Campaign Name</Label>
            <Input 
              id="name" 
              placeholder="Enter campaign name"
              className="bg-white/50 backdrop-blur-sm border-gray-200"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="type" className="text-sm font-medium">Campaign Type</Label>
            <Select>
              <SelectTrigger className="bg-white/50 backdrop-blur-sm border-gray-200">
                <SelectValue placeholder="Select campaign type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="post">Instagram Post</SelectItem>
                <SelectItem value="story">Instagram Story</SelectItem>
                <SelectItem value="video">Video Content</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="pt-4 space-x-2 flex justify-end">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" className="bg-gradient-to-r from-[#2F2C7F] to-[#E010CD]">
              Create Campaign
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}