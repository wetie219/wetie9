import React from "react";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { CheckCircle, Target, X } from "lucide-react";

export default function BusinessGoals({ formData, updateFormData }) {
  const campaignGoals = [
    {
      id: "brand_awareness",
      label: "Brand Awareness",
      description: "Increase visibility and recognition"
    },
    {
      id: "product_launch",
      label: "Product Launch",
      description: "Promote new products or services"
    },
    {
      id: "sales_boost",
      label: "Sales & Conversion",
      description: "Drive direct sales and conversions"
    },
    {
      id: "community_engagement",
      label: "Community Engagement",
      description: "Build and engage with your community"
    },
    {
      id: "content_creation",
      label: "Content Creation",
      description: "Get professional content for your brand"
    },
    {
      id: "event_promotion",
      label: "Event Promotion",
      description: "Promote events and launches"
    }
  ];

  const toggleGoal = (goalId) => {
    const currentGoals = formData.campaign_goals || [];
    if (currentGoals.includes(goalId)) {
      updateFormData({
        campaign_goals: currentGoals.filter(id => id !== goalId)
      });
    } else {
      updateFormData({
        campaign_goals: [...currentGoals, goalId]
      });
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-center mb-2">Campaign Goals</h2>
      <p className="text-gray-600 text-center mb-8">
        What do you want to achieve with influencer marketing?
      </p>

      <div className="space-y-4">
        {campaignGoals.map(goal => (
          <Card
            key={goal.id}
            className={`p-4 cursor-pointer transition-all duration-200 ${
              formData.campaign_goals?.includes(goal.id)
                ? "border-[#E010CD] bg-purple-50"
                : "hover:border-gray-300"
            }`}
            onClick={() => toggleGoal(goal.id)}
          >
            <div className="flex items-center gap-3">
              <div 
                className={`w-6 h-6 rounded-full flex items-center justify-center ${
                  formData.campaign_goals?.includes(goal.id)
                    ? "bg-[#E010CD] text-white"
                    : "bg-gray-100"
                }`}
              >
                {formData.campaign_goals?.includes(goal.id) ? (
                  <CheckCircle className="w-4 h-4" />
                ) : (
                  <Target className="w-4 h-4 text-gray-400" />
                )}
              </div>
              <div className="flex-1">
                <div className="font-medium">{goal.label}</div>
                <div className="text-sm text-gray-500">{goal.description}</div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <p className="text-sm text-gray-500 mt-4 text-center">
        Select all that apply to your marketing strategy
      </p>
    </div>
  );
}