import React from 'react';
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import {
  Users,
  TrendingUp,
  Globe,
  Play,
  Heart,
  MessageCircle
} from "lucide-react";

/**
 * TikTok Statistics Component
 * Displays real-time TikTok metrics
 */
export default function TikTokStats({ stats }) {
  if (!stats?.connected) {
    return null;
  }

  return (
    <div className="space-y-6">
      {/* Audience Overview */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">TikTok Audience</h3>
        
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="bg-black/5 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Users className="w-5 h-5 text-black" />
              <span className="text-sm text-gray-600">Followers</span>
            </div>
            <div className="text-2xl font-bold">
              {(stats.followers || 0).toLocaleString()}
            </div>
          </div>
          
          <div className="bg-black/5 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Heart className="w-5 h-5 text-red-500" />
              <span className="text-sm text-gray-600">Total Likes</span>
            </div>
            <div className="text-2xl font-bold">
              {(stats.total_likes || 0).toLocaleString()}
            </div>
          </div>
        </div>

        {/* Video Performance */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Average Views per Video</span>
            <Badge variant="outline" className="font-mono">
              {(stats.video_views || 0).toLocaleString()}
            </Badge>
          </div>
          <Progress value={stats.engagement_rate} className="h-2" />
        </div>

        {/* Demographics */}
        {stats.demographics && (
          <div className="space-y-4">
            <h4 className="text-sm font-medium">Demographics</h4>
            
            {/* Gender Split */}
            <div className="grid grid-cols-2 gap-2">
              <div className="bg-pink-50 rounded p-2 text-center">
                <div className="text-sm text-gray-600">Female</div>
                <div className="font-bold">
                  {stats.demographics.gender?.female || 0}%
                </div>
              </div>
              <div className="bg-blue-50 rounded p-2 text-center">
                <div className="text-sm text-gray-600">Male</div>
                <div className="font-bold">
                  {stats.demographics.gender?.male || 0}%
                </div>
              </div>
            </div>

            {/* Age Groups */}
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Age Distribution</h4>
              {Object.entries(stats.demographics.age_groups || {}).map(([age, percentage]) => (
                <div 
                  key={age}
                  className="flex items-center justify-between p-2 bg-gray-50 rounded"
                >
                  <span>{age.replace('_', '-')}</span>
                  <Badge variant="outline">{percentage}%</Badge>
                </div>
              ))}
            </div>
          </div>
        )}
      </Card>

      {/* Geographic Distribution */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Top Locations</h3>
        <div className="space-y-3">
          {stats.top_locations?.map((location, index) => (
            <div 
              key={index}
              className="flex items-center justify-between p-2 bg-gray-50 rounded"
            >
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-gray-600" />
                <span>{location.country}</span>
              </div>
              <Badge variant="outline">{location.percentage}%</Badge>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}