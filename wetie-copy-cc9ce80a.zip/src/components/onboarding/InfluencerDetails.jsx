import React from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

export default function InfluencerDetails({ formData, updateFormData }) {
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    updateFormData({ [name]: value });
  };
  
  return (
    <div>
      <h2 className="text-2xl font-bold text-center mb-2">Tell Us About Yourself</h2>
      <p className="text-gray-600 text-center mb-8">
        This information will be shown on your profile
      </p>
      
      <div className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="display_name">Full Name</Label>
          <Input 
            id="display_name"
            name="display_name"
            placeholder="Jane Smith"
            value={formData.display_name || ""}
            onChange={handleInputChange}
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="bio">Bio</Label>
          <Textarea 
            id="bio" 
            name="bio"
            placeholder="Tell brands about yourself, your content style, and what you're passionate about..."
            value={formData.bio || ""}
            onChange={handleInputChange}
            className="resize-none h-36"
          />
          <p className="text-sm text-gray-500">
            {formData.bio?.length || 0}/300 characters
          </p>
        </div>
      </div>
    </div>
  );
}